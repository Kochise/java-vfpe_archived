/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1999
*/

package jkk.net;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.Vector;

public abstract class Shell extends Thread implements Cloneable {

	public InputStream in;
	public OutputStream out;
	private Vector exitListeners = new Vector();

	public Shell() { }

	public Shell(InputStream is, OutputStream os) {
		in = is; out = os;
	}

	public Object clone() {
		try {
			Shell s = (Shell)super.clone();
			s.exitListeners = new Vector();
			return s;
		} catch(CloneNotSupportedException cnse) {
			System.out.println("Universe out of alignment.");
			System.exit(10);
		}
		return null;
	}

	// Override me

	public abstract void run();

	// tools

	public void exit() {
		for(int i=0;i < exitListeners.size();i++) {
			((ExitListener)exitListeners.elementAt(i)).exited(this);
		}
		this.stop();
	}

	public void addExitListener(ExitListener el) {
		exitListeners.addElement(el);
	}

	// nice idea, but not quite right
	public void transmute(Shell newShell) {
		newShell.in = in; newShell.out = out;
		newShell.start();
		// should this in fact be
		// newShell.init(); newShell.run();
		this.stop();
	}
}

