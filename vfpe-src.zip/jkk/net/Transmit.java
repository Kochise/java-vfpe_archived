/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1999
*/

package jkk.net;

import java.io.InputStreamReader;
import java.io.IOException;
import java.io.LineNumberReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

import jkk.io.Lib;
import jkk.io.Slurper;

// WARNING
// this class uses locale default character encodings for its Readers
// and Writers.  this should maybe be changed to explicit UTF8

public class Transmit {

	////////////
	// constants

	public static int closeDelay = 5000;

	///////////////////
	// application main

	public static void main(String [] argv) throws IOException {

		// read parameters

		if(argv.length < 2)
			throw new IllegalArgumentException(
				"usage: java jkk.net.Transmit <host> <port> [<file>]");
		int port = 0;
		try {
			port = Integer.parseInt(argv[1]);
		} catch(NumberFormatException nfe) {
			throw new IllegalArgumentException("bad port number " + port);
		}

		// try to open socket

		InetAddress ia = null;
		try {
			ia = InetAddress.getByName(argv[0]);
		} catch(UnknownHostException uhe) {
			throw new IOException("Unknown host " + argv[0]);
		}

		Socket s = new Socket(ia,port);
		final LineNumberReader r = new LineNumberReader(
			new InputStreamReader(s.getInputStream()));

		// start reader thread

		Thread t = new Thread() {
			public void run() {
				String st = null;
				do {
					try {
						st = r.readLine();
					} catch(IOException ioe) {
						System.err.println("*** exception on read ***");
						st = null;
					}
					if(st != null)
						System.out.println(st);
				} while(st != null);
			}
		};
		t.start();

		// start transmitting

		if(argv.length == 3) {
			byte [] bs = jkk.io.Lib.fileToByteArray(argv[2]);
			if(bs == null)
				System.err.println("*** can't find file ***");
			else {
				s.getOutputStream().write(bs);
				s.getOutputStream().flush();
			}
		}

		LineNumberReader in = new LineNumberReader(
			new InputStreamReader(System.in));
		OutputStreamWriter osw = new OutputStreamWriter(
			s.getOutputStream());
		String st = null;
		do {
			st = in.readLine();
			if(st.equals(".")) st = null;
			if(st != null) {
				osw.write(st + "\n"); osw.flush();
			}
		} while(st != null);

		// close socket

		s.close();

	}

	///////////////
	// static tools

	public static String transmit(String data, String host, int port) 
		throws IOException {
		try {
			InetAddress ia = InetAddress.getByName(host);
			return transmit(data,ia,port);
		} catch(UnknownHostException uhe) {
			throw new IllegalArgumentException("Unknown host " + host);
		}
	}

	public static String transmit(String data, InetAddress host, int port) 
		throws IOException {
		byte [] sData = Lib.stringToByteArray(data);
		byte [] rData = transmit(sData,host,port);
		return Lib.byteArrayToString(rData);
	}

	public static byte [] transmit(byte [] data, String host, int port) 
		throws IOException {
		try {
			InetAddress ia = InetAddress.getByName(host);
			return transmit(data,ia,port);
		} catch(UnknownHostException uhe) {
			throw new IllegalArgumentException("Unknown host " + host);
		}
	}

	public static byte [] transmit(byte [] data, InetAddress host, int port)
		throws IOException {
		Socket s = new Socket(host,port);
		OutputStream os = s.getOutputStream();
		Slurper slurper = new Slurper(s.getInputStream());
		synchronized (slurper) {
			slurper.start();
			os.write(data); os.flush();
			try {
				slurper.wait();
			} catch(InterruptedException ie) { 
			}
		}
		s.close();
		return slurper.getData();
	}
}

