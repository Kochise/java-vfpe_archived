/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1999
*/

package jkk.net;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.IOException;
import java.io.LineNumberReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

public abstract class StringShell extends Shell {

	private OutputStreamWriter osw;
	public boolean addCR = true;

	public void run() {
		init();
		String line = null;
		LineNumberReader lnr = new LineNumberReader(
			new InputStreamReader(in));
		while(true) {
			try {
				line = lnr.readLine();
			} catch(IOException ioe) {
				readError(ioe);
			}
			process(line);
		}
	}

	public void output(String s) {
		if(osw == null)
			osw = new OutputStreamWriter(out);
		try {
			if(addCR)
				s = jkk.text.Lib.toCRLF(s);
			osw.write(s);
			osw.flush();
		} catch(IOException ioe) {
			writeError(ioe);
		}
	}

	// Override me

	public void init() { }

	public abstract void process(String cmd);

	public void readError(IOException ioe) {
		System.out.println("StringShell (read error): " + ioe);
		exit(); stop();
	}
	
	public void writeError(IOException ioe) { }

}

