/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1999
*/

package jkk.net;

public class LoginShell extends StringShell {
	private static final int USERNAME = 0;
	private static final int PASSWORD = 1;
	private static final int COMMAND = 2;
	
	private int phase;
	public String prompt = "> ";
	public String banner = "house of Kelso test shell v0.1\n\n";

	// implementation

	public void init() {
		output(banner); output("username: ");
	}

	public void process(String cmd) {
		switch(phase) {
		case USERNAME:
			phase = PASSWORD;
			output("password: ");
			break;
		case PASSWORD:
			phase = COMMAND;
			output(prompt);
			break;
		case COMMAND:
			if(cmd.equals("exit")) {
				output("Bye.\n");
				exit(); return;
			}
			output("Do I hear you say " + cmd + "?\n");
			output(prompt);
			break;
		}
	}
}

