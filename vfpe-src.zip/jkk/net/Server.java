/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1999
*/

package jkk.net;

import java.io.InputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Hashtable;

public class Server extends Thread implements
	ExitListener {

	int port;
	Shell protoShell;
	public Hashtable connections;
	
	// constructors

	public Server(int port, Shell protoShell) {
		this.port = port;
		this.protoShell = protoShell;
		connections = new Hashtable();
	}

	// run method

	public void run() {
		ServerSocket listener = null;
		try {
			listener = new ServerSocket(port);
		} catch(IOException ioe) {
			System.out.println("Server (during server socket construction): "
				+ ioe);
			return;
		}
		while(true) {
			try {
				Socket client = listener.accept();
				Shell shell = (Shell)protoShell.clone();
				shell.in = client.getInputStream();
				shell.out = client.getOutputStream();
				shell.addExitListener(this);
				connections.put(shell,client);
				shell.start();
			} catch(IOException ioe) {
				System.out.println("Server (during accept): " + ioe);
			}
		}

	}

	// ExitListener implementation

	public void exited(Object o) {
		int hash = o.hashCode();
		Socket s = (Socket)connections.get(o);
		if(s == null) return;
		try {
			s.close();
		} catch(IOException ioe) {
			System.out.println("Server (during exited): " + ioe);
		}
		connections.remove(o);
	}

	// test launcher main

	public static void main(String [] argv) {
		int pn = 0;
		try {
			pn = Integer.parseInt(argv[0]);
		} catch(NumberFormatException nfe) {
			panic("bad port number " + argv[0]);
		}

		Shell shell = (Shell)jkk.Lib.makeObject(argv[1]);
		if(shell == null)
			panic("couldn't create prototype shell");
		Server s = new Server(pn,shell);
		s.start();
	}

	private static void panic(String msg) {
		System.out.println("Server (creating server): " + msg);
		System.exit(10);
	}
}

