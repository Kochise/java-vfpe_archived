/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1999
*/

package jkk;

import java.util.Enumeration;
import java.util.Hashtable;

/**
	Note that this returns 0 for keys that are not present.
*/
public class IntTable extends Hashtable {

	public void set(Object key, int val) {
		int [] a = getValArray(key); a[0] = val;
	}

	public void add(Object key, int val) {
		int [] a = getValArray(key); a[0] += val;
	}

	public int getVal(Object key) {
		if(!this.containsKey(key)) return 0;
		int [] a = getValArray(key); return a[0];
	}

	public Object maxKey() {
		Enumeration e = keys();
		Object mK = null;
		int m = Integer.MIN_VALUE;
		while(e.hasMoreElements()) {
			Object k = e.nextElement();
			int t = getVal(k);
			if(t >= m) {
				m = t; mK = k;
			}
		}
		return mK;
	}

	public int maxVal() { return getVal(maxKey());	}

	public int sum() {
		int s = 0;
		Enumeration e = keys();
		while(e.hasMoreElements())
			s += getVal(e.nextElement());
		return s;
	}

	private int [] getValArray(Object key) {
		int [] a = (int [])get(key);
		if(a == null)
			put(key,a = new int[1]);
		return a;
	}

}
