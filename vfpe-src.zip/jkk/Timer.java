/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  joel@babbage.cs.murdoch.edu.au
  *** * * * * copyright 1996
*/

package jkk;

import jkk.Functor;

public class Timer implements Runnable {
	private Functor f;
	private Thread alarm;
	public long delay;
	public long startTime;

	public Timer(long delay, Functor f) {
		this.f = f;
		this.delay = delay;
		reset();
	}

	public boolean isRunning() { return alarm.isAlive(); }
	
	public void start() { alarm.start(); }
	
	public void stop() { alarm.stop(); }
	
	public void reset() {
		if(alarm != null)
			alarm.stop();
		alarm = new Thread(this);
		startTime = System.currentTimeMillis();
	}
	
	public void run() {
		try {
			Thread.sleep(delay);
		} catch(InterruptedException ie) { }
		f.eval(null);
	}
}	
