/*
    * * * * * software from the house of J Kyle Kelso
    * **  ** 
  *** * * * * copyright 1999
*/

/* list implementation, O(n) operations */
/*	NOTE:	head of queue is LOWEST number priority */

package jkk;

import java.util.Vector;

public class PriQueue {

	private Vector elems;
	private Vector pris;

	public PriQueue() {
		elems = new Vector();
		pris = new Vector();
	}

	// ops

	public void add(Object o, int pri) {
		int i = 0;
		while(i < size() && getPriAt(i) <= pri)
			i++;
		elems.insertElementAt(o,i);
		pris.insertElementAt(new Integer(pri),i);
	}

	public Object next() {
		Object r = peek();
		elems.removeElementAt(0); pris.removeElementAt(0);
		return r;
	}

	public boolean isEmpty() { return size() == 0; }

	public int size() { return elems.size(); }

	public Object peek() { return elems.firstElement(); }

	public void remove(Object o) {
		int i = elems.indexOf(o);
		elems.removeElementAt(i);
		pris.removeElementAt(i);
	}

	public void setPri(Object o, int newPri) {
		remove(o); add(o, newPri);
	}

	public int getPri(Object o) {
		return getPriAt(elems.indexOf(o));
	}

	// internals

	private int getPriAt(int i) {
		return ((Integer)pris.elementAt(i)).intValue();
	}
}
