/*
    * * * * * software from the house of J Kyle Kelso
    * **  ** 
  *** * * * * copyright 1999
*/

package jkk;

import java.util.Enumeration;
import java.util.Vector;

import jkk.Set;

public class Partition {

	// given a function returning Vector of adjacent nodes
	// vector should not contain duplicates
	public static Set partition(Set v, Functor f) {
		Vector unclassified = v.vectorise();
		Set partitions = new Set();
		while(unclassified.size() > 0) {
			Object e = unclassified.firstElement();
			unclassified.removeElementAt(0);
			Set ePartition = null;
			Set eMembers = new Set(e,e);
			Vector ns = (Vector)f.eval(e);
			for(int i=0;i < ns.size();i++) {
				Object n = ns.elementAt(i);

				if(n.equals(e)) continue;
				Set nPartition = findPartition(n,partitions);

				if(ePartition == null) { // e not yet classified
					if(nPartition == null) { // n not classified
						if(!eMembers.elem(n)) {
							eMembers.put(n,n);
							unclassified.removeElement(n);
						}
					} else { // n already classified
						nPartition.add(eMembers);
						ePartition = nPartition;
					}
				} else { // e classified
					if(nPartition == null) { // n not classified
						ePartition.put(n,n);
						unclassified.removeElement(n);
					} else { // n classified
						if(!nPartition.equals(ePartition)) {
							ePartition.add(nPartition);
						}
					}
				}
			} // end of iterate-through-neighbours-of-e

			if(ePartition == null)
				partitions.put(eMembers,eMembers);
			
		}
		return partitions;
	}

	public static Set findPartition(Object e, Set partitions) {
		Enumeration ps = partitions.keys();
		while(ps.hasMoreElements()) {
			Set s = (Set)ps.nextElement();
			if(s.elem(e)) return s;
		}
		return null;
	}

}
