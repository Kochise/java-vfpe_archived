/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1996-2000
*/

package jkk.text;

import java.util.Enumeration;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.Vector;

import jkk.text.Lexer;

public class Lib {

	// milliseconds to English time interval

	public static String textTimeInterval(long millis) {
		return textTimeInterval(millis,true);
	}

	public static String textTimeInterval(long millis, boolean verbose) {
		StringBuffer buf = new StringBuffer();
		long days = millis/(1000*60*60*24);
		if(days > 0) {
			buf.append(days); buf.append(" days");
			if(!verbose) return buf.toString();
			millis -= days*(1000*60*60*24);
		}
		long hours = millis/(1000*60*60);		
		if(hours > 0) {
			buf.append(hours); buf.append(" hours");
			if(!verbose) return buf.toString();
			millis -= hours*1000*60*60;
		}
		long mins = millis/(1000*60);		
		if(mins > 0) {
			buf.append(mins); buf.append(" mins");
			if(!verbose) return buf.toString();
			millis -= mins*1000*60;
		}
		long secs = millis/(1000);
		buf.append(mins); buf.append(" secs");
		return buf.toString();
	}

	// string formatting

	public static final String LEFT = "left";
	public static final String RIGHT = "right";
	public static final String CENTER = "center";
	
	private static final String [] SPACES = {
		"", " ", "  ", "   ", "    ", "     ", "      ",
		"       ", "        " };

	public static String spaces(int n) {
		if(n >= SPACES.length) {
			StringBuffer buf = new StringBuffer();
			for(int i=0;i < n;i++) buf.append(' ');
			return buf.toString();
		} else
			return SPACES[n];
	}

	public static String justify(int i, int w, String j) {
		return justify(Integer.toString(i),w,j,false);
	}

	public static String justify(int i, int w) {
		return justify(i,w,RIGHT);
	}

	public static String justify(String s, int width, String just) {
		return justify(s,width,just,false);
	}

	public static String justify(String s, int width, String just,
		boolean truncate) {
		int left = width - s.length();
		if(left < 0)
			if(truncate)
				return s.substring(0,s.length()+left);
			else
				return s;
		if(just.equals(CENTER)) {
			s = spaces(left/2)+s+spaces(left/2);
			if(jkk.math.Lib.mod(left,2) != 0)
				s += " ";
			return s;
		}
			
		if(just.equals(RIGHT))
			return spaces(left)+s;
		return s+spaces(left);
	}
	
	public static String toCRLF(String s) {
		StringBuffer buf = new StringBuffer();
		for(int i=0;i < s.length();i++) {
			if(s.charAt(i) == 10)
				buf.append("\n\r");
			else
				buf.append(s.charAt(i));
		}
		return buf.toString();
	}

	public static String reverse(String r) {
		StringBuffer buf = new StringBuffer();
		for(int i=r.length()-1;i >= 0;i--)
			buf.append(r.charAt(i));
		return buf.toString();
	}

	// stuff for roman numerals and alphabet radix
	
	public static String toAlphabetRadix(int n) {
   		int radix = alphabetRadixDigits.length;
   		StringBuffer buf = new StringBuffer();
   		while(n > 0) {
   			buf.append(alphabetRadixDigits[(n-1) % radix]);
   			n = (n-1) / radix;
   		}
   		return reverse(buf.toString());
	}
	
	private static String [] alphabetRadixDigits ;
	static {
		alphabetRadixDigits = new String[26];
		for(int i=0;i < 26;i++)
			alphabetRadixDigits[i] = new Character((char)('a'+i)).toString();
	}

	/* translated this one from Perl */
	
	public static String toRoman(int arabic) {
 		StringBuffer roman = new StringBuffer();
        for(int i=0;i < 13;i++)
        	while(arabic >= romanRadix[i]) {
        		roman.append(romanDigits[i]);
        		arabic -= romanRadix[i];
        	}
 		return roman.toString();
	}
	private static final int [] romanRadix = {
		1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1
	};
	private static final String [] romanDigits = {
		"m", "cm", "d", "cd", "c", "xc", "l", "xl", "x", "ix", "v", "iv", "i"
	};

	public static Vector stringToLines(String s) {
		return segment(s,"\n");
	}

	// string segmentation

	public static Vector segment(String s, String delim) {
		StringTokenizer toks = new StringTokenizer(s,delim);
		Vector lines = new Vector();
		while(toks.hasMoreTokens())
			lines.addElement(toks.nextToken());
		return lines;
	}

	public static String linesToString(Vector lines) {
		return unsegment(lines,"\n");
	}
	
	public static String unsegment(Vector lines, String term) {
		StringBuffer buf = new StringBuffer();
		Enumeration e = lines.elements();
		while(e.hasMoreElements()) {
			buf.append((String)e.nextElement());
			buf.append(term);
		}
		return buf.toString();
	}

	public static Vector readFields(String s, char delim) {
		Vector v = new Vector();
		int i = 0;
		StringBuffer buf = new StringBuffer();
		while(i < s.length()) {
			if(s.charAt(i) == delim) {
				v.addElement(buf.toString());
				buf = new StringBuffer();
			} else
				buf.append(s.charAt(i));
			i++;
		}
		v.addElement(buf.toString());
		return v;
	}

	// properties file parsing
	
	public static void addProperties(Properties tmp, String props, String delim) 	{
		StringTokenizer toks = new StringTokenizer(props,delim);
		while(toks.hasMoreTokens()) {
			String line = toks.nextToken();
			if(line.startsWith("#") || line.startsWith(delim))
				continue;
			int eqIndex = line.indexOf('=');
			if(eqIndex == -1)
				continue;
			String pname = line.substring(0,eqIndex);
			String pval;
			if(eqIndex == line.length()-1)
				pval = "";
			else
				pval = line.substring(eqIndex+1);
			tmp.put(pname,pval);
		}
	}
	
	public static Properties readProperties(String props, String delim) {
		Properties tmp = new Properties();
		addProperties(tmp,props,delim);
		return tmp;
	}

	// simple S-expression printing and parsing

	public static Object parseObject(String s) {
		try {
			Long l = Long.valueOf(s);
			return l;		
		} catch(NumberFormatException nfe) { }
	
		try {
			Double d = Double.valueOf(s);
			return d;
		} catch(NumberFormatException nfe) { }

		return s;
	}

	public static Object parse(String s) { return parseList(new Lexer(s)); }

	public static Object parseList(String s) { return parseList(new Lexer(s)); }
	
	public static Object parseList(Lexer lex) {
		try {
			lex.nextSpace();
			if(!lex.more()) return null;
			char c = lex.peek();
			if(c == '(') {
				Vector a = new Vector();
				lex.advance(); lex.nextSpace();
				while((c = lex.peek()) != ')') {
					a.addElement(parseList(lex));
					lex.nextSpace();
				}
				lex.advance();
				return a;
			} else if(c == '"') {
				lex.advance();
				String a = lex.nextWord("\"",false,true);
				lex.advance();
				return a;
			} else {
				return parseObject(lex.nextWord("()",true));
			}
		} catch(ArrayIndexOutOfBoundsException aioobe) {
			return null;
		}
	}

	public static String print(Object o) { return printList(o); }

	public static String printList(Object o) {
		if(o instanceof Vector) {
			Vector v = (Vector)o;
			StringBuffer buf = new StringBuffer();
			buf.append('(');
			for(int i=0;i < v.size();i++) {
				if(i > 0) buf.append(' ');
				buf.append(printList(v.elementAt(i)));
			}
			buf.append(')');
			return buf.toString();
		} else if(o instanceof String) {
			String s = (String)o;
			if(noNeedToQuote(s))
				return s;
			else
				return quote(s);
		} else {
			return o.toString();
		}
	}

	public static boolean noNeedToQuote(String s) {
		try {
			Integer l = Integer.valueOf(s);
			return false;		
		} catch(NumberFormatException nfe) { }
	
		try {
			Double d = Double.valueOf(s);
			return false;
		} catch(NumberFormatException nfe) { }

		char c;
		if(s.length() == 0)
			return false;
		for(int i=0;i < s.length();i++) {
			c = s.charAt(i);
			if(Character.isWhitespace(c) ||
				c == '(' | c == ')' | c == '"' || c == '\\')
				return false;
		}
		return true;
	}

	public static String quote(String s) {
		StringBuffer buf = new StringBuffer();
		buf.append('"');
		char c;
		for(int i=0;i < s.length();i++) {
			c = s.charAt(i);
			if(c == '"' || c == '\\')
				buf.append("\\"+c);
			else
				buf.append(c);
		}
		buf.append('"');
		return buf.toString();
	}

	/** Converts ISO control characters to spaces */
   	public static String controlToSpace(String in) {
      	char [] buf = in.toCharArray();
      	for(int i=0;i < buf.length;i++)
        	buf[i] = (Character.isISOControl(buf[i]) ? ' ' : buf[i]);
      	return new String(buf);
   	}

   	// integer parsing with default value

   	public static int parseInt(String s, int def) {
   		try {
   			return Integer.parseInt(s);
		} catch(NumberFormatException nfe) {
			return def;
		}
	}

	// print out doubles with fixed number of decimal places

	public static String printDecimal(double d, int places) {
		String sgn = "";
		if(d < 0.0) {
			d *= -1.0; sgn = "-";
		}
		int integralPart = (int)Math.floor(d);
		double fract = d - Math.floor(d);
		int decPart = (int)(fract*Math.pow(10,places));
		String decString = Integer.toString(decPart);
		while(decString.length() < places)
			decString = "0" + decString;
		return sgn+integralPart+"."+decString;
	}

	// substitute into a keyed string

	public static String substitute(String s, Vector v) {
		StringBuffer buf = new StringBuffer();
		int i = 0;
		while(i < s.length()) {
			char c = s.charAt(i);
			if(c != '{') {
				buf.append(c); i++;
			} else {
				i++;
				StringBuffer bufInt = new StringBuffer();
				while(Character.isDigit(s.charAt(i))) {
					bufInt.append(s.charAt(i)); i++;
				}
				try {
					int key = Integer.parseInt(bufInt.toString());
					buf.append(v.elementAt(key));
				} catch(NumberFormatException nfe) { }
				do {
					i++;
				} while(s.charAt(i-1) != '}');
			}
		}
		return buf.toString();
	}
	
}
