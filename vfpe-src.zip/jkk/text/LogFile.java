/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1999
*/

package jkk.text;

import java.io.File;
import java.io.IOException;
import java.util.Vector;

public class LogFile {

	////////////
	// constants

	public static final long DEF_MAX_LOG_LEN = 1024*10;
	public static final long DEF_TRUNC_LOG_LEN = 1024*5;
	
	/////////
	// fields

	public long maxLogLen = DEF_MAX_LOG_LEN;
	public long truncLogLen = DEF_TRUNC_LOG_LEN;
	private String path;
	private String sep;
	
	////////////////////
	// constructor stuff

	public LogFile(String path, String sep) {
		this.path = path; this.sep = sep;
	}

	///////////////
	// public tools

	public void append(String entry) {
		try {
			jkk.io.Lib.appendStringToFile(path,entry+sep);
		} catch(IOException ioe) {
			throw new IllegalArgumentException("couldn't append to log file " 
				+ path);
		}
	}

	public Vector fetchEntries(int n, boolean delete) {
		String log = load();
		int p = 0;
		int newp = 0;
		Vector v = new Vector();
		while(n == -1 || n > 0) {
			newp = log.indexOf(sep,p);
			if(newp == -1) {
				p = log.length(); break;
			}	
			if(newp == 0) {
				p += sep.length(); continue;
			}
			v.addElement(log.substring(p,newp));
			p = newp + sep.length();
			if(n > 0) n--;
		}
		if(delete)
			save(log.substring(p));
		return v;
	}

	public void deleteEntries(int n) {
		String log = load();
		log = delete(log,n);
		save(log);
	}

	// check logfile length and truncate if necessary
	// this assumes a 8-bit char encoding ...

	public void checkLogLength() {
		long fLen = new File(path).length();
		if(fLen < maxLogLen)
			return;
		String log = load();
		while(log.length() > truncLogLen) {
			log = delete(log);
		}
		save(log);
	}

	////////////////
	// private tools

	private void save(String log) {
		try {
			jkk.io.Lib.stringToFile(path,log);
		} catch(IOException ioe) {
			throw new IllegalArgumentException("couldn't write log file " + path);
		}
	}

	private String load() { 
		String s = jkk.io.Lib.fileToString(path);
		if(s == null)
			throw new IllegalArgumentException("couldn't read log file " + path);
		return s;
	}

	private String delete(String log, int n) {
		int p = 0;
		while(n > 0) {
			p = log.indexOf(sep,p);
			if(p == -1)
				return sep;
			if(p == 0) {
				p += sep.length(); continue;
			}
			n--;
		}
		return log.substring(p+sep.length());
	}

	public String delete(String log) {
		return delete(log,1);
	}

}
