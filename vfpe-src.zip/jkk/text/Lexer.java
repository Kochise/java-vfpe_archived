/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997
*/

package jkk.text;

/* this one uses the Java (C ?) definition of whitespace */

public class Lexer
{
	private char [] buf;
	private int ptr;

	public Lexer(String s)	{
		buf = s.toCharArray(); ptr = 0;
	}

   	public boolean more() {
      	return ptr < buf.length;
   	}

   	public boolean more(boolean spacesCount) {
      	if(spacesCount) return more();
      	int p = ptr;
      	while(p < buf.length) {
         	if(Character.isWhitespace(buf[p]))
            	p++;
         	else
            	return true;
      	}
		return false;
	}

	public String nextWord(String delim, boolean stopOnSpace) {
		return nextWord(delim, stopOnSpace, false);
	}

   	public String nextWord(String delim, boolean stopOnSpace,
   		boolean useEscape) {
      	StringBuffer res = new StringBuffer();
      	while(
       	(ptr < buf.length) &&
       	(delim.indexOf(buf[ptr]) == -1) &&
       	!(Character.isWhitespace(buf[ptr]) && stopOnSpace))
      	{
      		if(useEscape && buf[ptr] == '\\')
      			ptr++;
         	res.append(buf[ptr]); ptr++;
      	}
      	return res.toString();
   	}
   	
   	public String nextSpace() {
		StringBuffer res = new StringBuffer();
      	while(ptr < buf.length && Character.isWhitespace(buf[ptr]))
        	res.append(buf[ptr++]);
        return res.toString();
 	}

	public boolean matchToken(String tok) {
		String prefix = new String(buf,ptr,buf.length-ptr);
      	if(prefix.startsWith(tok))
      	{
         	ptr += tok.length(); return true;
      	}
      	return false;
   	}

   	public void advance() {
    	if(ptr < buf.length) ptr++;
   	}

	public char peek() { return buf[ptr]; }

	public String rest() {
		return new String(buf,ptr,buf.length-ptr);
	}
}


