/*
  Written by Bruce Cooper.
*/
package jkk.java;

import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.Hashtable;

/**
  Class for scanning the binary representation of a class file.  Will load 
  the string constants, and generate a list of methods/fields and class 
  references.

  @author Bruce Cooper
  @version 0.0.2
*/
public class BinaryClass
{
   /**
      DO NOT EDIT THIS ENTRY: This is a VeriLib serial code stub.
   */
   private static final String o3SicR8ue = "$SCS$SERIAL$CODE$STR24$$";

   // Field types for the constant pool
   private static final int CONSTANT_Utf8 = 1;
   private static final int CONSTANT_Integer = 3;
   private static final int CONSTANT_Float = 4;
   private static final int CONSTANT_Long = 5;
   private static final int CONSTANT_Double = 6;
   private static final int CONSTANT_Class = 7;
   private static final int CONSTANT_String = 8;
   private static final int CONSTANT_FieldRef = 9;
   private static final int CONSTANT_MethodRef = 10;
   private static final int CONSTANT_InterfaceMethodRef = 11;
   private static final int CONSTANT_NameAndType = 12;
    
   // Magic Cookies
   private static final long MAGIC = 0xcafebabe;
   private static final int MAJOR_VERSION = 45;
   private static final int MINOR_VERSION = 3;
    
   // Accessor Flags
   public static final int ACC_PUBLIC = 0x0001;
   public static final int ACC_PRIVATE = 0x0002;
   public static final int ACC_PROTECTED = 0x0004;
   public static final int ACC_STATIC = 0x0008;
   public static final int ACC_FINAL  = 0x0010;
   public static final int ACC_SUPER  = 0x0020;
   public static final int ACC_VOLATILE  = 0x0040;
   public static final int ACC_TRANSIENT  = 0x0080;
   public static final int ACC_NATIVE  = 0x0100;
   public static final int ACC_INTERFACE = 0x0200;
   public static final int ACC_ABSTRACT = 0x0400;
   
   /** Major version number. */
   public int major;

   /** Minor version number. */
   public int minor;

   /** The Classes that are referenced from this class. */    
   public String[] referencedClasses;
    
   /** The name of this class. */
   public String className;
    
   /** The name of the SuperClass. */
   public String superClass;
    
   /** All of the interfaces that this class implements. */
   public String[] interfaces;
    
   /** Fields. */
   public Hashtable fields = new Hashtable();
    
   /** Methods. */
    public Hashtable methods = new Hashtable();
    
   /** The source file that generated this class. */
   public String sourceFile;
    
   /** 
      The modifiers for this class (PUBLIC, ABSTRACT, INTERFACE, etc...) 
   */
   public int modifiers;
    
   //////////////
   // Constructor

   /**
     Creates and initializes the class file from the supplied 
     InputStream.
     
     @param is The InputStream to load the class from.
    */
   public BinaryClass(InputStream is) throws IOException {
      DataInputStream dis = new DataInputStream(is);
      
      if (dis.readInt() != MAGIC)
         throw new IOException("Not a class file, no magic cookie");
         
      minor = dis.readUnsignedShort();
      major = dis.readUnsignedShort();

      // Constant Pool
      int constantCount = dis.readUnsignedShort();
      // Remember that the constantPool[0] is empty (doesn't exist)
      String[] strings = new String[constantCount];
      int[] classes = new int[constantCount];
      int nClasses = 0;
      
      classes[0] = 0;
      strings[0] = "java/lang/Object";
         
      for (int i = 1; i < constantCount; i++) {
         int tag = dis.readByte();
         switch(tag) {
            case CONSTANT_Utf8:
               strings[i] = dis.readUTF();
               break;
            case CONSTANT_Integer:
            case CONSTANT_Float:
               dis.skipBytes(4);
               break;
            case CONSTANT_Long:
            case CONSTANT_Double:
               i++;
               dis.skipBytes(8);
               break;
            case CONSTANT_String:
               dis.readUnsignedShort();
               break;
            case CONSTANT_Class:
               classes[i] = dis.readUnsignedShort();
               nClasses++;
               break;
            case CONSTANT_FieldRef:
            case CONSTANT_MethodRef:
            case CONSTANT_InterfaceMethodRef:
            case CONSTANT_NameAndType:
               dis.skipBytes(4);
               break;
            default:
               throw new IOException("Unknown Constant Pool index " + i + ", tag = " + tag);
         }
      }
      modifiers = dis.readUnsignedShort();
      className = strings[classes[dis.readUnsignedShort()]];
      int c = dis.readUnsignedShort();
      superClass = strings[classes[c]];

      // Interfaces
      int interfacesCount =  dis.readUnsignedShort();
      interfaces = new String[interfacesCount];
      for (int i = 0; i < interfacesCount; i++)
         interfaces[i] = strings[classes[dis.readShort()]];

      // Fields
      int fieldCount = dis.readShort();
      for (int i = 0; i < fieldCount; i++) {
         int fieldAccessFlags = dis.readUnsignedShort();
         String fieldName = strings[dis.readUnsignedShort()];
         String fieldType = strings[dis.readUnsignedShort()];
         
         int attributeCount = dis.readUnsignedShort();
         for (int j = 0; j < attributeCount; j++) {
            String attrName = strings[dis.readUnsignedShort()];
            int attrLength = dis.readInt();
            dis.skipBytes(attrLength);
         }
         fields.put(fieldName, new FieldRef(fieldAccessFlags, fieldName, fieldType));
      }

      // Methods
      int methodCount = dis.readShort();
      for (int i = 0; i < methodCount; i++) {
         int methodAccessFlags = dis.readUnsignedShort();
         String methodName = strings[dis.readUnsignedShort()];
         String methodType = strings[dis.readUnsignedShort()];
         boolean syntheticMethod = false;
         String[] exceptions = new String[0];
         
         int attributeCount = dis.readUnsignedShort();
         for (int j = 0; j < attributeCount; j++) {
            String attrName = strings[dis.readUnsignedShort()];
            int attrLength = dis.readInt();

            if (attrName.equals("Synthetic")) {
               syntheticMethod = true;
            } else if (attrName.equals("Exceptions")) {
               int nExceptions = dis.readUnsignedShort();

               exceptions = new String[nExceptions];
               for (int k = 0; k < nExceptions; k++) {
                  exceptions[k] = strings[classes[dis.readUnsignedShort()]];
               }
            } else  
               dis.skipBytes(attrLength);
         }
         if (!syntheticMethod) 
            methods.put(methodName, new MethodRef(methodAccessFlags, 
               methodName, methodType, exceptions));
      }

      // Attributes
      int attributeCount = dis.readUnsignedShort();
      for (int j = 0; j < attributeCount; j++) {
         String attrName = strings[dis.readUnsignedShort()];
         int attrLength = dis.readInt();

         if (attrName.equals("SourceFile")) {
            sourceFile = strings[dis.readUnsignedShort()];
         } else if (attrName.equals("InnerClasses")) {
            int nInnerClasses = dis.readUnsignedShort();

            for (int k = 0; k < nInnerClasses; k++) {
               int innerClassInfo = dis.readUnsignedShort();
               int outerClassInfo = dis.readUnsignedShort();
               String className = strings[dis.readUnsignedShort()];
               int accessFlags = dis.readUnsignedShort();
            }
         } else {
            dis.skipBytes(attrLength - 2);
         }
      }
       
      referencedClasses = new String[nClasses];
      int count = 0;
      for (int i = 0; i < classes.length; i++)
         if (classes[i] != 0)
            referencedClasses[count++] = strings[classes[i]];
   } // end of constructor
   
   public boolean isInterface() {
      return (modifiers & ACC_INTERFACE) != 0;
   }   

   ////////////
   // test main

   /**
     Simple test program to load a class and then display some info
     to stdout.
    */
   public static void main(String[] args) {
      if (args.length != 1) {
         System.err.println("Useage.  java BinaryClass classifle");
         System.exit(1);
      }
      try {
         BinaryClass c = new BinaryClass(new FileInputStream(args[0]));

         if (c.sourceFile != null)
            System.out.println("Source is " + c.sourceFile);
         System.out.println("SuperClass is " + c.superClass);
         for (Enumeration en = c.methods.keys(); en.hasMoreElements(); ) {
            String method = (String) en.nextElement();
            FieldRef ref = (FieldRef) c.methods.get(method);
            
            System.out.println("Method is " + ref);
         }
      } catch (IOException ex) {
         ex.printStackTrace();
      }
   } // end of main()
   
   /**
     Inner class representing a Field within a method.
    */
   public static class FieldRef {
      public String name;
      public int modifiers;
      public String type;
       
      public FieldRef(int mods, String name, String type) {
         modifiers = mods;
         this.name = name;
         this.type = type;
      }
      
      public boolean isPublic() {
         return (modifiers & ACC_PUBLIC) != 0;
      }
      public boolean isStatic() {
         return (modifiers & ACC_STATIC) != 0;
      }
      
      public boolean isAbstract() {
         return (modifiers & ACC_ABSTRACT) != 0;
      }
      
      public boolean isFinal() {
         return (modifiers & ACC_FINAL) != 0;
      }
      
      protected String modsToString() {
         StringBuffer sb = new StringBuffer();
         
         if (isPublic())
            sb.append("public ");
         if (isAbstract())
            sb.append("abstract ");
         if (isFinal())
            sb.append("final ");
         return sb.toString();
         
      }
      
      public String toString() {
         return modsToString() + ' ' + typeToString(type, 0) + ' ' + name;
      }
      
      protected String typeToString(String str, int pos) {
         switch (type.charAt(pos)) {
            case 'B':
               return "byte";
            case 'C':
               return "char";
            case 'D':
               return "double";
            case 'F':
               return "float";
            case 'I':
               return "int";
            case 'J':
               return "long";
            case 'S':
               return "short";
            case 'Z':
               return "boolean";
            case 'L':
               int endpos = type.indexOf(';', pos);
               return type.substring(pos+1,endpos).replace('/', '.');
            case 'V':
               return "void";   
            case '[':
               return typeToString(str, pos+1) + "[]";
            default:
               return "Unknown Type " + type.charAt(pos);
         }
      }
   }

   /**
     Inner class representing a Method within a class
    */   
   public static class MethodRef extends FieldRef {
      String[] exceptions;

      public MethodRef(int mods, String name, String type, String[] exceptions) {
         super(mods, name, type);
         this.exceptions = exceptions;
      } 
      
      public String toString() {
         int endBracketPos = type.lastIndexOf(')');
         StringBuffer sb = new StringBuffer(modsToString());
         sb.append(typeToString(type, endBracketPos +1));
         sb.append(' ');
         sb.append(name);
         sb.append("(");
         int pos = 1;
         while (pos < endBracketPos) {
            if (pos != 1)
               sb.append(", ");
            char ch = type.charAt(pos);
            String p = typeToString(type, pos++);
            sb.append(p);
            if (ch == '[') {
               pos = type.indexOf(';', pos) + 1;
            } else if (ch == 'L')
               pos += p.length() + 1;
         }
         sb.append(')');

         if (exceptions.length > 0) {
            sb.append(" throws ");
            for (int i = 0; i < exceptions.length; i++) {
               sb.append(exceptions[i]);

               if (i < exceptions.length -1)
                  sb.append(", ");
            }

         }
         return sb.toString();
      }
   }

}// end of BinaryClass
