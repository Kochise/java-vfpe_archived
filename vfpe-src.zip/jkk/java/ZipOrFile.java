/* Written by Bruce Cooper */

package jkk.java;

import java.io.*;
import java.util.zip.*;
import java.util.*;

/**
  A wrapper to both File and ZipFile so that you can use both from the
  same interface.<P> <strong> Bug:<strong> I think the leaves a bunch of
  ZipFiles open. This comes from the necessity of getting several
  subentries from a zipFile before you can close it. You could do some
  sort of weak Hash I suppose, but that would remove the 1.1 dependency.
*/
public class ZipOrFile
{
   /**
      DO NOT EDIT THIS ENTRY: This is a VeriLib serial code stub.
   */
   private static final String sGZI8NcMF = "$SCS$SERIAL$CODE$STR24$$";

	/**
	  Either the file we refer to, or the Zip which is the base  
	 */
	File f;
	/**
	  The entry in the zip file, or null if we are dealing with a file
	 */
	String entry;
	
	/**
	  Hash of the zips that have been opened by this class.  They should be closed
	  when they are no longer needed.  ARGH!!!
	 */
	private static Hashtable zips = new Hashtable();
	
	/**
	  This constructor just sets it up as a file reference.
	 */
	public ZipOrFile(File base) {
		f = base;
		
		// We will always start with a File.
		entry = null;
	}
	
	/**
	  Creates a ZipOrFile Reference from an Existing ZipOrFile, and then
	  a subEntry.
	 */
	public ZipOrFile(ZipOrFile base, String entry) {
		if (base.f.isDirectory())
			f = new File(base.f, entry);
		else {
			f = base.f;
			if (base.entry != null)
				entry = base.entry + File.separator + entry;
			else
				this.entry = entry;
		}	
	}
	
	
	/** 
	 @return the ZipFile which corresponds to the base file 
	 */
	private ZipFile getZip() throws IOException {
		ZipFile zip = (ZipFile) zips.get(f);
		if (zip == null) {
			zip = new ZipFile(f);
			zips.put(f, zip);
		}
		return zip;
	}
	
	
	/**
	  @return true if the file exists, or the entry exists within the zipfile.
	 */
	public boolean exists() {
		if (entry != null) {
			if (!f.exists())
				return false;
			try {
				ZipFile zip = getZip();
				return zip.getEntry(entry) != null;
			} catch (IOException ex) {
				ex.printStackTrace();
				return false;
			}
		} else {
			return f.exists();
		}
	}
	
	/**
	  Lists all Subentries within this ZipOrFile.
	 */
	public ZipOrFile[] list() throws IOException {
		ZipOrFile[] result;
		
		if (f.isDirectory()) {
			String[] files = f.list();
			result = new ZipOrFile[files.length];
			for (int i = 0; i < files.length; i++)
				result[i] = new ZipOrFile(this, files[i]);
		} else {
			Vector v = new Vector();
			ZipFile zip = getZip();
			Enumeration en = zip.entries();
			
			while (en.hasMoreElements()) {
				String name = ((ZipEntry) en.nextElement()).getName();
				if (name.length() > entry.length() && name.startsWith(entry))
					v.addElement(name);
			}
			
			result = new ZipOrFile[v.size()];
			for (int i = 0; i < v.size(); i++) {
				String newEntry = v.elementAt(i).toString().substring(entry == null ? 0 : entry.length());
				result[i] = new ZipOrFile(this, newEntry);
			}
		}
		return result;
	}
	
	/**
	  @reuturns an InputStream for this reference.  The caller is responsible for
	  ensuring that the input stream is closed.
	 */
	public InputStream open() throws IOException {
		InputStream is;
		
		if (entry == null)
			is = new FileInputStream(f);
		else {
			ZipFile zip = getZip();
			ZipEntry e = zip.getEntry(entry);
			
			is = e == null ? null : zip.getInputStream(e);
		}
		
		return is;
	}
	
}

