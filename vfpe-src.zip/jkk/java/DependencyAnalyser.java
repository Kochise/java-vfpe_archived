/*
  By Bruce Cooper.
*/

package jkk.java;

import java.io.File;
import java.io.InputStream;
import java.io.IOException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.StringTokenizer;
import java.util.Vector;

import jkk.java.BinaryClass;
import jkk.java.ZipOrFile;

/**
   This tool finds the transitive closure of class files referenced by
   a set of root classes.
   <p>
   Loads classes from the class path you provide it, and then adds each of
   the classes it references.  
   <p>
   Classes are added using addClass(), and the final Iterator of class names
   can be retrieved by getClasses().  A set of classes which should have been
   found (they were referenced and not explicitly exlcuded) but weren't
   can be retrieved by getMissingClasses().

   @author Bruce Cooper
   @version 0.0.2
*/
public class DependencyAnalyser
{
   /**
      DO NOT EDIT THIS ENTRY: This is a VeriLib serial code stub.
   */
   private static final String sb5HeJ6AH = "$SCS$SERIAL$CODE$STR24$$";

   /////////
   // Fields
   
   /**
      The set that contains the classes that have already been checked. This
      is used to both ensure that a class is not added twice, and the contents
      are returned as the results using getClasses();
   */
   protected HashSet classes = new HashSet();

   /**
      The set of classes that should have been found (ie they were referenced
      and not explicitly excluded) but weren't.
   */
   protected HashSet missingClasses = new HashSet();
   
   /** The ClassPath that we are using.  Set using setClassPath(). */
   protected ZipOrFile[] classPath;
   
   /**
      An array of strings which specify what classes to ignore, or include, 
      depending on the value of acceptMode.  Each entry will be a string 
      prefix which is compared to a candidate class name. 
   */
   protected String[] prefixes;
   
   /**
      The accept mode to use.  Will be one of ACCEPT_ALL_BUT_PREFIXES or 
      ACCEPT_ONLY_PREFIXES.
   */
   protected int acceptMode = ACCEPT_ALL_BUT_PREFIXES;
   
   /**
      Accept mode which specifies that all classes will be accepted except for
      those which have prefixes from one of the entries in prefixes[]
   */
   public static final int ACCEPT_ALL_BUT_PREFIXES = 0;
   
   /**
      Accept mode which specifies that only classes which have a prefix of one of
      the entries in prefixes[] will be accepted.
   */
   public static final int ACCEPT_ONLY_PREFIXES = 1;
   
   /**
      The default prefixes to use for the zero arg constructor.  Prefixes
      included are "java", "javax" and "[" (for arrays).
   */
   private static String[] defaultPrefixes = { "javax.", "java.", "[" };
   
   //////////////
   // Constructor

   /**
      Standard Constructor which sets up the Dependency Analyser with the VM's 
      classpath, the default prefixes, and in ACCEPT_ALL_BUT_PREFIXES mode.
   */
   public DependencyAnalyser() 
   {
      this(System.getProperty("java.class.path"), defaultPrefixes, 
         ACCEPT_ALL_BUT_PREFIXES);
   }
   
   /**
      Sets up the Dependency Analyser with the specified paramaters. Each can be
      overridden later by using the appropriate method.
      @param classPath the classPath to use.
      @param prefixes the prefixes to use
      @mode the prefix mode to use.  One of ACCEPT_ALL_BUT_PREFIXES, and
         ACCEPT_ONLY_PREFIXES
   */
   public DependencyAnalyser(String classPath, String[] prefixes, int mode) 
   {
      setClassPath(classPath);
      setPrefixes(prefixes);
      setAcceptMode(mode);
   }
   
   /////////////////
   // Primary method

   /**
      Adds a class, and all of it's referenced classes to the internal list
      of classes.   This is the main method for this class.
      @param className the name of the class to add.
   */
   public void addClass(String className) throws IOException 
   {
      if (classes.contains(className))
         return; 

      // Find the class file
      ZipOrFile classFile = getFileForClass(className);
      
      if (classFile != null) 
      {
         // Add the class to the list
         classes.add(className);
         
         // Scan the class file for it's referenced classes
         InputStream is = classFile.open();
         BinaryClass cl = new BinaryClass(is);
         
         // As long as the prefixes say we can, call addClass on each of
         // the referenced classes.
         for (int i = 0; i < cl.referencedClasses.length; i++) 
         {
            String refClass = cl.referencedClasses[i].replace('/', '.');
            if(classMatchesPrefixes(refClass) ^ acceptMode == ACCEPT_ALL_BUT_PREFIXES)
               addClass(refClass);
         }
         is.close();
      } else {
         if(!missingClasses.contains(className))
            missingClasses.add(className);
      }
   } // end of addClass()
   
   /**
     @return true if the specified class Name has a prefix of one of the
     specified prefixes.
     @param className the Name of the class to test.
   */
   protected boolean classMatchesPrefixes(String className) 
   {
      for (int i = 0; i < prefixes.length; i++)
         if (className.startsWith(prefixes[i]))
            return true;
      return false;
   }
   
   ////////////////////////
   // Configuration methods

   /**
      Sets the classpath that is used for loading .class files.  May contain Zips and
      Directories, and is separated by the normal separator, just like the standard 
      Java classpath.  
      @param cp the classpath to use.
   */
   public void setClassPath(String cp) 
   {
      StringTokenizer st = new StringTokenizer(cp, System.getProperty("path.separator"));
      classPath = new ZipOrFile[st.countTokens()];
      for (int i = 0; st.hasMoreTokens(); i++) {
         String cpe = st.nextToken();
         classPath[i] = new ZipOrFile(new File(cpe));
      }
   }

   /**
      Sets the prefixes that are used for scanning classes.  Prefixes will either
      be used to accept or deny class matches, depending on what the Accept mode is.
      @param prefixes The Prefixes to use
   */
   public void setPrefixes(String[] prefixes) 
   {
      this.prefixes = prefixes;
   }
   
   /** 
      Sets the accept mode that is used.  
      @param mode The accept mode to use.  Must be one of ACCEPT_ALL_BUT_PREFIXES or
         ACCEPT_ONLY_PREFIXES .
   */
   public void setAcceptMode(int mode) 
   {
      acceptMode = mode;
   }

   ///////////////////////////
   // Result returning methods

   /**
      @return an enumeration of the classes that have been saved by the addClass()
      method.  This is the results method for this class.
   */
   public Iterator getClasses() 
   {
      return classes.iterator();
   }   
   
   ///////////////////
   // Internal methods

   /**
      Returns the Zip or the File for the specified Class Name, or null if it
      can't find it on the classpath.
      @param className the Class to look up.
   */   
   protected ZipOrFile getFileForClass(String className) 
   {
      String translatedClassName = className.replace('.', File.separatorChar) + ".class";
      for (int i = 0; i < classPath.length; i++) 
      {
         ZipOrFile z = new ZipOrFile(classPath[i],  translatedClassName);
         if (z.exists())
            return z;
      }
      return null;
   }

   /**
      Splits up a string which is delimited by the standard path separator (; or : 
      depending on your OS) and turns it into an array of Strings.
      @param toSplit the string to split.
      @return the split string.
   */   
   protected static String[] splitString(String toSplit) 
   {
      StringTokenizer st = new StringTokenizer(toSplit, System.getProperty("path.separator"));
      String[] result = new String[st.countTokens()];
      for (int i = 0; st.hasMoreTokens(); i++) {
         result[i] = st.nextToken();
      }
      return result;
   }

   /**
      Main routine for scanning classes as a program.<P>
      Available switches
      <DL>
      <DD> -classpath </DD>
      <DT> Sets the classpath to use for looking for classes </DT>
      <DD> -prefix </DD>
      <DT> Sets the prefixes to use (: or ; separated) and sets the
           accept mode to ACCEPT_ONLY_PREFIXES </DT>
      <DD> -notprefix </DD>
      <DT> Sets the prefixes to use (: or ; separated) and sets the
           accept mode to ACCEPT_ALL_BUT_PREFIXES </DT>
      <DD> -help </DD>
      <DT> Shows Help </DT>
      </DL>
   */   
   public static void main(String[] args) 
   {
      DependencyAnalyser d = new DependencyAnalyser();
      Vector classesToParse = new Vector();
      
      for(int i = 0; i < args.length; i++) 
      {
         if(args[i].charAt(0) == '-') 
         {
            if(args[i].equals("-prefix")) 
            {
               d.setPrefixes(splitString(args[++i]));
               d.setAcceptMode(ACCEPT_ONLY_PREFIXES);
            } 
            else if(args[i].equals("-notprefix")) 
            {
               d.setPrefixes(splitString(args[++i]));
               d.setAcceptMode(ACCEPT_ALL_BUT_PREFIXES);
            } 
            else if(args[i].equals("-classpath")) 
            {
               d.setClassPath(args[++i]);
            } 
            else 
            {
               System.err.println("Unknown option " + args[i]);
               System.exit(1);
            }
         } 
         else 
            classesToParse.addElement(args[i]);
      }
      
      for(Iterator en = classesToParse.iterator(); en.hasNext();) 
      {
         try {
            d.addClass((String) en.next());
         } catch (IOException ex) {
            System.err.println(ex.getMessage());
         }
      }
         
      for (Iterator en = d.getClasses(); en.hasNext(); ) 
      {
         String className = (String) en.next();
         System.out.println(className);
      }
   }
} // end of DependancyAnalyser
