/*
    * * * * * software from the house of J Kyle Kelso
    * **  ** 
  *** * * * * copyright 1999
*/

package jkk;

public interface Relation {
	public abstract boolean related(Object a, Object b);
}
