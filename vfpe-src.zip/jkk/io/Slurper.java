/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1999
*/

package jkk.io;

import java.io.InputStream;
import java.io.IOException;

public class Slurper extends Thread {

	private byte [] data;
	private InputStream is;
	public IOException ioe;

	public Slurper(InputStream is) { this.is = is; }

	public void run() {
		try {
			data = Lib.slurpStream(is);
		} catch(IOException ex) {
			data = null; ioe = ex;
		}
		synchronized (this) {
			notifyAll();
		}
	}

	public byte [] getData() { return data; }
}
