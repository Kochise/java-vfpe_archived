/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1996-1997
*/

package jkk.io;

import java.io.*;
import java.net.URL;
import java.util.Vector;

public class Lib {

	private static int bufSize = 4096;

	public static byte [] slurpStream(InputStream is)
		throws IOException	{
		Vector bits = new Vector();
	   	int totalsize = 0;
	   	int r;
	   
	   	/* fill a list of buffers */
	   
	   	byte [] tmp;
	   	while((r = fillBuffer(is,tmp = new byte[bufSize])) == bufSize) {
	    	totalsize += r;
	      	bits.addElement(tmp);
	   	}
	   	totalsize += r;
	   
	   	/* build big array */
	   
	   	byte [] retArray = new byte[totalsize];
	   	int offset = 0;
	   	for(int i=0;i < bits.size();i++)
	   	{
	    	byte [] src = (byte [])bits.elementAt(i);
	      	System.arraycopy(src,0,retArray,offset,src.length);
	      	offset += src.length;
	   	}
	   	System.arraycopy(tmp,0,retArray,offset,r);
	   
	   	/* return it */
	   
		return retArray;
	}
	
	public static int fillBuffer(InputStream is, byte [] buf)
	throws IOException
	{
	   int offset = 0, r = 0;
	   while(offset < buf.length && r != -1)
	   {
	      r = is.read(buf,offset,buf.length-offset);
	      if(r >= 0) offset += r;
	   }
	   return offset;
	}
	
	public static long getFileSize(String fname) {
		return new File(fname).length();
	}

	/**
		Warning this does nothing if the strings are equal. Will only delete
		old file if new one is succefully written.
	*/
	public static void moveFile(String old, String n) throws IOException {
		if(old.equals(n)) return;
		byte [] b = fileToByteArray(old);
		if(b == null)
			throw new IOException("couldn't load file " + old);
		byteArrayToFile(n,b);
		File oldF = new File(old);
		oldF.delete();
	}

	public static byte [] resourceToByteArray(String rname, Class cl) {
		try {
			InputStream is = cl.getResourceAsStream(rname);
			byte [] b = slurpStream(is); is.close();
			return b;
		} catch(IOException ioe) {
			return null;
		}
	}

	public static byte [] resourceToByteArray(String rname) {
		try {
			InputStream is = ClassLoader.getSystemResourceAsStream(rname);
			byte [] b = slurpStream(is); is.close();
			return b;
		} catch(IOException ioe) {
			return null;
		}
	} 

	public static String resourceToString(String rname, Class cl) {
		byte [] ba = resourceToByteArray(rname,cl);
		if(ba == null) return null;
		return byteArrayToString(ba);
	}

	public static String resourceToString(String rname) {
		byte [] ba = resourceToByteArray(rname);
		if(ba == null) return null;
		return byteArrayToString(ba);
	}

	public static byte [] URLToByteArray(URL url) {
		try {
			InputStream is = url.openStream();
			byte [] bytes = slurpStream(is);
			is.close();
			return bytes;
		} catch(IOException ioe) {
			return null;
		}
	}

	public static String URLToString(URL url) {
		byte [] bytes = URLToByteArray(url);
		if(bytes == null) return null;
		return byteArrayToString(bytes);
	}

	public static byte [] fileToByteArray(String filename) {
		try {
      		FileInputStream fs = new FileInputStream(filename);
      		byte [] bytes = slurpStream(fs);
      		fs.close();
      		return bytes;
      	} catch(IOException ioe) {
      		return null;
      	}
   	}

   	public static void byteArrayToFile(String filename, byte [] bytes)
   		throws IOException {
		byteArrayToFile(filename,bytes,false);
   	}
   	
   	public static void byteArrayToFile(String filename, byte [] bytes,
   		boolean mds) 
   		throws IOException {
   		File f = new File(filename);
   		String fps = f.getParent();
   		if(fps != null) {
   			File fp = new File(fps);
   			if(mds && fp != null && !fp.exists()) {
				fp.mkdirs();
   			}
   		}
   		FileOutputStream fos = new FileOutputStream(filename);
   		fos.write(bytes); fos.flush(); fos.close();
   	}
   	
   	public static String byteArrayToString(byte [] bytes) {
   		StringBuffer buf = new StringBuffer();
   		try {
   			ByteArrayInputStream bais = new ByteArrayInputStream(bytes);
   			LineNumberReader lnr = new LineNumberReader(
   				new InputStreamReader(bais,"UTF8"));
   			String s = null;
   			while((s = lnr.readLine()) != null) {
   				buf.append(s); buf.append("\n");
   			}
   		} catch(IOException ioe) {
   			return null;
   		}
   		return buf.toString();
   	}
   	
   	public static byte [] stringToByteArray(String s) {
   		try {
   			ByteArrayOutputStream baos = new ByteArrayOutputStream();
   			OutputStreamWriter osw = new OutputStreamWriter(baos,"UTF8");
   			osw.write(s,0,s.length()); osw.flush();
   			return baos.toByteArray();
   		} catch(IOException ioe) {
   			return null;
   		}
   	}
   	
   	public static Object byteArrayToObject(byte [] bytes) {
   		try {
   			ByteArrayInputStream bis = new ByteArrayInputStream(bytes);
   			ObjectInputStream ois = new ObjectInputStream(bis);
   			return ois.readObject();
   		} catch(IOException ioe) {
   			return null;
   		} catch(ClassNotFoundException cnfe) {
   			return null;
   		}
   	}
   	
   	public static byte [] objectToByteArray(Object o) {
   		try {
   			ByteArrayOutputStream baos = new ByteArrayOutputStream();
   			ObjectOutputStream oos = new ObjectOutputStream(baos);
   			oos.writeObject(o); oos.flush();
   			return baos.toByteArray();
   		} catch(IOException ioe) {
//DEBUG
System.err.println("serialisation error: " + ioe);
   			return null;
   		}
   	}

   	public static void appendStringToFile(String fname, String s)
   		throws IOException {
		FileOutputStream fos = new FileOutputStream(fname,true);
		byte [] bs = stringToByteArray(s);
		fos.write(bs);
		fos.flush(); fos.close();
   	}
   			
   	/* Could write efficient version of these */
   	public static String fileToString(String fname) {
   		byte [] bs = fileToByteArray(fname);
   		if(bs == null) return null;
   		return byteArrayToString(bs);
   	}
   	
   	public static void stringToFile(String fname, String s) 
   		throws IOException {
   		byteArrayToFile(fname, stringToByteArray(s));
   	}

   	public static Object fileToObject(String fname) {
   		byte [] bs = fileToByteArray(fname);
   		if(bs == null) return null;
		return byteArrayToObject(bs);
   	}

   	public static void objectToFile(String fname, Object o)
   		throws IOException {
		byteArrayToFile(fname, objectToByteArray(o));
   	}
 		
	/**
		Returns new byte array, same as old up to smaller of two sizes.
      	This _must_ be in a standard library somewhere.
      	@param old byte array
      	@param int size of new byte array
      	@return new byte array
	*/
	public static byte [] resize(byte [] old, int size) {
       	byte [] tmp = new byte[size];
       	int datalen = Math.min(size,old.length);
       	for(int i=0;i < datalen;i++)
        	  tmp[i] = old[i];
       	return tmp;
   	}    		
}
