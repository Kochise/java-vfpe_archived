/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1998
*/

package jkk.io;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.Vector;

import jkk.Comparator;

public class SerialLib {

	public static Comparator fCompare;
	
	static {
		fCompare = new FieldComparator();
	}
	
	public static void main(String [] argv) {
		Class c = null;
		try {
			c = Class.forName(argv[0]);
		} catch(ClassNotFoundException cnfe) { 
			System.out.println(cnfe);
		}
		Vector fs = getAllFields(c,false);
		for(int i=0;i < fs.size();i++) {
			Field f = (Field)fs.elementAt(i);
			System.out.println(f.getName() + " : " + 
				Modifier.toString(f.getModifiers()));
		}
	}
	
	public static Vector getAllFields(Class c, boolean includeStatic) {
		Vector fields = new Vector();
		while(c != null) {
			Field [] fs = c.getDeclaredFields();
			for(int i=0;i < fs.length;i++)
				if(!Modifier.isStatic(fs[i].getModifiers()) || includeStatic)
					fields.addElement(fs[i]);
			c = c.getSuperclass();
		}
		return fields;
	}
}

class FieldComparator implements Comparator {
	public int compare(Object a, Object b) {
		return ((Field)a).getName().compareTo(((Field)b).getName());
	}
}
