/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1998
*/

package jkk.io;

import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Stack;
import java.util.Vector;

import jkk.Counter;
import jkk.text.Writer;
import jkk.text.ListWriter;

public class Serialiser {

	/* test main */
	
	public static void main(String [] argv) {
		System.setSecurityManager(new SecMan());
		Object [] o = new Object[10];
		Object o2 = new Integer(42);
		o[0] = o; o[1] = o2;
		Serialiser s = new Serialiser();
		s.numbers.put(o,s.genSym.next());
		java.io.StringWriter sw = null;
		try {
			sw = new java.io.StringWriter();
			s.writeObjectData(o,sw);
		} catch(IllegalAccessException iae)  {
			System.out.println("IllegalAccess: " + iae);
			iae.printStackTrace();
		} catch(IOException ioe) {
			System.out.println("IOException");
		}
		try {
			s.writeHeader(sw);
		} catch(IllegalAccessException iae) {
			System.out.println("IllegalAccess");
		} catch(IOException ioe) {
			System.out.println("IOException");
		}
		String os = sw.toString();
		System.out.println(os);
		
	}

	/* constants ------------------------------------------------- */

	private static final boolean INCLUDE_FIELD_ORDER = true;
	public static final String CLASS_PART_TAG = "class";
	public static final String OBJECT_PART_TAG = "objects";
	public static final String SECTION_INDENT = "    ";
	public static final String OBJECT_INDENT = "        ";

	/* public fields --------------------------------------------- */
	
	public boolean includeTransients;
	public Hashtable articulationPoints;

	/* private fields -------------------------------------------- */
	
	private Hashtable numbers;
	private Stack work;
	private Hashtable classInfo;
	private Counter genSym;
	private static Writer serWriter;
	
	static {
		serWriter = new ListWriter(new SerialWriter());
	}

	/* constructors ---------------------------------------------- */
	
	public Serialiser() {
		this(new Hashtable(),false);
	}

	public Serialiser(Hashtable aps, boolean itrans) {
		includeTransients = itrans;
		articulationPoints = aps;
		reset();
	}

	public void reset() {
		numbers = new Hashtable();
		work = new Stack();
		classInfo = new Hashtable();
		genSym = new Counter();
	}

	/* entry points ---------------------------------------------- */

	public String serialise(Object o) {
		return "";
	}

	public void writeObjectData(Object obj, java.io.Writer out)
		throws IllegalAccessException, IOException {

		/* write object data header */

		int rootNum = genSym.next().intValue();
		out.write(SECTION_INDENT);
		out.write('(');
		out.write(OBJECT_PART_TAG);
		out.write(' ');
		out.write(Integer.toString(rootNum));

		/* initialise */
		
		numbers.put(obj,new Integer(rootNum));
		work.push(obj);

		/* work loop */

		Object o;
		while(!work.isEmpty()) {
			o = work.pop();
			int n = ((Integer)numbers.get(o)).intValue();
			Class c = o.getClass();
			if(!classInfo.containsKey(c))
				buildClassInfo(c,INCLUDE_FIELD_ORDER);
			ClassInfo ci = (ClassInfo)classInfo.get(c);

			out.write('\n');
			out.write(OBJECT_INDENT);
			out.write('(');
			out.write(Integer.toString(n));	out.write(' ');
			out.write(ci.lName); out.write(' ');
			if(c.isArray()) {
				Class cc = c.getComponentType();
				if(!classInfo.containsKey(cc))
					buildClassInfo(cc,INCLUDE_FIELD_ORDER);
				ClassInfo cci = (ClassInfo)classInfo.get(cc);
				out.write(cci.lName); out.write(' ');
				int l = Array.getLength(o);
				out.write(Integer.toString(l));
				for(int i=0;i < l;i++) {
					out.write(' ');
					out.write(writeValue(Array.get(o,i),cc));
				}
			} else {
				Vector fs = ci.fields;
				for(int i=0;i < fs.size();i++) {
					Field f = (Field)fs.elementAt(i);
					out.write(' ');
					if(!includeTransients &&
						Modifier.isTransient(f.getModifiers()))
						out.write("-1");
					else
						out.write(writeValue(f.get(o),f.getType()));
				}
			}
			out.write(')');
		} // end of while-more-work

		out.write(')');
	} // end of method

	public void writeHeader(java.io.Writer out)
		throws IllegalAccessException, IOException {

		/* write object data header */

		int rootNum = genSym.next().intValue();
		out.write(SECTION_INDENT);
		out.write('(');
		out.write(CLASS_PART_TAG);

		/* write class data */

		Enumeration e = classInfo.elements();
		while(e.hasMoreElements()) {
			ClassInfo ci = (ClassInfo)e.nextElement();
			out.write('\n');
			out.write(OBJECT_INDENT);
			out.write(ci.output);
		}

		out.write(')');
	}

	/* inner workings -------------------------------------------- */
	
	private String writeValue(Object o, Class c) {
		if(o == null) {
			return "-1";
		} else if(c.isPrimitive()) {
			return o.toString();
		} else {
			Integer i;
			if(articulationPoints.containsKey(o)) {
				i = (Integer)articulationPoints.get(o);
			} else if(!(numbers.containsKey(o))) {
				i = new Integer(genSym.next().intValue());
				numbers.put(o,i);
				work.push(o);
			} else {
				i = (Integer)numbers.get(o);
			}
			return "o"+(Math.abs(i.intValue()));
		}
	}
	
	private void buildClassInfo(Class c, boolean includeFieldOrder) 
		throws IllegalAccessException {
		Vector v = new Vector();
		v.addElement(c.getName());
		
		String lName = "c" + genSym.next();
		v.addElement(lName);
		
		Field id = null;
		try {
			id = c.getField("serialVersionUID");
		} catch(NoSuchFieldException nsfe) {
			id = null;
		}
		if(id == null)
			v.addElement("-1");
		else 
			v.addElement(Long.toString(id.getLong(c)));
			
		Vector fs = SerialLib.getAllFields(c,false);
		jkk.Lib.slowSort(fs,SerialLib.fCompare,true);
		if(includeFieldOrder)
			v.addElement(fs);
			
		classInfo.put(c,new ClassInfo(lName,fs,serWriter.write(v)));
	}

}

class ClassInfo {
	public String lName;
	public Vector fields;
	public String output;
	public ClassInfo(String lName, Vector fields,String output) {
		this.lName = lName; this.fields = fields; this.output = output;
	}
	
}

class SerialWriter implements Writer {
	
	public SerialWriter() { }
	
	public String write(Object o) {
		if(o instanceof Field)
			return ((Field)o).getName();
		return o.toString();
	}
}

class SecMan extends SecurityManager {

	public void checkMemberAccess(Class cs, int which) {

	}
}
