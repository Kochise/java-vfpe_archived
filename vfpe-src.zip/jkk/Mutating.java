/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 2001
*/

package jkk;

import java.util.Random;

public interface Mutating {
    public void mutate(Random rand);
    public void setSpec(String spec);
    public String getSpec();
    public boolean validateSpec(String spec);
}
