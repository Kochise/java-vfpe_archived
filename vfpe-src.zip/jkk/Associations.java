/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1999-2000
*/

package jkk;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import jkk.text.Lib;

public class Associations extends Hashtable {

	//////////////
	// constructor

	public Associations() { super(); }

	// constructor using jkk.text list parsing
	public Associations(String spec) {
		Vector v = (Vector)Lib.parseList(spec);
		add(v);
	}

	// alternating vector constructor
	public Associations(Vector v) { add(v); }

	public void add(Vector v) {
		for(int i=0;i < v.size()/2;i++)
			put(v.elementAt(2*i),v.elementAt(2*i+1));
	}

	////////
	// tools

	public void update(Associations newData) {
		Enumeration e = newData.keys();
		while(e.hasMoreElements()) {
			Object key = e.nextElement();
			put(key,newData.get(key));
		}
	}
	
	///////////////////
	// projection tools

	public String getString(Object key) { return (String)get(key); }

	public String getString(Object key, String def) {
		if(!containsKey(key)) return def;
		return getString(key);
	}

	public boolean getBoolean(Object key) {
		String b = getString(key);
		return Boolean.valueOf(b).booleanValue();
	}

	public boolean getBoolean(Object key, boolean def) {
		if(!containsKey(key)) return def;
		return getBoolean(key);
	}
	
	public int getInt(Object key) {
		return ((Long)get(key)).intValue();
	}

	public int getInt(Object key, int def) {
		if(!containsKey(key)) return def;
		return getInt(key);
	}

	public long getLong(Object key) {
		return ((Long)get(key)).longValue();
	}

	public long getLong(Object key, long def) {
		if(!containsKey(key)) return def;
		return getLong(key);
	}

	public double getDouble(Object key) {
		return ((Double)get(key)).doubleValue();
	}

	public double getDouble(Object key, double def) {
		if(!containsKey(key)) return def;
		return getDouble(key);
	}

	public Vector getVector(Object key) { return (Vector)get(key); }

	///////////
	// printing

	public String format(int indent, int keyWidth) {
		return format(indent,keyWidth,jkk.Lib.objComp);
	}

	public String format(int indent, int keyWidth, Comparator keyCompare) {
		StringBuffer buf = new StringBuffer();
		Object [] ks = jkk.Lib.sortOnKeys(this,keyCompare);
		for(int i=0;i < ks.length;i++) {
			buf.append("\n");
			buf.append(Lib.spaces(indent));
			buf.append(Lib.justify(Lib.printList(ks[i]),keyWidth,Lib.LEFT));
			buf.append(" ");
			buf.append(Lib.printList(get(ks[i])));
		}
		return buf.toString();
	}
}

