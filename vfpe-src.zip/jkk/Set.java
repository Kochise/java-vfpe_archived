/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1996-1997
*/

package jkk;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

public class Set extends Hashtable {
    
    // constructors ------------------------------------------------------------

    // empty set
    public Set() { super(); }

    // singleton
    public Set(Object key, Object val) { super(); put(key,val); }

    public Set(Hashtable t) {
        this();
        Enumeration e = t.keys();
        while(e.hasMoreElements()) {
            Object k = e.nextElement();
            put(k,t.get(k));
        }
    }

    public Set(Vector v) {
        this();
        for(int i=0;i < v.size();i++) {
            Object o = v.elementAt(i);
            put(o,o);
        }
    }

    // tools -------------------------------------------------------------------

    public boolean elem(Object e) { return containsKey(e); }

    public boolean hasSubset(Set s) {
        Enumeration e = s.keys();
        while(e.hasMoreElements())
            if(!elem(e.nextElement()))
                return false;
        return true;
    }

    public Object choose() {
        if(isEmpty())
            return null;
        return keys().nextElement();
    }

    /* functional (ie non-mutating) operations */

    /* takes values from last added set */
    public Set union(Set s) {
        Set newSet = new Set();
        newSet.add(this); newSet.add(s); return newSet;
    }

    /* this uses the values from "this" set */
    public Set intersection(Set s) {
        Set newSet = new Set();
        Enumeration e = this.keys();
        while(e.hasMoreElements()) {
            Object x = e.nextElement();
            if(s.containsKey(x))
                newSet.put(x,this.get(x));
        }
        return newSet;
    }

    public Set difference(Set s) {
        Set newSet = (Set)this.clone();
        newSet.subtract(s); return newSet;
    }

    public Vector vectorise() {
        Vector v = new Vector(); Enumeration e = this.keys();
        while(e.hasMoreElements())
            v.addElement(e.nextElement());
        return v;
    }

    /* mutating operators */

    public void add(Set s) {
        Enumeration e = s.keys();
        while(e.hasMoreElements()) {
            Object x = e.nextElement(); put(x,s.get(x));
        }
    }

    public void subtract(Set s) {
        Enumeration e = s.keys();
        while(e.hasMoreElements())
            remove(e.nextElement());
    }

    /* does this have the moving target problem ? */
    public void intersect(Set s) {
        Enumeration e = this.keys();
        while(e.hasMoreElements()) {
            Object x = e.nextElement(); 
            if(!s.containsKey(x))
                remove(x);
        }
    }

    public String toString() {
        Enumeration e = keys();
        StringBuffer buf = new StringBuffer();
        buf.append("{");
        while(e.hasMoreElements()) {
            buf.append(' '); buf.append(e.nextElement().toString());
        }
        buf.append(" }"); return buf.toString();
    }
}
