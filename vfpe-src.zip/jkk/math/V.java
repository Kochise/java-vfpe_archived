/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1996-1999
*/

package jkk.math;

import java.awt.Point;

public class V {

	public static double [] fromPoint(Point p) {
		double [] r = new double[2];
		r[0] = p.x; r[1] = p.y;
		return r;
	}

	public static Point toPoint(double [] v) {
		return new Point((int)v[0],(int)v[1]);
	}

	public static double norm(double [] v) {
		double d = 0;
		for(int i=0;i < v.length;i++)
			d += v[i]*v[i];
		return Math.sqrt(d);
	}

	public static double [] mul(double [] v, double x) {
		double [] u = new double[v.length];
		for(int i=0;i < v.length;i++)
			u[i] = v[i]*x;
		return u;
	}

	public static double [] dot(double [] v, double [] u) {
		double [] r = new double[v.length];
		for(int i=0;i < v.length;i++)
			r[i] = v[i]*u[i];
		return r;
	}

	public static double [] add(double [] v, double [] u) {
		double [] r = new double[v.length];
		for(int i=0;i < v.length;i++)
			r[i] = v[i]+u[i];
		return r;
	}

	public static void addm(double [] v, double [] u) {
		for(int i=0;i < v.length;i++)
			v[i] = v[i]+u[i];
	}

	public static double [] sub(double [] v, double [] u) {
		double [] r = new double[v.length];
		for(int i=0;i < v.length;i++)
			r[i] = v[i]-u[i];
		return r;
	}

	public static void subm(double [] v, double [] u) {
		for(int i=0;i < v.length;i++)
			v[i] = v[i]-u[i];
	}
	
	public static String print(double [] v) {
		StringBuffer buf = new StringBuffer();
		buf.append('<');
		for(int i=0;i < v.length;i++) {
			if(i > 0) buf.append(", ");
			buf.append(Double.toString(v[i]));
		}
		buf.append('>'); return buf.toString();
	}

	

}
