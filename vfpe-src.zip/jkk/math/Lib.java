/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1996-1999
*/

package jkk.math;

import java.util.Random;

/**
   Library of mathematical-type functions.
   @author J Kyle Kelso
*/
public class Lib {

	/**
		Generate random permutation - probably very bad implementation.
		@param n size of permutation
		@return an array n ints, in which each int in 0..n-1 will appear
			exactly once.
	*/
	public static int [] permutation(int n) {
		Random r = new Random();
		int [] p = new int[n];
		for(int i=0;i < n;i++) p[i] =i;
		for(int i=0;i < n;i++) {
			int s = mod(r.nextInt(),n);
			int tmp = p[i];
			p[i] = p[s]; p[s] = tmp;
		}
		return p;
	}

	// bit manipulation stuff
	
	/**
		@param x long integer to find log base 2 of.
		@return log base 2 of argument rounded down to an int ie the
			bit position of the highest order set bit.  Returns -1 if
			a -ve arg is passed in.
	*/
	public static int intLog(long x) {
		if(x < 1)
			return -1;
		int i = 0;
		while(x != 1) {
			x = x >>> 1; i++;
		}
		return i;
	}
	
	/**
	   Given an arbitary int, produces another with equal numbers of 1's
	   and 0's.  This is used to make bit-balanced constants for XORing
	   things in the longHash() implementation.
	   @param x initial int.  Only low 16 bits are used.
	   @return bit balanced int.
	*/
	public static int bitBalance(int x) {
		int left = x & 0x0000ffff;
		return left | ((~left) << 16);
	}

	public static void clipInts(int [] data, int min, int max) {
		for(int i=0;i < data.length;i++) {
			if(data[i] < min) data[i] = min;
			else if(data[i] >= max) data[i] = max-1;
		}
	}
	
	public static int [] composeIntMap(int [] map, int [] data) {
		int [] r = new int[data.length];
		for(int i=0;i < data.length;i++)
			r[i] = map[data[i]];
		return r;	
	}

	/**
		DES-like hash function, from:
		"Numerical Recipies in C, 7.5, Cambridge University Press 1992.
		<p>
		The hash constants should be an array bit-rich random ints (ideally
		with 16 '1's and 16 '0's) with an even size.  The reference suggests
		that 4 ints (2 iterations) passes all statistical tests for randomness, 
		8 is probably overkill.
		<p>
		This could definitely be simplified and optimised.
		<p>
		@param x value being hashed.  To get a random number stream, just pass
		   successive long values in.
		@param cs seed value.
	*/
	public static long longHash(long x, int [] cs) {
		int NITER = cs.length/2;
		int left = (int)(x >>> 32);
		int right = (int)(x & 0xFFFFFFFFL);
		for(int i=0;i < NITER;i++) {
			int tmp = right;
			right = shuffle(right,i,cs) ^ left;
			left = tmp;
		}
		return ((long)left << 32) | ((long)right & 0xFFFFFFFFL);
	}
	
	/**
	   Internal bit-shuffling for longHash.
	   @param x starting 32 bits.
	   @param i current position in seed array.
	   @param cs seed array.
	   @return shuffled 32 bits.
	*/
	private static int shuffle(int x, int i, int [] cs) {
		x ^= cs[i];
		int hi = x>>>16; int low = x & 0xffff;
		x = ~(hi*hi)+(low*low);
		x = (x >>> 16) | (x << 16);
		return (x ^ cs[i*2])+hi*low;
	}

   /**
      This creates an array of the form suitable for use with the longHash()
      function.  The longer the string, the more the hash function will mix
      things up.  Its fairly robust, but if you're paranoid you could make sure
      you use a variety of ASCII characters.  Only the low 8 bits of each
      character are used.
      @param s String on which to base seed.
      @param an even-numbered size array of bit-balanced ints.
   */
	public static int [] makeHashConstants(String s) {
		int n = s.length(); n += (n % 4 == 0 ? 0 : 4 - (n % 4));
		char [] chs = new char[n];
		for(int i=0;i < n;i++)
			chs[i] = (i < s.length() ? s.charAt(i) : ' ');
		int [] cs = new int[n/2];
		for(int i=0;i < cs.length;i++) {
			cs[i] = bitBalance((int)((chs[i*2]<<8) | (chs[i*2+1] & 0x00ff)));
		}
		return cs;
	}

	/* heres an alternative that accepts hex digits */
	/*
	public static int [] makeHashConstants(String s) {
		int n = s.length(); n += (n % 8 == 0 ? 0 : 8 - (n % 8));
		char [] chs = new char[n];
		for(int i=0;i < n;i++)
			chs[i] = (i < s.length() ? s.charAt(i) : '5');
		int [] cs = new int[n/4];
		for(int i=0;i < cs.length;i++) {
			int x = 0x55555555;
			try {
				x = Integer.parseInt(new String(chs,i*4,4),16);
			} catch(NumberFormatException nfe) { }
			cs[i] = bitBalance(x);
		}
		return cs;
	}
	*/
	
	/**
		mod that returns +ve values just like % doesn't.
	*/
	public static int mod(int m, int n) {
		int r = m % n;
		return r < 0 ? r + n : r;
	}

	/* i think the % operator on floats does this */
	
	public static double fract(double d) {
		return d - Math.floor(d);
	}

	public static int sign(double d) {
		if(d < 0.0) return -1;
		if(d > 0.0) return 1;
		return 0;
	}
}
