/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1999
*/

package jkk.math;

import java.util.Random;

public class Dice {

	private static Random r = new Random();

	public static int d(int n) {
		return Lib.mod(r.nextInt(),n)+1;
	}

	public static int d(int count, int n) {
		int sum = 0;
		for(int i=0;i < count;i++)
			sum += d(n);
		return sum;
	}

	public static int distribute(double x, double [] vals) {
		for(int i=0;i < vals.length;i++) {
			if(x <= vals[i])
				return i;
		}
		return vals.length-1;
	}

	public static int getInt(int n, int [] t) {
		if(n < 0) return t[0];
		if(n >= t.length) return t[t.length-1];
		return t[n];
	}

	public static String getString(int n, String [] t) {
		if(n < 0) return t[0];
		if(n >= t.length) return t[t.length-1];
		return t[n];
	}
}
