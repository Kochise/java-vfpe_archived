/*
    * * * * * software from the house of J Kyle Kelso
    * **  ** 
  *** * * * * copyright 1999
*/

package jkk;

// directed graph adjacency list implementation
// has tools for maintaining undirected graphs

import java.io.Serializable;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import jkk.Set;

public class Graph implements Serializable {

	private Hashtable nodes;

	// constructor stuff

	public Graph() { }

	public void init() {
		nodes = new Hashtable();
	}

	// tools

	public void addNode(Object n) { nodes.put(n,new Vector()); }

	public void addLink(Object n, Object o) {
		Vector l = (Vector)nodes.get(n);
		if(!l.contains(o))
			l.addElement(o);
	}

	public void addBiLink(Object n, Object o) { addLink(n,o); addLink(o,n); }

	// more obscure tools

	public Functor getNeighbourFunctor() {
		return new Functor() {
			public Object eval(Object x) { return nodes.get(x); }
		};
	}

	public Set getNodesAsSet() { return new Set(nodes); }

	// testing stuff

	public static void main(String argv []) {

		// read graph

		Vector script = (Vector)jkk.text.Lib.parseList(argv[0]);

		// interpret to build graph

		Graph g = new Graph(); g.init();
		int i = 0;
		while(i < script.size()) {
			String cmd = (String)script.elementAt(i);
			if(cmd.equals("node")) {
				g.addNode(script.elementAt(i+1));
				i += 2;
			} else if(cmd.equals("arc")) {
				g.addBiLink(script.elementAt(i+1),script.elementAt(i+2));
				i += 3;
			} else
				i++;
		}

		// partition

		Set parts = Partition.partition(g.getNodesAsSet(),g.getNeighbourFunctor());

		// print partitions

		Enumeration e = parts.keys();
		while(e.hasMoreElements()) {
			Enumeration f = ((Set)e.nextElement()).keys();
			System.out.print("Partition:");
			while(f.hasMoreElements()) {
				System.out.println(" ");
				System.out.print(f.nextElement().toString());
			}
			System.out.println(" ");
		}
	}

}
