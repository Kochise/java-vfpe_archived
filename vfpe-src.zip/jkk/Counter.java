/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1996
*/

package jkk;

import java.io.Serializable;

public class Counter implements Serializable {
    private int n;

    public Counter() { n = 0; }

    public Integer next() { return new Integer(n++); }

    public int nextInt() { return n++; }

    public int peekInt() { return n; }
}
