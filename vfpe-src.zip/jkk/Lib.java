/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1996-1999
*/

package jkk;

import java.math.BigInteger;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Random;
import java.util.Vector;

public class Lib {

	public static Random rand = new Random();

	public static Object makeObject(String cName) {
		Object r = null;
		try {
			Class aClass = Class.forName(cName);
			r = aClass.newInstance();
		} catch(ClassNotFoundException cnfe) {
			r = null;
		} catch(InstantiationException ie) {
			r = null;
		} catch(IllegalAccessException iae) {
			r = null;
		}
		return r;		
	}

	/* data structures and sorting */

	public static Object [] sortOnValues(Hashtable t, Comparator c) {
		Enumeration e = t.keys();
		int size = t.size();
		Object [] k = new Object[size];
		Object [] v = new Object[size];
		int i=0;
		while(e.hasMoreElements()) {
			Object o = e.nextElement();
			k[i] = o; v[i] = t.get(o);
			i++;
		}
		quicksort(v,c,k); return k;
	}

	public static Object [] sortOnKeys(Hashtable t, Comparator c) {
		Enumeration e = t.keys();
		int size = t.size();
		Object [] k = new Object[size];
		int i=0;
		while(e.hasMoreElements()) {
			Object o = e.nextElement();
			k[i] = o;
			i++;
		}
		quicksort(k,c,null); return k;
	}

	public static void quicksort(Object [] keys, Comparator c) {
		quicksort(keys,0,keys.length-1,c,null);
	}

	public static void quicksort(Object [] keys, Comparator c, Object [] v) {
		quicksort(keys,0,keys.length-1,c,v);
	}

	public static void quicksort(
		Object [] k, int low, int high, Comparator c,
		Object [] v) {

		// base
		
		int diff = high - low;
		if(diff <= 0) return;
		if(diff == 1) {
			if(c.compare(k[low],k[high]) > 0)
				swap(k,v,low,high);
			return;
		}

		// partition
		
		Object pivot = k[diff/2+low];
		int x = low; int y = high;
		while(x <= y) {
			if(c.compare(k[x],pivot) < 0)
				x++;
			else if(c.compare(k[y],pivot) > 0)
				y--;
			else {
				swap(k,v,x,y); x++; y--;
			}
		}

		// recurse
		x--; y++;
		quicksort(k,low,x,c,v);
		quicksort(k,y,high,c,v);
	}

	private static void swap(Object [] o, Object [] v, int m, int n) {
		Object tmp = o[m]; o[m] = o[n]; o[n] = tmp;
		if(v != null) {
			tmp = v[m]; v[m] = v[n]; v[n] = tmp;
		}
	}

	public static Object [] elementsAsArray(Hashtable t) {
		Enumeration e = t.elements(); int size = t.size();
		Object [] v = new Object[size]; int i=0;
		while(e.hasMoreElements()) {
			v[i] = e.nextElement(); i++;
		}
		return v;
	}

	public static Object [] keysAsArray(Hashtable t) {
		Enumeration e = t.keys(); int size = t.size();
		Object [] v = new Object[size]; int i=0;
		while(e.hasMoreElements()) {
			v[i] = e.nextElement(); i++;
		}
		return v;
	}

	/* stable */
	public static void slowSort(Vector v, Comparator c, boolean ascending) {
		for(int i=0;i < v.size()-1;i++)
			for(int j=i;j < v.size();j++) {
				int o = c.compare(v.elementAt(i),v.elementAt(j));
				if((ascending && (o > 0)) || (!ascending && (o < 0))) {
					Object t = v.elementAt(i);
					v.setElementAt(v.elementAt(j),i);
					v.setElementAt(t,j);
				}
			}
	}

	/* stable */
	public static void slowSort(Object [] v, Comparator c, boolean ascending) {
		for(int i=0;i < v.length-1;i++)
			for(int j=i;j < v.length;j++) {
				int o = c.compare(v[i],v[j]);
				if((ascending && (o > 0)) || (!ascending && (o < 0))) {
					Object t = v[i];
					v[i] = v[j]; v[j] = t;
				}
			}
	}

	/* vector tools */
	
	public static void joinVectors(Vector a, Vector b) {
		for(Enumeration e = b.elements();e.hasMoreElements();)
			a.addElement(e.nextElement());
	}

	public static Object [] toArray(Vector v) {
		Object [] r = new Object[v.size()];
		v.copyInto(r); return r;
	}

	// not efficient
	public static Vector nub(Vector v) {
		Vector r = new Vector();
		for(int i =0;i < v.size();i++) {
			Object x = v.elementAt(i);
			if(!r.contains(x))
				r.addElement(x);
		}
		return r;
	}

	public static Object [] subarray(Object [] a, int begin, int end) {
		Object [] r = new Object[end-begin];
		for(int i=begin;i < end;i++)
			r[i-begin] = a[i];
		return r;
	}

	/*	there _should_ have been a Comparable interface in
		Java 1.0 */
	public static int compare(Object a, Object b) {
		int r = 0;

		// we do this the long way because it should be right for longs
		// and BigIntegers
		if((a instanceof BigInteger) && (b instanceof BigInteger)) {
			BigInteger bi = ((BigInteger)a).subtract((BigInteger)b);
			r = bi.signum();
		} else if((a instanceof Long) && (b instanceof Long)) {
			long l = ((Long)a).longValue() - ((Long)b).longValue();
			r = l < 0L ? -1 : (l > 0L ? 1 : 0);
		} else if((a instanceof Number) && (b instanceof Number)) {
			double fr = ((Number)a).doubleValue() - ((Number)b).doubleValue();
			r = fr < 0.0 ? -1 : (fr > 0.0 ? 1 : 0);
		} else if((a instanceof Character) && (b instanceof Character)) {
			r = ((Character)a).charValue() - ((Character)b).charValue();
		} else if((a instanceof String) && (b instanceof String)) {
			r = ((String)a).compareTo((String)b);
		} else {
			throw new NumberFormatException(
				"jkk.Lib.compare doesn't handle classes " + 
				a.getClass().getName() + " and " + b.getClass().getName());
		}
		return r;
	}

	public static Comparator objComp = new Comparator() {
		public int compare(Object a, Object b) {
			return Lib.compare(a,b);
		}
	};

}
