/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1998
*/

/* this is straight from java.util.Comparator in Java 1.2 */

package jkk;

public interface Comparator {
	public abstract int compare(Object a, Object b);
}
