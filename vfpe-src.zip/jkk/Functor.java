/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1996
*/

package jkk;
/* should this be an interface ? */

public abstract class Functor {
    public abstract Object eval(Object x);
}
