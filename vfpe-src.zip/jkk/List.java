/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997
*/

package jkk;

public class List {
	public Object head;
	public List tail;

	public List(Object head, List tail) {
		this.head = head;
		this.tail = tail;
	}
	
	public List reverse() {
		List tmp = null;
		List head = this;
		while(head != null) {
			tmp = new List(head.head,tmp);
			head = head.tail;
		}
		return tmp;
	}
	
	public String toString() {
		return jkk.text.Lib.printList(this);
	}
}
