/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1999
*/

package jkk.movie;

import java.applet.Applet;
import java.applet.AudioClip;
import java.awt.Button;
import java.awt.Color;
import java.awt.Dialog;
import java.awt.Frame;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.Panel;
import java.awt.Point;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.InputStream;
import java.io.IOException;
import java.net.URL;
import java.net.MalformedURLException;
import java.util.Hashtable;
import java.util.Vector;

import jkk.gui.IconSource;
import jkk.gui.Lib;

/**
	The PlayerApplet plays application demo movies.  The MovieConstants source
	contains the definition of the language interpreted by the PlayerApplet).
	The script file and screen shot images for the demo are stored in a
	directory (named by the "movie.dir" applet parameter) off the document
	base directory.
	<p>
	The PlayerApplet shows a control panel with "forward/backward" stepping
	buttons and a commentary area; below the control panel is an image of the
	application, over which cursor movements are shows for the demo.
	<p>
	The script interpreter instruction execution parts of this could be put in
	a "MoviePlayer" component that wraps a MovieCanvas and optional controls
	and has a variable IconSource: this would allow Movie constructor apps to
	use the same code.
	<p>
	The source code for this class contains sample applet HTML code for
	a demo applet.
	<p>
	@author J Kyle Kelso, (c) 1999.
*/
public class PlayerApplet extends Applet
	implements ActionListener, MovieConstants, IconSource {

/* Here is some sample HTML for embedding a PlayerApplet

<center>
<APPLET CODE="jkk.movie.PlayerApplet" WIDTH = "600" HEIGHT = "700" >
<PARAM NAME="movie.dir" VALUE="movie1">
<PARAM NAME="delay" VALUE="50">
<PARAM NAME="cursor.correction.x" VALUE="-5">
<PARAM NAME="cursor.correction.y" VALUE="-5">
Didn't work, did it ? I know that Netscape 6.1 will show
this applet, you should be able to get it from somewhere at
<a href="www.netscape.com">Netscape</a>
</APPLET>
</center>

*/

	////////////
	// constants

	private static final String NEXT_LABEL = "next";
	private static final String REPLAY_LABEL = "replay";
	private static final String RESET_LABEL = "reset";

	/////////
	// fields

	private Vector script;
	private URL movieBase;
	private int pc;
	private Hashtable cursors;
	private int delay;
	private Point cursorCorrection;
    private Frame controls;
    private AudioClip click;

	private Button nextButton;
	private Button replayButton;
	private TextArea commentary;
	private MovieCanvas playbackPanel;

	///////////////
	// applet stuff
	
	public void init() {
		
		// read script
		URL scriptURL = null;
		try {
			movieBase = new URL(getDocumentBase(),getParameter("movie.dir")+"/");
			scriptURL = new URL(movieBase,SCRIPT_FILE_NAME);
		} catch(MalformedURLException murle) {
			throw new IllegalArgumentException("couldn't make script url");
		}

		String ss = jkk.io.Lib.URLToString(scriptURL);
		if(ss == null)
			throw new IllegalArgumentException("IO problem getting script");
		script = (Vector)jkk.text.Lib.parse(ss);

		// load cursor images and click sound

		cursors = new Hashtable();
		cursors.put("normal",getImage(getDocumentBase(),"normal.gif"));
		jkk.gui.Lib.waitForImage((Image)cursors.get("normal"),this);
		cursors.put("grab",getImage(getDocumentBase(),"grab.gif"));
		jkk.gui.Lib.waitForImage((Image)cursors.get("grab"),this);
        click = getAudioClip(getDocumentBase(),"click.wav");
		
        // configure from applet params

		try {
			delay = Integer.parseInt(getParameter("delay"));
		} catch(NumberFormatException nfe) {
			delay = 10;
		}
		
		cursorCorrection = new Point();
		String ccx = getParameter("cursor.correction.x");
		if(ccx != null) {
		    try {
			    cursorCorrection.x = Integer.parseInt(ccx);
		    } catch(NumberFormatException nfe) { }
		}
		String ccy = getParameter("cursor.correction.y");
		if(ccy != null) {
		    try {
			    cursorCorrection.y = Integer.parseInt(ccy);
		    } catch(NumberFormatException nfe) { }
		}
		
        String bgColor = getParameter("bgcolor");
        if(bgColor != null)
            setBackground(Color.decode(bgColor));
		
		// initialise interpreter
		pc = 0;
		pc++;	// comment header

        controls = new Frame("Player Applet Controls");
        PlayerControls pc = new PlayerControls(this);
        controls.setLayout(new GridBagLayout());
        Lib.constrain(controls,pc,"position=0,0,1,1 weight=1.0,1.0");
        controls.pack(); controls.setVisible(true);

        setLayout(new GridBagLayout());
        Lib.constrain(this,playbackPanel = new MovieCanvas(this),
            "position=0,0,1,1 weight=1.0,1.0");

		play();
    }

    public void start() {
        controls.setVisible(true);
    }

    public void stop() {
        controls.setVisible(false);
    }

    public void destroy() {
        controls.dispose();
    }

    class PlayerControls extends Panel {

        PlayerApplet pa;

		public PlayerControls(PlayerApplet pa) {
            this.pa = pa;

            setLayout(new GridBagLayout());
            Lib.constrain(this, commentary = new TextArea(8,60),
                "position=0,0,1,3 weight=1.0,1.0");
            commentary.setBackground(pa.getBackground()); 
            commentary.setEditable(false);

            Button b;
            Lib.constrain(this,nextButton = new Button(NEXT_LABEL),
                "position=1,0,1,2 weight=0.0,1.0");
            nextButton.addActionListener(pa);

            replayButton = new Button(REPLAY_LABEL);
        /*
            Lib.constrain(this,replayButton,
                "position=1,1,1,1 weight=0.0,0.0");
            replayButton.addActionListener(pa);
            replayButton.setEnabled(false);
        */
            Lib.constrain(this,b = new Button(RESET_LABEL),
                "position=1,2,1,1 weight=0.0,0.0");
            b.addActionListener(pa);
        }

    } // end of class PlayerControls

	/////////////////////////
	// internal functionality

	private void play() {
		String cmd;
		do {
			cmd = WAIT;
			if(pc >= script.size())
				continue;
			Vector event = (Vector)script.elementAt(pc++);
			cmd = (String)event.elementAt(0);
			execute(event);
		} while(!cmd.equals(WAIT));
		if(pc >= script.size())
			nextButton.setEnabled(false);
		replayButton.setEnabled(true);
	}

	private void replay() {

	}

	private void execute(Vector args) {
		String cmd = (String)args.firstElement();
		if(cmd.equals(CHANGE_VIEW)) {
			playbackPanel.setView((Vector)args.elementAt(1));
		} else if(cmd.equals(CHANGE_CURSOR)) {
			playbackPanel.changeCursor((Image)cursors.get(args.elementAt(1)));
		} else if(cmd.equals(CHANGE_COMMENT)) {
			commentary.setText((String)args.elementAt(1));
		} else if(cmd.equals(MOUSE_SEQUENCE)) {
			playbackPanel.playSequence(args,delay,
                        cursorCorrection,click);
		}
	}

	///////////////////
	// IconSource impl.

	public Image getImage(String iName) {
// FEATURE do some look-ahead caching
		Image img = getImage(movieBase,iName);
		jkk.gui.Lib.waitForImage(img,this);
		return img;
	}

	/////////////////
	// event listener

	public void actionPerformed(ActionEvent ae) {
		String cmd = ae.getActionCommand();
		if(cmd.equals(NEXT_LABEL)) {
			play();
		} else if(cmd.equals(REPLAY_LABEL)) {
			replay();
		} else if(cmd.equals(RESET_LABEL)) {
			pc = 1; nextButton.setEnabled(true);
			play();
		}
	}

}
