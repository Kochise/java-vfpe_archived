/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1999
*/

package jkk.movie;

import java.applet.AudioClip;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.Vector;

import jkk.gui.IconSource;

/**
	The EventCollectorPanel displays backdrop images, and can
	collect mouse and mouse motion events that occur on it.  It
	was designed to capture fake application cursor movement and
	clicks, so that they can be stored for use in application demo
	movies.

	@author J Kyle Kelso, 1999.
*/
public class MovieCanvas extends Canvas implements
	MouseListener, MouseMotionListener, MovieConstants {

	////////////
	// constants 

	private static final int GAP = 10;

	/////////
	// fields
	
	public IconSource icons;

	private Image backdrop;
	private String currentMain;
	private Vector aux;
	private Dimension bDim;
	private Dimension auxDim;
	private Vector events;
	private boolean collecting;

	private Image cursor;
	private int cx, cy;
	private boolean showCursor;
	
	//////////////
	// constructor

	public MovieCanvas(IconSource icons) {
		this.icons = icons;
		aux = new Vector();
		bDim = new Dimension(0,0);
		auxDim = new Dimension(0,0);
		events = new Vector();
		addMouseListener(this);
		addMouseMotionListener(this);
	}

	//////////
	// methods

	public void setBackdrop(Image i) {
		backdrop = i;
		bDim.width = backdrop.getWidth(null);
		bDim.height = backdrop.getHeight(null);
		clearAux();
		repaint();
	}

	public void addAux(Image img) {
		aux.addElement(img);
		auxDim.height += img.getHeight(null);
		auxDim.width = Math.max(auxDim.width,img.getWidth(null)+1);
		repaint();
	}

	public void clearAux() {
		aux = new Vector();
		auxDim.width = 0;auxDim.height = 0;
	}

	public void setView(Vector vSpec) {
		String thisMain = (String)vSpec.elementAt(0);
		if(currentMain == null || !currentMain.equals(thisMain)) {
			Image img = icons.getImage(thisMain);
			currentMain = thisMain;
			setBackdrop(img);
		}
		clearAux();
		for(int i=1;i < vSpec.size();i++) {
			Image img = icons.getImage((String)vSpec.elementAt(i));
			addAux(img);
		}
		repaint();
	}

	// mouse motion capture

	public void clearEvents() {
		events = new Vector();
	}

	public void setCollecting(boolean c) {
		collecting = c;
	}

	public void toggleCollecting() {
		collecting = !collecting;
	}

	public Vector getEvents() { return events; }

	// playback

	public void playSequence(Vector seq, int delay, 
            Point cursorCorrection, AudioClip click) {	
	    showCursor = true;
		int i=1;
		while(i < seq.size()) {
			String cmd = (String)seq.elementAt(i);
			if(cmd.equals(MOUSE_MOVE)) {
				cx = ((Long)seq.elementAt(i+1)).intValue() +
				    cursorCorrection.x;
				cy = ((Long)seq.elementAt(i+2)).intValue() +
				    cursorCorrection.y;
				paint(getGraphics());
				try {
					Thread.sleep(delay);
				} catch(InterruptedException ie) { }
				i += 3;
			} else if(cmd.equals(MOUSE_CLICK)) {
                            if(click != null) click.play();
				repaint();
				i += 3;
			}
		}
	}

	public void changeCursor(Image cImage) {
		cursor = cImage; repaint();
	}

	//////////
	// painter

	Image offscreen;

	public void paint(Graphics gr) {
		// prep buffer
		Dimension s = getPreferredSize();
		if(offscreen == null)
			offscreen = createImage(s.width,s.height);
		int ow = offscreen.getWidth(null);
		int oh = offscreen.getHeight(null);
		if(s.width > ow || s.height > oh) {
			offscreen = createImage(s.width,s.height);
			ow = s.width; oh = s.height;
		}

		// draw into buffer
		Graphics g = offscreen.getGraphics();
		g.setColor(getBackground());
		g.fillRect(0,0,ow,oh);
		if(backdrop != null) {
			g.drawImage(backdrop,0,0,null);
			g.setColor(Color.black);
			g.drawRect(0,0,bDim.width,bDim.height);
		}
		if(aux != null) {
			int dy = 0;
			for(int i=0;i < aux.size();i++) {
				Image img = (Image)aux.elementAt(i);
				g.drawImage(img,bDim.width+GAP,dy,null);
				g.setColor(Color.black);
				g.drawRect(bDim.width + GAP,dy,img.getWidth(null),img.getHeight(null));
				dy += GAP + img.getHeight(null);
			}
		}
		if(showCursor && cursor != null)
			g.drawImage(cursor,cx,cy,null);

		// blit
		gr.drawImage(offscreen,0,0,null);
	}
	
	/* single buffer
	public void paint(Graphics g) {
		if(backdrop != null) {
			g.drawImage(backdrop,0,0,null);
		}
		if(aux != null) {
			int dy = 0;
			for(int i=0;i < aux.size();i++) {
				Image img = (Image)aux.elementAt(i);
				g.drawImage(img,bDim.width+GAP,dy,null);
				dy += GAP + img.getHeight(null);
			}
		}
		if(showCursor && cursor != null)
			g.drawImage(cursor,cx,cy,null);
	}
	*/

	/////////
	// layout

	public Dimension getPreferredSize() { 
		return new Dimension(bDim.width+GAP+auxDim.width,
			Math.max(bDim.height,auxDim.height));
	}

	public Dimension getMinimumSize() { 
		return getPreferredSize();
	}

	//////////////////
	// mouse listeners

	public void mouseMoved(MouseEvent me) { collect(me); }
	public void mouseDragged(MouseEvent me) { collect(me); }

	public void mousePressed(MouseEvent me) { collect(me); }
	public void mouseReleased(MouseEvent me) { collect(me); }
	public void mouseClicked(MouseEvent me) { collect(me); }
	public void mouseEntered(MouseEvent me) { collect(me); }
	public void mouseExited(MouseEvent me) { collect(me); }

	private void collect(MouseEvent me) {
		if(collecting)
			events.addElement(me);
	}
}

