/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1999
*/

package jkk.movie;

/**
	Common constants for movie package.  The source for this class contains
	the grammar of the movie scripts.

	@author J Kyle Kelso, (c) 1999.
*/
public interface MovieConstants {

	/*
	
	The scripts are s-expressions, as parsed by the jkk.text.Lib methods.
	Like this (with linear whitespace between tokens):

	movie-script 		::= '(' <comment string> event* ')'
    event               ::= comment-change | view-change | cursor-change |
                            mouse-sequence | wait
    comment-change      ::= '(change-comment' <comment string> ')'
    view-change         ::= '(change-view' view-spec ')'
    cursor-change       ::= '(change-cursor' <cursor string> ')'
    mouse-sequence      ::= '(mouse-sequence' mouse-event* ')'
    wait                ::= '(wait)'
    view-spec           ::= '(' <image name>* ')'
    mouse-event         ::=   'm' <x int> <y int>
     						| 'c' <x int> <y int>
     						
    */

	public static final String WAIT = "wait";
	public static final String CHANGE_VIEW = "change-view";
	public static final String CHANGE_CURSOR = "change-cursor";
	public static final String CHANGE_COMMENT = "change-comment";
	public static final String MOUSE_SEQUENCE = "mouse-sequence";
	public static final String MOUSE_MOVE = "m";
	public static final String MOUSE_CLICK = "c";

	public static final String SCRIPT_FILE_NAME = "script";
}
