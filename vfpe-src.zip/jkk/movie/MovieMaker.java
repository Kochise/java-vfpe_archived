/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1999
*/

package jkk.movie;

import java.awt.Button;
import java.awt.Checkbox;
import java.awt.Choice;
import java.awt.Dialog;
import java.awt.Frame;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.Point;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.io.File;
import java.util.Hashtable;
import java.util.Vector;

import jkk.Counter;
import jkk.gui.IconSource;
import jkk.gui.TextLabel;
import jkk.text.Lib;

/**
	The MovieMaker takes demo application scripts and presents
	them, pausing at each empty "mouse-sequence" instruction to
	allow a mouse sequence to be entered.

	@author J Kyle Kelso, 1999.
*/
public class MovieMaker extends Frame
	implements KeyListener, IconSource, MovieConstants {

	////////////
	// constants

	public static final String FRAME_TITLE = "MovieMaker";
	public static final int DELAY = 10;
	public static final int BIG_JUMP = 1000;
	
	/////////
	// fields

	private String fileBase;
	private MovieCanvas face;
	private Hashtable cursors;

	private Vector inScript;
	private StringBuffer outScript;
	private int pc;
	private Vector currentSequence = new Vector();
        private Point zeroPoint = new Point(0,0);
	
	//////////////
	// constructor

	public MovieMaker(String fBase) {
		super(FRAME_TITLE);
		fileBase = fBase;

		// load cursor images

		cursors = new Hashtable();
		cursors.put("normal",getImage("normal.gif"));
		jkk.gui.Lib.waitForImage((Image)cursors.get("normal"),this);
		cursors.put("grab",getImage("grab.gif"));
		jkk.gui.Lib.waitForImage((Image)cursors.get("grab"),this);

		// parse script
		String ss = jkk.io.Lib.fileToString(path(SCRIPT_FILE_NAME));
		if(ss == null)
			throw new IllegalArgumentException("IO problem getting script");
		inScript = (Vector)jkk.text.Lib.parse(ss);

		// find first frame and make MovieCanvas
		face = new MovieCanvas(this);
		face.addKeyListener(this);
		
		// show frame
		add(face,"Center");
		pack();
		setVisible(true);

		// prepare script
		outScript = new StringBuffer();
		outScript.append("(\n");
		outScript.append(jkk.text.Lib.print(inScript.firstElement()));
		outScript.append('\n');
		pc = 0;
		showNext();
	}

	private void step() { step(1,false); }
	
	private void step(int n, boolean stopOnMouse) {
		boolean stop = false;
		for(int i=0;i < n;i++) {
			pc++;
			if(pc >= inScript.size()) {
				outScript.append("\n)");
				try {
					jkk.io.Lib.stringToFile(path(SCRIPT_FILE_NAME),
						outScript.toString());
				} catch(IOException ioe) {
					System.err.println("couldn't write script: " + ioe);
				}
				System.exit(0);
			}
			Vector event = (Vector)inScript.elementAt(pc);
			String cmd = (String)event.firstElement();
			if(cmd.equals(CHANGE_VIEW)) {
				face.setView((Vector)event.elementAt(1));
			} else if(cmd.equals(CHANGE_CURSOR)) {
				face.changeCursor((Image)cursors.get(event.elementAt(1)));
			} else if(cmd.equals(CHANGE_COMMENT)) {

			} else if(cmd.equals(MOUSE_SEQUENCE)) {
				if(event.size() < 2) {
					if(stopOnMouse) {
						pc--; break;
					}
					Vector ss = convertToScriptSequence(currentSequence);
					outScript.append(jkk.text.Lib.print(ss));
					currentSequence = new Vector();
				} else {
					face.playSequence(event,DELAY,zeroPoint,null);
					outScript.append(jkk.text.Lib.print(event));
				}
			}
			if(!cmd.equals(MOUSE_SEQUENCE))
				outScript.append(jkk.text.Lib.print(event));
			outScript.append('\n');
			if(cmd.equals(WAIT))
				outScript.append('\n');
		}

		// show next instruction
		showNext();
	}

	private String path(String obj) {
		return fileBase + File.separator + obj;
	}

	public static Vector convertToScriptSequence(Vector in) {
		Vector out = new Vector();
		out.addElement(MOUSE_SEQUENCE);
		for(int i=0;i < in.size();i++) {
			MouseEvent me = (MouseEvent)in.elementAt(i);
			boolean writePos = false;
			if(me.getID() == MouseEvent.MOUSE_MOVED) {
				out.addElement(MOUSE_MOVE); writePos = true;
			} else if(me.getID() == MouseEvent.MOUSE_CLICKED) {
				out.addElement(MOUSE_CLICK); writePos = true;
			}
			if(writePos) {
				out.addElement(new Long(me.getX()));
				out.addElement(new Long(me.getY()));
			}
		}
		return out;
	}

	private void showNext() {
		if(pc+1 >= inScript.size()) {
			System.out.println("(end-of-script)");
		} else {
			Vector event = (Vector)inScript.elementAt(pc+1);
			System.out.println(jkk.text.Lib.print(event));
		}
	}

	/////////////////////
	// image source impl.

	public Image getImage(String img) {
		byte [] idata = jkk.io.Lib.fileToByteArray(path(img));
		if(idata == null) return null;
		Image i = jkk.gui.Lib.imageFromByteArray(idata);
		jkk.gui.Lib.waitForImage(i,this);
		return i;
	}
	
	///////////////
	// key listener

	public void keyPressed(KeyEvent ke) { }
	public void keyReleased(KeyEvent ke) { }

	public void keyTyped(KeyEvent ke) {
		char c = ke.getKeyChar();
		String mods = KeyEvent.getKeyModifiersText(ke.getModifiers());
		switch(c) {
		case 'c':
			face.clearEvents(); break;
		case 'f':
			step(BIG_JUMP,true);
			break;
		case 'n':
			currentSequence = face.getEvents();
			step();
			face.clearEvents();
			break;
		case 's':
			face.toggleCollecting(); break;
		case 'x':
			step(BIG_JUMP,false);
			break;
		default:
			break;
		}
	}

	////////////////
	// launcher main

	public static void main(String [] argv) {
		MovieMaker mm = new MovieMaker(argv[0]);
	}
}

