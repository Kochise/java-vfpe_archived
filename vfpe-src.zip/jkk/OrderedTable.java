/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997
*/

/*	a hashtable that remembers the order that keys were added, and
	uses that order to return the key enumeration

	if an existing key is added again, it becomes the last element
	in the enumeration
*/

package jkk;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

public class OrderedTable extends Hashtable {
	private Vector keyvect;

	public OrderedTable() { super(); keyvect = new Vector(); }

	public Enumeration keys() { return keyvect.elements(); }

	public Object put(Object key, Object val) {
		Object old = super.put(key,val); 
		if(old != null) { keyvect.removeElement(old); }
		keyvect.addElement(key); return old;
	}

	public Object remove(Object key) {
		Object old = super.remove(key); 
		if(old != null) { keyvect.removeElement(key); }
		return old;
	}
}
