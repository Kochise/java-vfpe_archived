/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1999
*/

/* for setting the transparency of an image */

package jkk.gui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Image;
import java.awt.image.ImageFilter;
import java.awt.image.ImageObserver;
import java.awt.image.ImageProducer;
import java.awt.image.RGBImageFilter;
import java.awt.image.FilteredImageSource;

public class TransparencyFilter extends RGBImageFilter {
	private int bgRGB;
	private double trans = 0.5;
	private int a = 128 << 24;

	public TransparencyFilter(double trans) {
		canFilterIndexColorModel = true;
		setTrans(trans);
	}

	public void setTrans(double trans) {
		this.trans = trans;
		a = ((int)(255*trans)) << 24;
	}

	public int filterRGB(int x, int y, int rgb) {
		return a | (rgb & 0x00ffffff);
	}

	public static Image filter(Image img, double t, Component c) {
		ImageFilter f = new TransparencyFilter(t);
		ImageProducer prod =
			new FilteredImageSource(img.getSource(),f);
		return c.createImage(prod);
	}
		
}
