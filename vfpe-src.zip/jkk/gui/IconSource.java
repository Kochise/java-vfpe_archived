/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1999
*/

package jkk.gui;

import java.awt.Image;

public interface IconSource {

	public Image getImage(String spec);
}
