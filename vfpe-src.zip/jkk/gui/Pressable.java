/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997
*/

package jkk.gui;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Vector;

public abstract class Pressable extends Component
	implements MouseListener {
	
	private static String DEF_COMMAND = "pressable";
	protected String command;
	
	private Vector actionListeners;
	
	public Pressable() {
		addMouseListener(this);
		command = DEF_COMMAND;
		actionListeners = new Vector();
	}

	public void setCommand(String cmd) {
		command = cmd;
	}

	public void addActionListener(ActionListener al) {
		actionListeners.addElement(al);
	}
	
	/* event handling */
	
	public void mouseClicked(MouseEvent evnt) { }	
	public void mouseEntered(MouseEvent evnt) { }
	public void mouseExited(MouseEvent evnt) { }
	
	public void mousePressed(MouseEvent evnt) {
		if(!isEnabled()) return;
		ActionEvent ae = new ActionEvent(this,ActionEvent.ACTION_FIRST,
			command, evnt.getModifiers());
		for(int i=0;i < actionListeners.size();i++)
			((ActionListener)actionListeners.elementAt(i)).actionPerformed(ae);
	}

	public void mouseReleased(MouseEvent evnt) { }
}
