/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1999
*/

/* for producing "faded" images for a given background colour */

package jkk.gui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Image;
import java.awt.image.ImageFilter;
import java.awt.image.ImageObserver;
import java.awt.image.ImageProducer;
import java.awt.image.RGBImageFilter;
import java.awt.image.FilteredImageSource;

public class BackgroundFilter extends RGBImageFilter {
	private int bgRGB;
	private double trans = 0.5;

	public BackgroundFilter(Color bg, double trans) {
		canFilterIndexColorModel = true;
		setBackground(bg); setTrans(trans);
	}
	
	public BackgroundFilter(Color bg) {
		this(bg,0.5);
	}

	public void setTrans(double trans) {
		this.trans = trans;
	}

	public void setBackground(Color bg) {
		bgRGB = bg.getRGB();
	}

	public int filterRGB(int x, int y, int rgb) {
		int a = rgb & 0xff000000;
		int r = (int)
			(((rgb & 0xff0000) >>> 16)*(1.0-trans) +
			((bgRGB & 0xff0000) >>> 16)*trans);
		int g = (int)
			(((rgb & 0xff00) >>> 8)*(1.0-trans) +
			((bgRGB & 0xff00) >>> 8)*trans);
		int b = (int)
			((rgb & 0xff)*(1.0-trans) + (bgRGB & 0xff)*trans);
		return a | (r<<16) | (g<<8) | b;
	}

	public static Image filter(Image img, Color bg, double t, Component c) {
		ImageFilter f = new BackgroundFilter(bg,t);
		ImageProducer prod =
			new FilteredImageSource(img.getSource(),f);
		return c.createImage(prod);
	}
		
}
