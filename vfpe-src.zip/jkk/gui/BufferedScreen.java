/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1999
*/

/*
	Whole-screen double-buffered window
*/

package jkk.gui;

import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.Window;

public class BufferedScreen extends Window {

	private Dimension d;
	private Image buf;
	
	public BufferedScreen(Frame f) {
		super(f);
		d = Toolkit.getDefaultToolkit().getScreenSize();
		setBounds(0,0,d.width,d.height);
	}

	public void paint(Graphics g) {
		if(buf == null) {
			buf = createImage(d.width,d.height);
		}
		Graphics bg = buf.getGraphics();
		bg.setColor(getBackground());
		bg.fillRect(0,0,d.width,d.height);
		super.paint(bg);
		g.drawImage(buf,0,0,null);
	}
}
