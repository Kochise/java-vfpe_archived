/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997
*/

package jkk.gui;

import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.util.Vector;

import jkk.gui.Pressable;

public class MultiLineTextLabel extends TextLabel {

	/* length becomes maximum line length */
	private int totalHeight;
	private Vector lines;
	
	public MultiLineTextLabel(String s) { super(s); }
	
	public void setText(String s) {
		lines = jkk.text.Lib.stringToLines(s);
		validate();
	}

	public void paint(Graphics g) {
		Dimension size = getSize();
		if(opaque) {
			g.setColor(getBackground());
			g.fillRect(0,0,size.width,size.height);
		}
		g.setColor(getForeground());
		int yAdvance = ascent;
		for(int i=0;i < lines.size();i++) {
			g.drawString((String)lines.elementAt(i),leadingGap,yAdvance);
			yAdvance += height;
		}
	}

	private void calcSizes() {
		FontMetrics fm = getFontMetrics(getFont());
		ascent = fm.getAscent();
		length = 0;
		for(int i=0;i < lines.size();i++)
			length = Math.max(length, 
				fm.stringWidth((String)lines.elementAt(i)));
		height = fm.getHeight();
		totalHeight = height*lines.size();
	}

	public Dimension getMinimumSize() {
		calcSizes();
		return new Dimension(length+leadingGap,totalHeight);
	}

	public Dimension getPreferredSize() {
		return getMinimumSize();
	}
}

