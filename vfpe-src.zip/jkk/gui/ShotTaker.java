/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1999
*/

package jkk.gui;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.io.FileOutputStream;
import java.io.IOException;

import jkk.Counter;

/**
	The ShotTaker captures the current appearence of a component, and
	can save it to a file.  It also attempts to keep track of the cursor
	position by listening to mouse movements.  A ShotTaker object attaches
	to a particular component, the screen shot taking functionality is
	also exposed as static methods.

	@author J Kyle Kelso, 1999.
*/
public class ShotTaker implements MouseMotionListener {

	/////////
	// fields

	protected Component c;
	protected Counter shotCounter = new Counter();
	protected Counter auxCounter;

	public String shotFilePrefix = "shot";
	public Point lastCursorPos = new Point();

	//////////////
	// constructor

	public ShotTaker(Component c) {
		this.c = c;  
		c.addMouseMotionListener(this);
	}

	//////////
	// methods

	public Image takeShot() { return click(c); }

	public void shotToFile() throws IOException {
		shotToFile(shotFilePrefix+shotCounter.nextInt()+".gif");
		auxCounter = new Counter();
	}

	public void shotToFile(Component comp) throws IOException {
		Image i = click(comp);
		String fName = shotFilePrefix+shotCounter.nextInt()+".gif";
		if(i == null)
			throw new IOException("ShotTaker couldn't create image for "+fName);
		jkk.GIFEncoder.imageToGIFFile(i,fName);
	}

	public void auxToFile(Component aux) throws IOException {
		Image i = click(aux);
		String fName = shotFilePrefix+(shotCounter.peekInt()-1)+
			"-"+auxCounter.nextInt()+".gif";
		if(i == null)
			throw new IOException("ShotTaker couldn't create image for "+fName);
		jkk.GIFEncoder.imageToGIFFile(i,fName);
	}

	public void shotToFile(String fName) throws IOException {
		Image i = takeShot();
		if(i == null)
			throw new IOException("ShotTaker couldn't create image for "+fName);
		jkk.GIFEncoder.imageToGIFFile(i,fName);
	}

	////////////////////
	// screen shot taker

	public static Image click(Component comp) {
		Dimension s = comp.getSize();
		Image buf = comp.createImage(s.width,s.height);
		if(buf == null)	return null;
		comp.update(buf.getGraphics());
		return buf;
	}

	////////////////////////////////
	// event handling - mouse motion and click triggers
	
	public void mouseMoved(MouseEvent me) { updateCursorPos(me.getPoint()); }

	public void mouseDragged(MouseEvent me) { updateCursorPos(me.getPoint()); }

	private void updateCursorPos(Point p) {
		lastCursorPos.x = p.x; lastCursorPos.y = p.y;
	}

}

