/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1998
*/

package jkk.gui;

import java.awt.Color;
import java.awt.image.IndexColorModel;

public class ColorMaps {

	public static Color [] linear(int size, Color start, Color end) {
		Color [] c = new Color [size];
		int redRange = end.getRed()-start.getRed();
		int greenRange = end.getGreen()-start.getGreen();
		int blueRange = end.getBlue()-start.getBlue();
		for(int i=0;i < size;i++) {
			float r = (float)i/(float)size;
			c[i] = new Color(
				(int)(start.getRed() + r*redRange),
				(int)(start.getGreen() + r*greenRange),
				(int)(start.getBlue() + r*blueRange));
		}
		return c;			
	}
	
	public static int [] mapToRGB(Color [] cs) {
		int [] r = new int[cs.length];
		for(int i=0;i < cs.length;i++)
			r[i] = cs[i].getRGB();
		return r;
	}
}
