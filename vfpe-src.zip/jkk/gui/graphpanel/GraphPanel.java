/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1999
*/

/*	A panel for containing a directed graph of components */
	
package jkk.gui.graphpanel;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Component;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Label;
import java.awt.Panel;
import java.awt.SystemColor;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.util.Hashtable;
import java.util.StringTokenizer;
import java.util.Vector;

import jkk.gui.ToolTipButton;

/* directed graph panel with some automated layout */

public class GraphPanel extends Panel {

	LinkLayoutPanel lp;
	Hashtable nodes;
	Label mb;
	Frame f;

	public GraphPanel() {
		nodes = new Hashtable();
		setLayout(new BorderLayout());
		lp = new LinkLayoutPanel();
		add(lp,"Center");
		add(new ControlPanel(),"North");
		mb = new Label("Hi There");
		mb.setBackground(SystemColor.control);
		add(mb,"South");
	}

	private Frame findFrameParent() {
		Container c = getParent();
		while(c != null) {
			if(c instanceof Frame) return (Frame)c;
			c = c.getParent();
		}
		return null;
	}

	// control panel class

	class ControlPanel extends Panel {
		TextField text = new TextField(10);
		
		ControlPanel() {
			setBackground(SystemColor.control);
			setLayout(new FlowLayout(2,0,FlowLayout.LEFT));
			
			Button b = new Button("add node");
			b.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent ae) {
					String [] args = getArgs();
					if(args.length < 1) {
						mb.setText("Need node name"); return;
					}
					if(nodes.containsKey(args[0])) {
						mb.setText("Duplicate node name"); return;
					}
					if(f == null) {
						f = findFrameParent();
						if(f == null) {
							mb.setText("Can't find frame"); return;
						}
					}
					ToolTipButton node = new ToolTipButton(f,args[0],null);
					lp.add(node); node.setLocation(50,50);
					node.setBackground(SystemColor.control);
					node.setSize(node.getPreferredSize());
					nodes.put(args[0],node);
					lp.repaint();
					node.isDraggable = true;
				}
			});
			add(b);

			b = new Button("delete node");
			b.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent ae) {
					String [] args = getArgs();
					if(args.length < 1) {
						mb.setText("Need node name"); return;
					}
					Component node = (Component)nodes.get(args[0]);
					if(node == null) {
						mb.setText("No node named " + args[0]); return;
					}
					lp.remove(node); nodes.remove(args[0]);
					lp.repaint();

				}
			});
			add(b);

			b = new Button("add link");
			b.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent ae) {
					String [] args = getArgs();
					if(args.length < 2) {
						mb.setText("Need two node names"); return;
					}
					Component node1 = (Component)nodes.get(args[0]);
					Component node2 = (Component)nodes.get(args[1]);
					if(node1 == null || node2 == null) {
						mb.setText("Unknown node name"); return;
					}
					lp.addLink(node1,node2); lp.repaint();
				}
			});
			add(b);

			b = new Button("delete link");
			b.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent ae) {
					String [] args = getArgs();
					if(args.length < 2) {
						mb.setText("Need two node names"); return;
					}
					Component node1 = (Component)nodes.get(args[0]);
					Component node2 = (Component)nodes.get(args[1]);
					if(node1 == null || node2 == null) {
						mb.setText("Unknown node name"); return;
					}
					lp.removeLink(node1,node2); lp.repaint();
				}
			});
			add(b);

			add(text);
		}

		private String [] getArgs() {
			Vector v = new Vector();
			StringTokenizer toks = new StringTokenizer(text.getText());
			while(toks.hasMoreTokens()) {
				v.addElement(toks.nextElement());
			}
			String [] r = new String[v.size()];
			for(int i=0;i < r.length;i++) {
				r[i] = (String)v.elementAt(i);
			}
			return r;
		}
	}

}
