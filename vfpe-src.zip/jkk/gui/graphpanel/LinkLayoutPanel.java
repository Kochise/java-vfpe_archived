/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1999
*/

/*	A panel for containing a directed graph of components */
	
package jkk.gui.graphpanel;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Point;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Random;
import java.util.Vector;

import jkk.gui.LinkPanel;
import jkk.math.V;

/* directed graph panel with some automated layout */

public class LinkLayoutPanel extends LinkPanel {

	Random rand;
	
	public LinkLayoutPanel() {
		super();
		rand = new Random();
	}

	public void jiggle(double scale) {
		Component [] comps = getComponents();
		for(int i=0;i < comps.length;i++)
			peturb(comps[i],scale);
	}

	public void peturb(Component c, double scale) {
		double theta = rand.nextDouble();
		double r = rand.nextGaussian()*scale;
		double x = Math.cos(theta)*r;
		double y = Math.sin(theta)*r;
		Point p = c.getLocation();
		c.setLocation(p.x+(int)x,p.y+(int)y);
	}

	public void attract(double scale, double optDist) {
		Enumeration keys = sources.keys();
		Hashtable forces = new Hashtable();
		
		while(keys.hasMoreElements()) {
			Component n1 = (Component)keys.nextElement();
			Enumeration e = ((Vector)sources.get(n1)).elements();
			while(e.hasMoreElements()) {
				Component n2 = (Component)e.nextElement();
				double [] p1 = V.fromPoint(n1.getLocation());
				double [] p2 = V.fromPoint(n2.getLocation());
				double [] diff = V.sub(p2,p1);
				double len = V.norm(diff);
				double mag = (optDist-len)/(len+optDist)*scale;
				double [] force = V.mul(diff,mag);
				if(!forces.containsKey(n1))
					forces.put(n1,new double[2]);
				if(!forces.containsKey(n2))
					forces.put(n2,new double[2]);
				double [] n2f = (double [])forces.get(n2);
				V.addm(n2f,force);
				double [] n1f = (double [])forces.get(n1);
				V.subm(n1f,force);
			}
		}

		Enumeration e = forces.keys();
		while(e.hasMoreElements()) {
			Component n = (Component)e.nextElement();
			double [] f = (double [])forces.get(n);
			Point p = n.getLocation();
			n.setLocation(p.x+(int)f[0],p.y+(int)f[1]);
		}
	}

	public void repel(double scale) {
		Component [] comps = getComponents();
		Object [] forces = new Object[comps.length];
		
		for(int i=0;i < comps.length;i++)
			forces[i] = new double[2];
			
		for(int i=0;i < comps.length;i++) {
			Component n1 = comps[i];
			for(int j=i+1;j < comps.length;j++) {
				Component n2 = comps[j];
				double [] p1 = V.fromPoint(n1.getLocation());
				double [] p2 = V.fromPoint(n2.getLocation());
				double [] diff = V.sub(p2,p1);
				double len = V.norm(diff);
				if(len == 0.0) {
					peturb(n1,scale); peturb(n2,scale);
				} else {
					double mag = scale/(len*len);
					double [] force = V.mul(diff,mag);
					double [] n2f = (double [])forces[j];
					V.addm(n2f,force);
					double [] n1f = (double [])forces[i];
					V.subm(n1f,force);
				}
			}
		}

		for(int i=0;i < comps.length;i++) {
			Component n = comps[i];
			double [] f = (double [])forces[i];
			Point p = n.getLocation();
			n.setLocation(p.x+(int)f[0],p.y+(int)f[1]);
		}
	}

	public void iterate(
		int n, double rand, double opt, double attr, double repl,
		boolean redraw) {
		for(int i=0; i < n;i++) {
			jiggle(rand);
			attract(attr,opt);
			repel(repl);
			if(redraw) repaint();
		}
	}

	/*	useful setting for this are
		rand 10.0 opt 50.0 attr 0.5 repl 100.0
		over, say, 100 iterations
	*/
	public void relax(
		int n, double rand, double opt, double attr, double repl,
		boolean redraw) {
		for(int i=0; i < n;i++) {
			jiggle(rand*(((double)n - (double)i)/(double)n));
			attract(attr,opt);
			repel(repl);
			if(redraw) repaint();
		}
	}
	
	private double len(Point p) {
		return Math.sqrt(p.x*p.x+p.y*p.y);
	}

}
