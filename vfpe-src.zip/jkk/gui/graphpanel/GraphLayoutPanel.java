/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1999
*/

/*	A panel for containing a graph of components with
	automated layout */
	
package jkk.gui.graphpanel;

import java.awt.Button;
import java.awt.Label;
import java.awt.Panel;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import jkk.gui.Bordered;
import jkk.gui.DoubleField;
import jkk.gui.GridBagPanel;
import jkk.gui.IntField;
import jkk.gui.ToolTipButton;

/* directed graph panel with some automated layout */

public class GraphLayoutPanel extends GraphPanel {

	DoubleField randField, attrOptField, attrScaleField, repelField;
	IntField iterField;
	
	public GraphLayoutPanel() {
		super();

		GridBagPanel gbp = new GridBagPanel();

		Button b = new Button("Randomise");
		gbp.add(b,"position=0,0,1,1 fill=NONE");
		b.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				if(!randField.validDouble()) return;
				lp.jiggle(randField.getDouble());
				lp.repaint();
			}
		});
		gbp.add(randField = new DoubleField(),
			"position=1,0,2,1 fill=HORIZONTAL");

		b = new Button("Attract");
		gbp.add(b,"position=0,1,1,1 fill=NONE");
		b.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				if(!attrOptField.validDouble()) return;
				if(!attrScaleField.validDouble()) return;
				lp.attract(attrScaleField.getDouble(),
					attrOptField.getDouble());
				lp.repaint();
			}
		});
		gbp.add(attrOptField = new DoubleField(5),
			"position=1,1,1,1 fill=HORIZONTAL");
		gbp.add(attrScaleField = new DoubleField(5),
			"position=2,1,1,1 fill=HORIZONTAL");

		b = new Button("Repel");
		gbp.add(b,"position=0,2,1,1 fill=NONE");
		b.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				if(!repelField.validDouble()) return;
				lp.repel(repelField.getDouble());
				lp.repaint();
			}
		});
		gbp.add(repelField = new DoubleField(),
			"position=1,2,2,1 fill=HORIZONTAL");

		b = new Button("Iterate");
		gbp.add(b,"position=0,3,1,1 fill=NONE");
		b.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				if(!iterField.validInt()) return;
				if(!randField.validDouble()) return;
				if(!repelField.validDouble()) return;
				if(!attrOptField.validDouble()) return;
				if(!attrScaleField.validDouble()) return;
				lp.iterate(iterField.getInt(),
					randField.getDouble(),
					attrOptField.getDouble(),
					attrScaleField.getDouble(),
					repelField.getDouble(),true);
				lp.repaint();
			}
		});
		gbp.add(iterField = new IntField(),
			"position=1,3,2,1 fill=HORIZONTAL");

		b = new Button("Relax");
		gbp.add(b,"position=0,4,1,1 fill=NONE");
		b.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				if(!iterField.validInt()) return;
				if(!randField.validDouble()) return;
				if(!repelField.validDouble()) return;
				if(!attrOptField.validDouble()) return;
				if(!attrScaleField.validDouble()) return;
				lp.relax(iterField.getInt(),
					randField.getDouble(),
					attrOptField.getDouble(),
					attrScaleField.getDouble(),
					repelField.getDouble(),true);
				lp.repaint();
			}
		});

		Bordered bp = new Bordered(Bordered.SQUARE,Bordered.ETCHED,15);
		bp.title = "Layout";
		bp.add(gbp,"");
		add(bp,"East");
	}
}
