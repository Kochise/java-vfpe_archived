/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1998
*/

package jkk.gui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;

import jkk.math.Lib;

public class Histogram extends Component {

	private static int MARGINS = 10;
	public int[] data;
	public int max, min;
	public Color color = Color.black;
	
	public Histogram() { }
	
	public void paint(Graphics g) {
		Dimension size = getSize();
		size.setSize(size.width - MARGINS*2,size.height - MARGINS*2);
		g.setColor(color);
	
		/* interpolate linearly */
		
		for(int i=0;i < size.width;i++) {
			float r = (float)i*(float)data.length/(float)size.width;
			int j = (int)r; 
			if(j+1 >= data.length) break;
			float rem = (float)Lib.fract(r);	
			int h = (int)(data[j] + rem*(data[j+1] - data[j]));
			int ph = (h - min)*size.height/(max - min);
			
			g.drawLine(MARGINS+i,MARGINS+size.height-ph,MARGINS+i,MARGINS+size.height);
		}
	}
	
	
	
	public Dimension getPreferredSize() {
		return new Dimension(data.length + MARGINS*2,max - min + MARGINS*2);
	}
}
