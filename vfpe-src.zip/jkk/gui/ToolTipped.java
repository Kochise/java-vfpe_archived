/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997
*/
	
package jkk.gui;

import java.awt.Container;
import java.awt.Panel;
import java.awt.Point;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import jkk.Functor;
import jkk.Timer;

public class ToolTipped extends Container
	implements MouseListener, MouseMotionListener {
	
	protected long TIP_DELAY = 500;
	protected Timer alarm;
	protected boolean tipPosted;
	protected Point lastMousePos;
	
	/* constructor -------------------------------------------------- */

	public ToolTipped() { 
		super(); 
		tipPosted = false;
		alarm = new Timer(TIP_DELAY,new TipTimerFunctor(this));
		addMouseListener(this);
		addMouseMotionListener(this);
	}

	/* ToolTip API -------------------------------------------------- */
	
	public void postTip() {
		tipPosted = true;
	}
	
	public void unpostTip() {
		tipPosted = false;
	}

	public void resetTipTimer() {
		if(tipPosted)
			unpostTip();
		alarm.reset();
	}

	/* event handling------------------------------------------------ */

	public void mouseClicked(MouseEvent evnt) {
		jiggle(evnt);
		//resetTipTimer();
	}
	
	public void mouseEntered(MouseEvent evnt) {
		if(!alarm.isRunning()) alarm.start();
	}
	
	public void mouseExited(MouseEvent evnt) {
		resetTipTimer();
	}
	
	public void mousePressed(MouseEvent evnt) {
		jiggle(evnt);
		//resetTipTimer();
	}

	public void mouseReleased(MouseEvent evnt) { jiggle(evnt); }

	public void mouseDragged(MouseEvent evnt) { jiggle(evnt); }
	
	public void mouseMoved(MouseEvent evnt) { jiggle(evnt); }

	/* what exactly should this behaviour be ? */
	public void jiggle(MouseEvent evnt) {
		if(tipPosted) unpostTip();
		lastMousePos = evnt.getPoint();
		if(alarm.isRunning()) {
			alarm.reset(); alarm.start();
		}
	}
}

class TipTimerFunctor extends Functor {
	private ToolTipped ttc;

	public TipTimerFunctor(ToolTipped ttc) {
		this.ttc = ttc;
	}
	
	public Object eval(Object x) {
		ttc.postTip(); return null;
	}
}

