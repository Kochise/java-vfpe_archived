/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1999
*/

package jkk.gui.glyph;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import java.util.Vector;

public abstract class Glyph {

	//////////////////
	// glyph interface

	public boolean listening;

	public abstract void render(Graphics g, int x, int y, double scale);

	public abstract Vector getSectors(int x, int y, int sSize);

	public void handleMouseEvent(MouseEvent me, int x, int y, double scale) { }

	////////
	// tools

	public Vector sectorsForRectangle(Rectangle clip, int sSize) {
		Vector v = new Vector();

		for(int j=clip.x;j < clip.x+clip.width;j+=sSize) {
			for(int i=clip.y;i < clip.y+clip.height;i+=sSize) {
				v.addElement(new Integer(j/sSize));
				v.addElement(new Integer(i/sSize));
			}
		}
		v.addElement(new Integer((clip.x+clip.width)/sSize));
		v.addElement(new Integer(clip.y/sSize));
		v.addElement(new Integer((clip.x+clip.width)/sSize));
		v.addElement(new Integer((clip.y+clip.height)/sSize));
		v.addElement(new Integer(clip.x/sSize));
		v.addElement(new Integer((clip.y+clip.height)/sSize));

		return v;
	}

}
