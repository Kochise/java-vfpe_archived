/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1999
*/

package jkk.gui.glyph;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.util.Vector;

public class LineGlyph extends Glyph {

	/////////
	// fields

	public Color c;
	public int thickness;
	public int dX, dY;

	///////////////
	// constructors

	public LineGlyph(Color c, int dX, int dY, int thickness) {
		this.thickness = thickness; this.c = c;
		this.dX = dX; this.dY = dY;
	}

	//////////////////
	// glyph interface

	private static final double K = Math.sqrt(2.0)-1;

	public void render(Graphics g, int x, int y, double scale) {

//FEATURE
// should we scale line thicknesses ?

		// deal with thinning of diagonal lines
		double small = (double)Math.min(Math.abs(dX),Math.abs(dY));
		double large = (double)Math.max(Math.abs(dX),Math.abs(dY));
		int t = (int)(((double)thickness)*(1.0+(small/large)*K));

		// render line
		g.setColor(c);
		int sx = x-t/2;
		int sy = y;
		for(int i=0;i < t;i++)
			g.drawLine(sx+i,sy,(int)(sx+i+dX/scale),(int)(sy+dY/scale));
		sx = x;
		sy = y-t/2;
		for(int i=0;i < t;i++)
			g.drawLine(sx,sy+i,(int)(sx+dX/scale),(int)(sy+i+dY/scale));
	}

	public Vector getSectors(int x, int y, int sSize) {
		Vector v = new Vector();
		int n = Math.max(1,Math.max(dX,dY)/sSize)*2;
		for(int i=0;i <= n;i++) {
			v.addElement(new Integer((x + i*(dX/n))/sSize));
			v.addElement(new Integer((y + i*(dY/n))/sSize));
		}
		return v;
	}

}
