/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1999-2000
*/

package jkk.gui.glyph;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.Hashtable;
import java.util.Vector;

import jkk.Comparator;

public class GlyphPanel extends /* Canvas */ Component /* Container */ 
	implements MouseListener, MouseMotionListener {

	////////////
	// constants

	private static final int DEF_BUF_SIZE = 100;
	public static final int DOUBLE_BUF = 0;
	public static final int SLIDING_BUF = 1;
	public static final int NO_BUF = 2;

	/////////
	// fields

	public Color background = Color.black;

	protected int bufMode = DOUBLE_BUF;
	protected Dimension size;
	protected int sectorSize;
	protected int xOrigin, yOrigin;
	private Hashtable glyphs;
	public double scale;

	// this contains a hashtables for each populated sector column
	// hashtables are are keyed on Integers
	private Hashtable [] sectors;

	///////////////
	// constructors

	public GlyphPanel(Dimension size, int sSize, int depth) {
		this.size = size; glyphs = new Hashtable();
		setSize(size);
		sectorSize = sSize;
		xOrigin = size.width/2; yOrigin = size.height/2;
		sectors = new Hashtable[depth];
		for(int i=0;i < depth;i++)
			sectors[i] = new Hashtable();
		scale = 1.0;

		buffer = createImage(DEF_BUF_SIZE,DEF_BUF_SIZE);
		bufRect = new Rectangle(0,0,DEF_BUF_SIZE,DEF_BUF_SIZE);

		addMouseListener(this); addMouseMotionListener(this);
	}

	//////////
	// methods

	public void addGlyph(Glyph g, int x, int y, int z, boolean fixed) {

		// find sectors for glyph
		Vector ss = g.getSectors(x,y,sectorSize);

		// add glyph to all sectors
		GlyphEntry ge = new GlyphEntry(g,x,y,z);
		for(int i=0;i < ss.size();i += 2) {
			Integer ix = (Integer)ss.elementAt(i);
			Integer iy = (Integer)ss.elementAt(i+1);
			Vector s = getSector(ix,iy,z);
			if(!s.contains(ge)) {
				s.addElement(ge);
			}
		}

		// add glyph to table if not fixed
		if(!fixed)
			glyphs.put(g,ge);
	}

	public void removeGlyph(Glyph g) {
		GlyphEntry ge = (GlyphEntry)glyphs.get(g);
		Vector ss = g.getSectors(ge.x,ge.y,sectorSize);
		for(int i=0;i < ss.size();i += 2) {
			Integer ix = (Integer)ss.elementAt(i);
			Integer iy = (Integer)ss.elementAt(i+1);
			Vector s = peekSector(ix,iy,ge.z);
			// is this worthwhile ?
			if(s != null) {
				s.removeElement(ge);
				if(s.size() == 0) {
					Hashtable col = peekColumn(ix,ge.z);
					col.remove(iy);
					if(col.size() == 0) {
						sectors[ge.z].remove(ix);
					}
				}
			}
		}
	}

	public int scl(int x) {
		return (int)(x*scale);
	}

	public int unscl(int x) {
		return (int)(x/scale);
	}

	////////////////
	// layout stuff

	public Dimension getPreferredSize() { return size; }

	//////////
	// painter

	public void changeBufMode(int bufMode) {
		this.bufMode = bufMode;
		if(bufMode == DOUBLE_BUF) {
			bufRect.x = 0; bufRect.y = 0;
		}
	}

	private static final double BUF_FACTOR = 1.5;
	private static final int BIG = 1024;

	private Image buffer;
	private Rectangle bufRect;
	private Rectangle glyphWindow;

	public void paint(Graphics g) {

		Rectangle clip = g.getClipBounds();
		if(clip.width > BIG || clip.height > BIG) {
			jkk.gui.Lib.clipClip(g,this);
			clip = g.getClipBounds();
		}
		if(bufMode == NO_BUF || clip.width > BIG || clip.height > BIG) {
			rawPaint(g,new Rectangle(g.getClipBounds()));
			return;
		}

		if(bufMode == DOUBLE_BUF) {
			checkBufSize(clip,1.0);
			Graphics bufG = buffer.getGraphics();
			bufG.setClip(0,0,clip.width,clip.height);
			bufG.translate(-clip.x,-clip.y);
			rawPaint(bufG,new Rectangle(clip));
			g.drawImage(buffer,
				clip.x,clip.y,clip.x+clip.width,clip.y+clip.height,
				0,0,clip.width,clip.height,null);
			return;
		}

		// check for buffer update

		if(!bufRect.union(clip).equals(bufRect)) {

			// check for enlargement
			checkBufSize(clip,BUF_FACTOR);

			// update buffer

			int clipXc = clip.x + clip.width/2;
			int clipYc = clip.y + clip.height/2;
			bufRect.x = clipXc - bufRect.width/2;
			bufRect.y = clipYc - bufRect.height/2;
			Graphics bufG = buffer.getGraphics();
			bufG.setClip(0,0,bufRect.width,bufRect.height);
			bufG.translate(-bufRect.x,-bufRect.y);
			glyphWindow = new Rectangle(bufRect);
			rawPaint(bufG,glyphWindow);
		}

		// blit

		g.drawImage(buffer,bufRect.x,bufRect.y,null);
	}

	private void checkBufSize(Rectangle clip, double factor) {
		if(clip.width > bufRect.width ||
			clip.height > bufRect.height) {
			int newW = (int)(clip.width*factor);
			int newH = (int)(clip.height*factor);
			buffer = createImage(newW,newH);
			bufRect.width = newW; bufRect.height = newH;
		}
	}

	public void rawPaint(Graphics g, Rectangle w) {

		Rectangle clip = new Rectangle(g.getClipBounds());
		if(background != null) {
			g.setColor(background);
			g.fillRect(clip.x,clip.y,clip.width,clip.height);
		}

		// render all glyphs, in depth order, in clip region
		
		w.translate(-xOrigin,-yOrigin);
		w.setBounds(scl(w.x),scl(w.y),scl(w.width),scl(w.height));

		//Hashtable already = new Hashtable();
		for(int k=0;k < sectors.length;k++) {
			int leftLimit = w.x-sectorSize/2;
			int rightLimit = w.x+w.width+sectorSize/2;
			for(int j=leftLimit;j < rightLimit;j+=sectorSize) {
				int topLimit = w.y-sectorSize/2;
				int bottomLimit = w.y+w.height+sectorSize/2;
				for(int i=topLimit;i < bottomLimit;i+=sectorSize) {
					int x = j/sectorSize;
					int y = i/sectorSize;
					Vector s = peekSector(x,y,k);
					if(s == null) continue;
					for(int l=0;l < s.size();l++) {
						GlyphEntry ge = (GlyphEntry)s.elementAt(l);
		//				if(!already.containsKey(ge)) {
							ge.g.render(g,
								unscl(ge.x)+xOrigin,unscl(ge.y)+yOrigin,
								scale);
		//					already.put(ge,ge);
		//				}
					}
				}
			}
		}

	}

	/////////////////
	// event handling

	public void mouseEntered(MouseEvent me) { }
	public void mouseExited(MouseEvent me) { }

	public void mousePressed(MouseEvent me) { alertGlyphs(me); }
	public void mouseReleased(MouseEvent me) { alertGlyphs(me); }
	public void mouseClicked(MouseEvent me) { alertGlyphs(me); }
	public void mouseDragged(MouseEvent me) { }
	public void mouseMoved(MouseEvent me) { }

	// report event to first interested glyph in glyph co-ords
	public void alertGlyphs(MouseEvent me) {
		int x = scl(me.getX()-xOrigin);
		int y = scl(me.getY()-yOrigin);
		int i = x/sectorSize;
		int j = y/sectorSize;
		for(int k=sectors.length-1;k >= 0;k--) {
			Vector gv = peekSector(i,j,k);
			for(int l = 0;l < gv.size();l++) {
				GlyphEntry ge = (GlyphEntry)gv.elementAt(l);
				if(ge.g.listening)
					ge.g.handleMouseEvent(me,x-ge.x,y-ge.y,scale);
				if(me.isConsumed())
					return;
			}
		}
	}

	////////
	// tools

	private Vector getSector(int x, int y, int z) {
		return getSector(new Integer(x), new Integer(y),z);
	}

	private Vector getSector(Integer x, Integer y, int z) {
		Hashtable col = getColumn(x,z);
		if(!col.containsKey(y)) {
			col.put(y, new Vector());
		}
		return (Vector)col.get(y);
	}

	private Hashtable getColumn(Integer x, int z) {
		Hashtable cols = sectors[z];
		if(!cols.containsKey(x)) {
			cols.put(x,new Hashtable());
		}
		return (Hashtable)cols.get(x);
	}

	private Vector peekSector(int x, int y, int z) {
		return getSector(new Integer(x), new Integer(y),z);
	}

	private Vector peekSector(Integer x, Integer y, int z) {
		Hashtable col = getColumn(x,z);
		if(col == null) return null;
		if(!col.containsKey(y))
			return null;
		return (Vector)col.get(y);
	}

	private Hashtable peekColumn(Integer x, int z) {
		Hashtable cols = sectors[z];
		if(!cols.containsKey(x)) return null;
		return (Hashtable)cols.get(x);
	}
}

class GlyphEntry {
	Glyph g;
	int x, y, z;

	public GlyphEntry(Glyph g, int x, int y, int z) {
		this.g = g; this.x = x; this.y = y; this.z = z;
	}
}

