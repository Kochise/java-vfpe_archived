/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1999
*/

package jkk.gui.glyph;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.util.Vector;

public class TextGlyph extends Glyph {

	/////////
	// fields

	private String text;
	private Font f;
	public Color c;
	private int xOffset, yOffset;
	private Dimension bounds;
	private boolean centered;

	///////////////
	// constructors

	public TextGlyph(String s, Font f, Color c, boolean centered) {
		text = s; this.f = f; this.c = c;
		this.centered = centered;
		calcBounds();
	}

	private void calcBounds() {
		FontMetrics fm = Toolkit.getDefaultToolkit().getFontMetrics(f);
		bounds = new Dimension(fm.stringWidth(text),fm.getHeight());
	}

	//////////////////
	// glyph interface

	public void render(Graphics g, int x, int y, double scale) {
		if(centered)
			x -= bounds.width/2;
		g.setFont(f); g.setColor(c);
		g.drawString(text,x,y);
	}

	public Vector getSectors(int x, int y, int sSize) {
		Rectangle r = new Rectangle(x,y,bounds.width,bounds.height);
		if(centered)
			r.translate(0,-bounds.width/2);
		return sectorsForRectangle(r,sSize);
	}

}
