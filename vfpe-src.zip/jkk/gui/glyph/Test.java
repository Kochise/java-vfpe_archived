
package jkk.gui.glyph;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Label;
import java.awt.ScrollPane;

public class Test {

	public static void main(String [] argv) {
		int s = 4000;
		GlyphPanel gp = new GlyphPanel(new Dimension(s,s),
			100,1);
		TextGlyph word = new TextGlyph("Hello",
			new Font("Sans-Serif",Font.PLAIN,12),Color.black,true);
		for(int i= -s/2;i < s/2;i += 80) {
			for(int j= -s/2;j < s/2;j += 50) {
				gp.addGlyph(word,i,j,0,true);
			}
		}

		gp.invalidate();
		ScrollPane sp = new ScrollPane();
		sp.add(gp);
		Frame f = new Frame("Glyph Test");
		f.add(sp,"Center");
		f.pack();
		f.setVisible(true);
	}
}
