/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997-2000
*/

package jkk.gui;

import java.awt.Button;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Image;
import java.awt.Insets;
import java.awt.Label;
import java.awt.MediaTracker;
import java.awt.Menu;
import java.awt.MenuItem;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.TextArea;
import java.awt.TextComponent;
import java.awt.TextField;
import java.awt.Toolkit;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.ImageProducer;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.IOException;
import java.net.URL;
import java.util.Enumeration;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.Vector;

import jkk.gui.GridBagPanel;

public class Lib {

    /* hopefully optimises stupidly large clip bounds */

    public static void clipClip(Graphics g, Component c) {
        Container cnt = c.getParent();
        if(cnt == null) return;
        Point p = c.getLocation();
        Dimension d = cnt.getSize();
        Rectangle newClip = g.getClipBounds().intersection(
            new Rectangle(-p.x,-p.y,d.width,d.height));
        g.setClip(newClip);
    }

    /* component heirarchy stuff */

    public static Frame getParentFrame(Component c) {
        while(c != null) {
            if(c instanceof Frame)
                return (Frame)c;
            c = c.getParent();
        }
        return null;
    }

    /* layout stuff */

    public static Rectangle childBounds(Container c) {
        Component [] comps = c.getComponents();
        if(comps.length == 0) return null;
        Rectangle b = comps[0].getBounds();
        int minX = b.x; int minY = b.y;
        int maxX = minX + b.width; int maxY = minY + b.height;
        for(int i=1;i < comps.length;i++) {
             b = comps[i].getBounds();
            minX = Math.min(minX,b.x);
            minY = Math.min(minY,b.y);
            maxX = Math.max(maxX,b.x+b.width);
            maxY = Math.max(maxY,b.y+b.height);
        }
        return new Rectangle(minX,minY,maxX-minX,maxY-minY);
    }

    public static void centreChildBounds(Container c) {
        Rectangle cb = childBounds(c);
        Dimension size = c.getSize();
        int dx = (size.width - cb.width)/2 - cb.x;
        int dy = (size.height - cb.height)/2 - cb.y;
        Component [] comps = c.getComponents();
        Point loc = new Point();
        for(int i=0;i < comps.length;i++) {
            loc = comps[i].getLocation();
            comps[i].setLocation(loc.x+dx,loc.y+dy);
        }
    }
    
    /* Window positioning stuff */

    public static Point centre(Component c) {
        Point pos = c.getLocation();
        Dimension size = c.getSize();
        return new Point(pos.x+size.width/2,pos.y+size.height/2);
    }

    public static void locateNear(Component c, Component p) {
        Point pLoc = p.getLocationOnScreen();
        Dimension pSize = p.getSize();
        Dimension cSize = c.getSize();
        Dimension sSize = Toolkit.getDefaultToolkit().getScreenSize();
        String corner = "";
        if(pLoc.x+pSize.width+cSize.width > sSize.width)
            corner += "W";
        if(pLoc.y+pSize.height+cSize.height > sSize.height)
            corner += "N";
        locateNear(c,p,corner);
    }

    public static void screenCentre(Window w) {
        Dimension wSize = w.getSize();
        Dimension sSize = Toolkit.getDefaultToolkit().getScreenSize();
        w.setLocation(
            (sSize.width-wSize.width)/2,(sSize.height-wSize.height)/2);
    }

    public static final int NEAR_GAP = 10;
    public static void locateNear(Component c, Component p, String corner) {
        Point pLoc = p.getLocationOnScreen();
        Dimension pSize = p.getSize();
        Dimension cSize = c.getSize();
        String cnr = corner.toUpperCase();
        int cX, cY;
        if(cnr.indexOf('N') != -1)
            cY = pLoc.y-cSize.height-NEAR_GAP;
        else
            cY = pLoc.y+pSize.height+NEAR_GAP;
        if(cnr.indexOf('W') != -1)
            cX = pLoc.x-cSize.width;
        else
            cX = pLoc.x+pSize.width;
        c.setLocation(cX,cY);
    }

    /* Cursor stuff */

    public static void setCursorForTree(Component c, Cursor cs) {
        c.setCursor(cs);
        if(c instanceof Container) {
            Component [] comps = ((Container)c).getComponents();
            for(int i=0;i < comps.length;i++)
                setCursorForTree(comps[i],cs);
        }
    }

    /* image stuff */

    public static Image imageFromInputStream(InputStream is) throws IOException
    {
        return imageFromInputStream(is,false);
    }
   
    public static Image imageFromInputStream(
        InputStream is, boolean closeStream) throws IOException {
        byte [] imagedata = jkk.io.Lib.slurpStream(is);
        Image i = imageFromByteArray(imagedata);
        if(closeStream) is.close();
        return i;
   }

    public static Image imageFromFile(String fName, Component waiter) {
        Image i = null;
        try {
            FileInputStream fis = new FileInputStream(fName);
            i = imageFromInputStream(fis,true);
        } catch(IOException ioe) {
            return null;
        }
        if(waiter != null)
            waitForImage(i,waiter);
        return i;
    }

    public static Image imageFromByteArray(byte [] imagedata) {
        Image i = Toolkit.getDefaultToolkit().createImage(imagedata);
        return i;
    }

    public static Image imageFromURL(URL url,Component waiter) {
        ImageProducer ip = null;
        try {
            ip = (ImageProducer)url.getContent();
        } catch(IOException ioe) { }
        if(ip == null) return null;
        Image icon = Toolkit.getDefaultToolkit().createImage(ip);
        if(waiter != null)
            waitForImage(icon,waiter);
        return icon;
    }

       public static void waitForImage(Image img, Component waiter) {
        MediaTracker mt = new MediaTracker(waiter);
          mt.addImage(img,0);
          try {
            mt.waitForID(0);
          } catch(InterruptedException ie) { }
       }

       /* rendering stuff */

       public static void drawParagraph(Graphics g, Vector para, int x, int y, int lh) {
        for(int i=0;i < para.size();i++) {
            g.drawString(para.elementAt(i).toString(),x,y);
            y += lh;
        }
       }

    public static void tileImage(Graphics g, Image img, Rectangle rect) {
          int imgWidth = img.getWidth(null);
          int imgHeight = img.getHeight(null);
          int xBound = rect.width/imgWidth + 1;
          int yBound = rect.height/imgHeight + 1;
          for(int i=0;i < xBound;i++)
            for(int j=0;j < yBound;j++)
                   g.drawImage(img,rect.x + i*imgWidth,rect.y + j*imgHeight,null);
    }

    public static void alignString(Graphics g, int x, int y, String s, String dir) {
        FontMetrics fm = g.getFontMetrics();
        int sw = fm.stringWidth(s);
        if(dir.equals("right"))
            x -= sw;
        else if(dir.equals("centre"))
            x -= sw/2;
        g.drawString(s,x,y);
    }
    
    /* menu stuff */

    public static void sortMenu(Menu m) {
        int n = m.getItemCount();
        MenuItem minItem;
        while(n > 0) {
            minItem = Lib.findMinMenuItem(m,n);
            m.remove(minItem); m.add(minItem);
            n--;
        }
    }

    private static MenuItem findMinMenuItem(Menu m, int n) {
        MenuItem min = m.getItem(0);
        for(int i=1;i < n;i++)
            if(m.getItem(i).getLabel().compareTo(min.getLabel()) < 0)
                min = m.getItem(i);
        return min;
    }

    public static MenuItem findItem(String s,Menu m) {
        for(int i=0;i < m.getItemCount();i++)
            if(m.getItem(i).getLabel().equals(s))
                return m.getItem(i);
        return null;
    }

    /* GridBagLayout stuff */

    public static void setGBConstraints(
        GridBagConstraints gbs, String cts) {
            
        Properties props = jkk.text.Lib.readProperties(cts," ");
        Enumeration e = props.keys();
        while(e.hasMoreElements()) {
            String cname = (String)e.nextElement();
            String cval = props.getProperty(cname);

            if(cname.equals("anchor")) {
                if(cval.equals("NORTH"))
                    gbs.anchor = GridBagConstraints.NORTH;
                else if(cval.equals("NORTHWEST"))
                    gbs.anchor = GridBagConstraints.NORTHWEST;
                else if(cval.equals("WEST"))
                    gbs.anchor = GridBagConstraints.WEST;
                else if(cval.equals("SOUTHWEST"))
                    gbs.anchor = GridBagConstraints.SOUTHWEST;
                else if(cval.equals("SOUTH"))
                    gbs.anchor = GridBagConstraints.SOUTH;
                else if(cval.equals("SOUTHEAST"))
                    gbs.anchor = GridBagConstraints.SOUTHEAST;
                else if(cval.equals("EAST"))
                    gbs.anchor = GridBagConstraints.EAST;
                else if(cval.equals("NORTHEAST"))
                    gbs.anchor = GridBagConstraints.NORTHEAST;
                else
                    gbs.anchor = GridBagConstraints.CENTER;
            }
            
            if(cname.equals("fill")) {
                if(cval.equals("HORIZONTAL"))
                    gbs.fill = GridBagConstraints.HORIZONTAL;
                else if(cval.equals("VERTICAL"))
                    gbs.fill = GridBagConstraints.VERTICAL;
                else if(cval.equals("BOTH"))
                    gbs.fill = GridBagConstraints.BOTH;
                else
                    gbs.fill = GridBagConstraints.NONE;
            }

            if(cname.equals("position")) {
                StringTokenizer ps = new StringTokenizer(cval,",");
                try {
                    gbs.gridx = Integer.parseInt(ps.nextToken());
                    gbs.gridy = Integer.parseInt(ps.nextToken());
                    gbs.gridwidth = Integer.parseInt(ps.nextToken());
                    gbs.gridheight = Integer.parseInt(ps.nextToken());
                } catch(NumberFormatException nfe) { }
            }

            if(cname.equals("insets")) {
                StringTokenizer ps = new StringTokenizer(cval,",");
                Insets ins = new Insets(0,0,0,0);
                try {
                    ins.top = Integer.parseInt(ps.nextToken());
                    ins.left = Integer.parseInt(ps.nextToken());
                    ins.bottom = Integer.parseInt(ps.nextToken());
                    ins.right = Integer.parseInt(ps.nextToken());
                } catch(NumberFormatException nfe) { }
                gbs.insets = ins;
            }

            if(cname.equals("padding")) {
                StringTokenizer ps = new StringTokenizer(cval,",");
                try {
                    gbs.ipadx = Integer.parseInt(ps.nextToken());
                    gbs.ipady = Integer.parseInt(ps.nextToken());
                } catch(NumberFormatException nfe) { }
            }

            if(cname.equals("weight")) {
                StringTokenizer ps = new StringTokenizer(cval,",");
                try {
                    gbs.weightx = (new Float(ps.nextToken())).floatValue();
                    gbs.weighty = (new Float(ps.nextToken())).floatValue();
                } catch(NumberFormatException nfe) { }
            }
        } // end of while-more-constraints
    } // end of method setGBConstraints

    public static String GBC_DEFAULTS =
        "anchor=CENTER fill=BOTH position=0,0,1,1 " +
        "insets=0,0,0,0 padding=0,0 weight=1.0,1.0";
        
    public static void constrain(
        Container cont, Component comp, String cts) {

        GridBagConstraints gbc = new GridBagConstraints();
        setGBConstraints(gbc,GBC_DEFAULTS);
        setGBConstraints(gbc,cts);

        ((GridBagLayout)cont.getLayout()).setConstraints(comp,gbc);
        cont.add(comp);
    }

    /* dialog stuff */

    public static String requestString(String title, String prompt,
        Frame parent) {
        return requestString(title,prompt,parent,"",false);
    }
    
    public static String requestString(String title, String prompt,
        Frame parent, String defText, boolean multiline) {
       return requestString(title,prompt,parent,defText,false,null);    
    }
    
    public static String requestString(String title, String prompt,
        Frame parent, String defText, boolean multiline, Component near) {

        StringRequester sr = 
            new StringRequester(title,prompt,parent,defText,multiline);
        if(near != null)
            locateNear(sr,near);
        else
            screenCentre(sr);
       
        sr.setVisible(true);
        return sr.getString();
    }

    public static String requestChoice(String title, String prompt,
        String [] choices, Frame parent) {
        return requestChoice(title,prompt,choices,parent,null);
    }

    public static String requestChoice(String title, String prompt,
        String [] choices, Frame parent, Component near) {

        ChoiceRequester cr = new ChoiceRequester(
            title,prompt,choices,parent);
        if(near != null)
            locateNear(cr,near);
        else
            screenCentre(cr);
        cr.setVisible(true);
        return cr.getChoice();
    }
}

