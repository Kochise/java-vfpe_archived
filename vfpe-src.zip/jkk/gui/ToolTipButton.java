/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1998
*/

package jkk.gui;

import java.awt.Color;
import java.awt.Frame;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import jkk.gui.Bordered;
import jkk.gui.GridBagPanel;
import jkk.gui.ImageLabel;
import jkk.gui.PopupLabel;
import jkk.gui.TextLabel;

/* this implementation is for simple text-labeled buttons */

public class ToolTipButton extends Bordered {

    protected static int BORDER_SIZE = 2;
    private PopupLabel tip;
    private Frame parent;
    private TextLabel button;
    private ImageLabel iButton;

    public String tipText;
	public Color tipBackground = null;

	/* constructor -------------------------------------------------- */

	public ToolTipButton(Frame parent, String title, String tipText) { 
        super(Bordered.SQUARE,Bordered.RAISED,BORDER_SIZE);
        this.tipText = tipText;
   		this.parent = parent;
        add("",button = new TextLabel(title));
	}

	public ToolTipButton(Frame parent, Image img, String tipText) {
		super(Bordered.SQUARE,Bordered.RAISED,BORDER_SIZE);
        this.tipText = tipText;
   		this.parent = parent;
        add("",iButton = new ImageLabel(img));
	}

	/* control ------------------------------------------------------ */

	public void addActionListener(ActionListener l) {
		if(button != null)
			button.addActionListener(l);
		if(iButton != null)
			iButton.addActionListener(l);
	}

	public void setCommand(String cmd) {
		if(button != null)
			button.setCommand(cmd);
		if(iButton != null)
			iButton.setCommand(cmd);
	}

	public void setEnabled(boolean en) {
		super.setEnabled(en);
		if(button != null)
			button.setEnabled(en);
		if(iButton != null)
			iButton.setEnabled(en);
	}
		
	/* ToolTip handling --------------------------------------------- */

	public void postTip() {
		if(tipText == null) return;
		super.postTip();
		if(!isShowing()) return;
		tip = new PopupLabel(parent,tipText,this);
		if(tipBackground != null)
			tip.setBackground(tipBackground);
		tip.setVisible(true);
	}

	public void unpostTip() {
		super.unpostTip();
		if(tip != null) {
			tip.setVisible(false); tip.dispose();
		}
	}

}
