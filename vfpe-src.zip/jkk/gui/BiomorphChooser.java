/*
        / \
      /     \
     |\     / \ / \  chiral software
     |  \ /     \   \
      \  |\     /|  /|
        \|  \ /  |/  |
         |\  |  /|  /
         |  \|/  |/
          \  |  /
            \|/
*/

package jkk.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.GridLayout;
import java.util.Hashtable;
import java.util.Random;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

import jkk.Lib;
import jkk.Mutating;

/**
    This class is a GUI component for doing biomorph-style (a la 
    Dawkins) walks through discrete multidimensional spaces.
    The object used are javax.swing.Icons that also implement
    jkk.Mutating .
*/
public class BiomorphChooser extends JPanel implements 
    ActionListener, DocumentListener {

    ////////////
    // constants

    private static final int KEY_FLAG = 5;
    private static final String SET_CMD = "SET";

    /////////
    // fields

    /** Numbered Icons, 1 = NW, 9 = SE etc. */
    private Hashtable flags = new Hashtable();
    private Random rand = new Random();

    private JTextField specField;
    private JButton setButton;

    //////////////
    // constructor

    /**
        @param cName fully qualified classname of instance of
            javax.swing.Icon and jkk.Mutating, with zero-arg
            constructor for dynamic instantiation.
        @param startSpec starting spec for walk.
    */
    public BiomorphChooser(String cName, String startSpec) {
        setLayout(new BoxLayout(this,BoxLayout.Y_AXIS));
        JPanel p = new JPanel(new GridLayout(3,3));
        for(int i=1;i <= 9;i++) {
            Icon f = (Icon)Lib.makeObject(cName);
            ((Mutating)f).setSpec(startSpec);
            if(f == null)
                throw new IllegalArgumentException("can't make object " +
                    "of type " + cName);
            JButton b = new JButton(f);
            String cmd = Integer.toString(i);
            p.add(b); flags.put(cmd,f);
            b.addActionListener(this);
            b.setActionCommand(cmd);
        }
        add(p);

        Box b = new Box(BoxLayout.X_AXIS);
        b.add(specField = new JTextField());
        specField.setText(
            ((Mutating)flags.get(
            Integer.toString(KEY_FLAG))).getSpec());
        specField.getDocument().addDocumentListener(this);

//NOTE internationalise
        b.add(setButton = new JButton("Set"));
        setButton.setActionCommand(SET_CMD);
        setButton.addActionListener(this);
        add(b);
    }

    /** Reset centre flag to spec and mutate the others. */
    public void setFlag(String s) {
        for(int i=1;i <= 9;i++) {
            String cmd = Integer.toString(i);
            Mutating f = (Mutating)flags.get(cmd);
            f.setSpec(s);
            if(i != KEY_FLAG)
                f.mutate(rand);
        }
        specField.setText(
            ((Mutating)flags.get(
            Integer.toString(KEY_FLAG))).getSpec());
        setButton.setEnabled(true);
        repaint();
    }

    //////////////////
    // action listener

    public void actionPerformed(ActionEvent ae) {
        String cmd = ae.getActionCommand();
        if(cmd.equals(SET_CMD)) {
            setFlag(specField.getText());
            return;
        }
        String newSpec = ((Mutating)flags.get(cmd)).getSpec();
        setFlag(newSpec);
    }

    public void insertUpdate(DocumentEvent de) { 
        setButton.setEnabled(((Mutating)flags.get(
            Integer.toString(KEY_FLAG))).validateSpec(
            specField.getText()));
    }
        
    public void removeUpdate(DocumentEvent de) { 
        setButton.setEnabled(((Mutating)flags.get(
            Integer.toString(KEY_FLAG))).validateSpec(
            specField.getText()));
    }
    
    public void changedUpdate(DocumentEvent de) { 
        setButton.setEnabled(((Mutating)flags.get(
            Integer.toString(KEY_FLAG))).validateSpec(
            specField.getText()));
    }
}
