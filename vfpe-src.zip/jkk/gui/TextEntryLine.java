/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1999
*/

package jkk.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Vector;

/**
	Subclass of CommandLine that listens for KeyEvents coming from
	itself, and implementing typing with backspace.  Is also an
	ActionEvent source, fires an ActionEvent when enter is pressed,
	like a TextField.

	@author J Kyle Kelso, (c) 1999
*/
public class TextEntryLine extends CommandLine {

	////////////
	// constants
	
	/////////
	// fields

	private Vector listeners;

	//////////////
	// constructor
	
	public TextEntryLine() {
		super();
		addKeyListener(this);
		listeners = new Vector();
		addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent me) {
				requestFocus();
			}
		});
	}

	public TextEntryLine(int cWidth) {
		this();
		charWidth = cWidth;
	}

	////////
	// tools

	public void addActionListener(ActionListener al) {
		listeners.addElement(al);
	}
	
	/////////////////
	// painting stuff

	///////////////
	// layout stuff

	/////////////////
	// event handling

	public void keyPressed(KeyEvent ke) {
		int code = ke.getKeyCode();
		switch(code) {
		case KeyEvent.VK_ENTER:
			ActionEvent ae =
				new ActionEvent(this,ActionEvent.ACTION_PERFORMED,getText());
			for(int i=0;i < listeners.size();i++)
				((ActionListener)listeners.elementAt(i)).actionPerformed(ae);
			break;
		case KeyEvent.VK_BACK_SPACE:
			backspace(); break;
		case KeyEvent.VK_DELETE:
			setText(""); break;
		default:
			break;
		}
	}
	
	public void keyReleased(KeyEvent ke) { }

	public void keyTyped(KeyEvent ke) {
		char c = ke.getKeyChar();
		if(c == KeyEvent.CHAR_UNDEFINED ||
		   Character.isISOControl(c)) return;
		addChar(c);
	}

}
