/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1999
*/

package jkk.gui;

import java.awt.TextField;

public class DoubleField extends TextField {

	public DoubleField() { super(); }
	public DoubleField(int n) {	super(n); }

	public double getDouble() {
		try {
			return Double.valueOf(getText()).doubleValue();
		} catch(NumberFormatException nfe) { }
		return 0.0;
	}

	public boolean validDouble() {
		try {
			Double n = Double.valueOf(getText());
			return true;
		} catch(NumberFormatException nfe) {
			return false;
		}
	}
}

