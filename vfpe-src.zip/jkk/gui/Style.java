/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997
*/

/* drawing tools */

package jkk.gui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Rectangle;

public class Style {

	public static int GAP = 4;

	public static void drawEtchedRect(Graphics g, Rectangle size) {
		Color old = g.getColor();
		g.draw3DRect(size.x,size.y,size.width,size.height,false);
		g.setColor(old);
		g.draw3DRect(size.x+1,size.y+1,size.width-2,size.height-2,true);
	}
	
	public static void fillLosenge(Graphics g, Rectangle size) {
		int x = size.x; int y = size.y; int w = size.width; int h = size.height;
		int r = h/2;
		g.fillRect(x+r,y,w-h+1,h);
		g.fillArc(x,y,h,h,90,180); g.fillArc(x+w-h,y,h,h,270,180);
	}

	public static void drawLosenge(Graphics g, Rectangle size) {
		int x = size.x; int y = size.y; int w = size.width; int h = size.height;
		int r = h/2;
		if(w > h) {
			g.drawLine(x+r,y,w-r,0); g.drawLine(x+r,y+h-1,x+w-r,y+h-1);
		}
		g.drawArc(x,y,h-1,h-1,90,180);
		g.drawArc(x+w-h,y,h-1,h-1,270,180);
	}

	public static void draw3DLosenge(Graphics g, Rectangle size, boolean raised) {
		int x = size.x; int y = size.y; int w = size.width; int h = size.height;
		int r = h/2;
		Color l = g.getColor().brighter();
		Color d = g.getColor().darker();
		if(!raised) {
			l = d; d = g.getColor().brighter();
		}
		g.setColor(l);
		g.drawLine(x+r,y,x+w-r,y);
		g.drawArc(x,y,h-1,h-1,90,135);
		g.drawArc(x+w-h,y,h-1,h-1,45,45);
		g.setColor(d);
		g.drawLine(x+r,y+h-1,x+w-r,y+h-1);
		g.drawArc(x,y,h-1,h-1,225,45);
		g.drawArc(x+w-h,y,h-1,h-1,270,135);
	}
	
	public static void drawEtchedLosenge(Graphics g, Rectangle size) {
		Color old = g.getColor();
		Style.draw3DLosenge(g,size,false);
		g.setColor(old);
		Style.draw3DLosenge(g,
			new Rectangle(size.x+1,size.y+1,size.width-2,size.height-2),true);
	}
}
