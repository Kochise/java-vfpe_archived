/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997
*/

/* concrete lightweight container */

package jkk.gui;

import java.awt.Container;

public class LightContainer extends Container {

	public LightContainer() { super(); }

}
