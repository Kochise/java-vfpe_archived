/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1999
*/

package jkk.gui;

import java.awt.Component;
import java.awt.Image;
import java.awt.image.ImageObserver;
import java.io.File;
import java.io.IOException;
import java.util.Hashtable;

public class ImageCache extends Hashtable implements IconSource {

	/////////
	// fields

	public String fsRoot;
	public Component waiter;

	///////////////
	// constructors

	// file system based cache
	public ImageCache(String fsRoot) {
		this.fsRoot = fsRoot;
	}

	//////////
	// methods

	public Image getImage(String key) {
		if(!containsKey(key)) {
			if(fsRoot != null) {
				byte [] idata = jkk.io.Lib.fileToByteArray(
					fsRoot + File.separator + key + ".gif");
				if(idata == null) return null;
				Image i = Lib.imageFromByteArray(idata);
				if(waiter != null)
					Lib.waitForImage(i,waiter);
				put(key,i);
			} else {
				// load from classpath via class getResource()
			}
		}
		return (Image)get(key);
	}
}

/**
  This inner class handles the ImageObserver notification associated with
  the lodaing of a specific image.  The parent of this class is a dummy
  instance.  The ImageSync has only been made an inner class for scoping
  (organisational) reasons.
*/
class ImageSync implements ImageObserver
{
  /**
     The image object to synchronize.
  */
  private Image image;

  /**
     Creates an image sync awaiting the completion of the specified
     image.
  */   
  public ImageSync(Image image)
  {
     this.image = image;
  }

  /**
     Implementation of the ImageObserver interface such that it awaits
     completion of the specified Image.
  */
  public synchronized boolean imageUpdate(Image image, int status,
                                          int x, int y, int w, int h)
  {
     if (image == this.image && status == ImageObserver.ALLBITS)
     {
        notifyAll();
        return false;                   // signal no more updates required
     }
     
     return true;                // signal further updates to be delivered
  }

  /**
     Waits for creation of the specified Image to complete.
     
     @return  True on successful completion and false otherwise.
  */      
  public synchronized boolean available()
  {
     try {
        // One the width and height are known then the image will be
        // complete.
        while (image.getHeight(this) == -1 || image.getWidth(this) == -1)
           wait();
        return true;
     } catch (InterruptedException ie) {
        return false;
     }
  }
}
// end of inner class ImageSync
