/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997
*/

/*	Text label popup label */
	
package jkk.gui;

import java.awt.Component;
import java.awt.Dialog;
import java.awt.Frame;
import java.awt.SystemColor;
import java.awt.Window;

import jkk.gui.Bordered;
import jkk.gui.MultiLineTextLabel;

public class PopupLabel extends Window /*Dialog*/ {

	public PopupLabel(Frame parent, String text, Component cp) {
		super(parent);
		setBackground(SystemColor.info);
		setForeground(SystemColor.infoText);
		Bordered border = new Bordered(Bordered.SQUARE,Bordered.PLAIN,2);
		border.add("",new MultiLineTextLabel(text));
		add("Center",border);
		pack();
		jkk.gui.Lib.locateNear(this,cp);
	}
}
