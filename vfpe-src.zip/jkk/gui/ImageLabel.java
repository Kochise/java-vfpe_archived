/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997
*/

package jkk.gui;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Graphics;
import java.awt.image.ImageObserver;

import jkk.gui.BackgroundFilter;
import jkk.gui.Pressable;

public class ImageLabel extends Pressable implements ImageObserver {
	
	public Image img;
	public Image disabledImage;
	private int width, height;
	
	public ImageLabel(Image i) {
		setImage(i);
	}

	public void setImage(Image i) {
		this.img = i;
		width = img.getWidth(this); height = img.getHeight(this);
		repaint();
	}

	public void paint(Graphics g) {
		Dimension size = getSize();
		Image toDraw = img;
		if(!isEnabled()) {
			if(disabledImage == null) {
				disabledImage = BackgroundFilter.filter(
					img,getBackground(),0.75,this);
				Lib.waitForImage(disabledImage,this);
			}
			toDraw = disabledImage;
		}
		g.drawImage(toDraw,(size.width-width)/2,(size.height-height)/2,this);
			
	}

	public Dimension getMinimumSize() {
		return new Dimension(width,height);
	}

	public Dimension getPreferredSize() {
		return new Dimension(width,height);
	}

	/* ImageObserver implementation */

	public boolean imageUpdate(Image img,
    	int infoflags, int x, int y, int width, int height) {

		if((infoflags & ImageObserver.WIDTH) != 0) {
			width = img.getWidth(null);
			invalidate(); validate();
		}

		if((infoflags & ImageObserver.HEIGHT) != 0) {
			width = img.getWidth(null);
			invalidate(); validate();
		}

		if((infoflags & (ImageObserver.ABORT | ImageObserver.ERROR)) != 0) {
			
		}

		if((infoflags & (ImageObserver.ALLBITS | ImageObserver.FRAMEBITS)) != 0) {
			repaint();
		}

		if((infoflags & ImageObserver.SOMEBITS) != 0) {
			repaint(x,y,width,height);
		}

		return false;
    }
}
