/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997-2001
*/

package jkk.gui;

import java.awt.Button;
import java.awt.Dialog;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Frame;
import java.awt.Label;
import java.awt.TextArea;
import java.awt.TextComponent;
import java.awt.TextField;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;

import jkk.gui.MultiLineTextLabel;

public class StringRequester extends Dialog implements ActionListener {
	private static final String CANCEL_LABEL = "Cancel";
	private static final String OK_LABEL = "OK";
	private static final int DEF_ROWS = 5;
	private static final int DEF_COLS = 40;
	
	public TextComponent tf;
	private String str = null;
	private Button okB, cancelB;

	public StringRequester(String title, String prompt, Frame parent) {
		this(title,prompt,parent,"",false);
	}
	
	public StringRequester(String title, String prompt, Frame parent,
		String defaultText, boolean multiline) {
		this(title,prompt,parent,defaultText, 
			multiline ? DEF_ROWS : 1,DEF_COLS);
	}

	public StringRequester(String title, String prompt, Frame parent,
		String defaultText, int rows, int cols) {
		super(parent,title,true);
		GridBagPanel gbp = new GridBagPanel();
		
		add("Center",gbp);
		if(prompt.indexOf("\n") != -1)
			gbp.add(new MultiLineTextLabel(prompt),
				"position=0,0,2,1 weight=0.0,0.0");
		else
			gbp.add(new Label(prompt,Label.CENTER),
				"position=0,0,2,1 weight=0.0,0.0");
		if(rows > 1) {
			tf = new TextArea(rows,cols);
		} else {
			tf = new TextField(cols);
			((TextField)tf).addActionListener(this);
		}
		tf.setText(defaultText);
		gbp.add(tf,"position=0,1,2,1 weight=1.0,1.0");
		
		gbp.add(okB = new Button(OK_LABEL),"position=0,2,1,1 weight=0.0,0.0");
		okB.addActionListener(this);
		gbp.add(cancelB = new Button(CANCEL_LABEL),
			"position=1,2,1,1 weight=0.0,0.0");
		cancelB.addActionListener(this);
		pack();
		addComponentListener(new ComponentAdapter() {
			public void componentShown(ComponentEvent ce) {
				tf.requestFocus();
			}
		});
	}

	public String getString() { return str; }

	/* event handling */

	public void actionPerformed(ActionEvent ae) {
		if(ae.getSource().equals(cancelB)) {
			str = null;
		} else {
			str = tf.getText();
		}
		setVisible(false); dispose();
	}
}

