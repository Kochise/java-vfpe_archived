/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997
*/

package jkk.gui;

import java.awt.Button;
import java.awt.Dialog;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.util.Vector;

public class StringSelectorPopup extends Dialog
	implements ActionListener, WindowListener {
	private String sel = null;
	
	public StringSelectorPopup(Frame parent, String title, Vector strs) {
		super(parent,title,true);
		addWindowListener(this);
		setLayout(new GridLayout(strs.size(),1));
		for(int i=0;i < strs.size();i++) {
			String label = (String)strs.elementAt(i);
			Button b = new Button(label);
			add(b); b.addActionListener(this);
		}
		pack();
	}

	public String getSelectedString() { return sel; }
	
	/* event handling */

	public void actionPerformed(ActionEvent event) {
		sel = event.getActionCommand();
		setVisible(false); dispose();
	}

	public void windowActivated(WindowEvent event) { }
	public void windowClosed(WindowEvent event) { }
	
	public void windowClosing(WindowEvent event) {
		setVisible(false); dispose();
	}
	
	public void windowDeactivated(WindowEvent event) { }
	public void windowDeiconified(WindowEvent event) { }
	public void windowIconified(WindowEvent event) { }
	public void windowOpened(WindowEvent event) { }
}
