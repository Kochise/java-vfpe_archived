/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1998
*/

package jkk.gui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.ImageObserver;
import java.awt.image.MemoryImageSource;

import jkk.math.Lib;

public class IntensityMap extends Component {

	public  int MARGINS = 10;
	public int [] data;
	public int width,height,range;
	public Color [] colorMap;
	
	private Image image;

	public IntensityMap() { }
	
	public void rebuildImage() {
		if(data == null) return;
		Lib.clipInts(data,0,range);		
		int [] rgbData = Lib.composeIntMap(
			ColorMaps.mapToRGB(colorMap),data);
		image = createImage(new MemoryImageSource(
			width,height,rgbData,0,width));
	}

	public void paint(Graphics g) {
		Dimension size = getSize();
		size.setSize(size.width - MARGINS*2,size.height - MARGINS*2);
		if(image == null) {
			if(data == null) return;
			rebuildImage();
		}
		g.drawImage(image,MARGINS,MARGINS,size.width,size.height,null);
	}

	public Dimension getPreferredSize() {
		return new Dimension(width + MARGINS*2,height + MARGINS*2);
	}

	/*
	public boolean imageUpdate(Image img, int flags, int x, int y, int w, int h)
	{
		if((flags & ImageObserver.ALLBITS) != 0) {
			repaint(); return false;
		}
		return true;
	}
	*/

	/* pointless code ... good practise though */
	/*
	public void paint(Graphics g) {
		Dimension size = getSize();
		size.setSize(size.width - MARGINS*2,size.height - MARGINS*2);
	
		// interpolate linearly
		
forRow:	for(int i=0;i < size.width;i++) {
			float fx = (float)i*(float)width/(float)size.width;
			int x = (int)fx; if(x+1 >= width) break forRow;
			float xrem = (float)Lib.fract(fx);
forColumn:	for(int j=0;j < size.height;j++) {
				float fy = (float)j*(float)height/(float)size.height;
				int y = (int)fy;
				if(y+1 >= height) break forColumn;
				float yrem = (float)Lib.fract(fy);

				// intensity values at top and bottom of square

				int topi = (int)(data[y*width+x] +
					yrem*(data[y*width+x+1] - data[y*width+x]));
				int boti = (int)(data[(y+1)*width+x] +
					yrem*(data[(y+1)*width+x+1] - data[(y+1)*width+x]));

				// interpolate along vertical line

				int vi = (int)(topi + xrem*(boti - topi));

				// map to color table
				
				vi = Math.max(0,vi); vi = Math.min(range-1,vi);
				int ci = (int)((float)vi/(float)range*(float)colorMap.length);
				g.setColor(colorMap[ci]);
				g.drawRect(MARGINS+i,MARGINS+j,1,1);
			}
		}
	}
	*/
}
