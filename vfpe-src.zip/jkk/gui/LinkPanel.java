/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997
*/

/*	A panel for containing a directed graph of components */
	
package jkk.gui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Panel;
import java.awt.Point;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import jkk.gui.Lib;
import jkk.gui.LightContainer;

/* making this heavyweight reduces flickering */

public class LinkPanel extends /* Panel */ Container {

	// constants
	
	public static final int NORMAL = 0;
	public static final int HEAVY = 1;
	public static final int DEF_SIZE = 200;

	// fields

	protected Dimension prefSize;
	protected Color linkColor = Color.black;
	protected Hashtable sources;
	protected Hashtable attributes; // a little heavyweight, but I'm lazy

	// constructors
	
	public LinkPanel() {
		setLayout(null);
		sources = new Hashtable();
		attributes = new Hashtable();
		prefSize = new Dimension();
	}

	// methods

	public void addImpl(Component c, Object o, int i) {
		super.addImpl(c,o,i);
		sources.put(c,new Vector());
	}

	public void remove(Component c) {
		super.remove(c);
		sources.remove(c);
		Enumeration e = sources.keys();
		while(e.hasMoreElements()) 
			removeLink((Component)e.nextElement(),c);
	}

	public void removeAll() {
		Component [] cs = getComponents();
		for(int i=0;i < cs.length;i++)
			remove(cs[i]);
	}

	public void addLink(Component from, Component to) {
		Vector v = (Vector)sources.get(from);
		if(!v.contains(to))
			v.addElement(to);
	}

	public void removeLink(Component from, Component to) {
		if(sources.containsKey(from)) {
			Vector ds = (Vector)sources.get(from);
			if(ds.contains(to))
				ds.removeElement(to);
		}
	}

	public void setLinkAttribute(Component from, Component to, int attrib) {
		if(!attributes.containsKey(from))
			attributes.put(from,new Hashtable());
		Hashtable s = (Hashtable)attributes.get(from);
		s.put(to,new Integer(attrib));
	}

	public int getLinkAttribute(Component from, Component to) {
		if(!attributes.containsKey(from)) return NORMAL;
		Hashtable s = (Hashtable)attributes.get(from);
		if(!s.containsKey(to)) return NORMAL;
		return ((Integer)s.get(to)).intValue();
	}

	// painter

	public void paint(Graphics g) {
		Enumeration e = sources.keys();
		g.setColor(linkColor);
		while(e.hasMoreElements()) {
			Component src = (Component)e.nextElement();
			Point s = Lib.centre(src);
			Vector v = (Vector)sources.get(src);
			for(int i=0;i < v.size();i++) {
				Component dst = (Component)v.elementAt(i);
				Point d = Lib.centre(dst);
				g.drawLine(s.x,s.y,d.x,d.y);
				if(getLinkAttribute(src,dst) == HEAVY) {
					g.drawLine(s.x+1,s.y,d.x+1,d.y);
					g.drawLine(s.x,s.y+1,d.x,d.y+1);
					g.drawLine(s.x+1,s.y+1,d.x+1,d.y+1);
				}
			}
			
		}
		//paintComponents doesn't seem to work to offscreen bitmaps (?)
		paintComponents(g);
		//super.paint(g);
	}

	// layout

	public void setPrefSize(Dimension d) { prefSize = d; }

	public Dimension getPreferredSize() { return prefSize; }

	public Dimension getMinimumSize() { return prefSize; }
}
