/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1999
*/

/*  A container that allows its child to be grabbed and
  slid around. */
  
package jkk.gui;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

public class SlidingPane extends Container
  implements MouseListener, MouseMotionListener {

  /////////
  // fields
  
  private Point pressPoint;
  private Component child;
  private Dimension prefSize = new Dimension(0,0);

  //////////////
  // constructor

  public SlidingPane() {
    setLayout(null);
    addMouseListener(this);
  }

  public SlidingPane(Component c) {
    this();  addChild(c);
  }

  //////////
  // methods

  public void addChild(Component c) {
    if(child != null)
      throw new IllegalArgumentException("already got child");
    child = c; add(c);
    c.addMouseListener(this);
    c.addMouseMotionListener(this);
  }

  /////////
  // layout

  public void doLayout() {
    if(child == null) return;
    child.setSize(child.getPreferredSize());
  }

  public Dimension getPreferredSize() {
    if(child != null) {
      Rectangle d = child.getBounds();
      prefSize.width = d.x + d.width;
      prefSize.height = d.y + d.height;
    }
    return prefSize;
  }

  /////////////////
  // event handling
  
  public void mouseClicked(MouseEvent evnt) { 
    if(evnt.getClickCount() == 2) 
      child.setLocation(0,0);
  }
  public void mouseEntered(MouseEvent evnt) { }
  public void mouseExited(MouseEvent evnt) { }
  public void mousePressed(MouseEvent evnt) {
    Point p = new Point(evnt.getX(),evnt.getY());
    pressPoint = p;
  }
  public void mouseReleased(MouseEvent evnt) { pressPoint = null; }

  public void mouseDragged(MouseEvent evnt) {
    Component c = evnt.getComponent();
    Point current = c.getLocation();
    if(pressPoint == null) {
      Dimension size = c.getSize();
      pressPoint = new Point(size.width/2,size.height/2);
    }
    c.setLocation(current.x+evnt.getX()-pressPoint.x
      ,current.y+evnt.getY()-pressPoint.y);
    //c.getParent().repaint();
  }

  public void mouseMoved(MouseEvent evnt) { }
}

