/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1999
*/

package jkk.gui;

import java.awt.TextField;

public class IntField extends TextField {

	public int getInt() {
		try {
			return Integer.parseInt(getText());
		} catch(NumberFormatException nfe) { }
		return 0;
	}

	public boolean validInt() {
		try {
			int n = Integer.parseInt(getText());
			return true;
		} catch(NumberFormatException nfe) {
			return false;
		}
	}
}

