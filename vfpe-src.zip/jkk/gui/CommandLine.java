/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1999
*/

package jkk.gui;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.image.ImageObserver;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

/**
	A kind of text label that should be able to have characters added
	to it without having to repaint the whole thing.  Has an optional
	background tile image that is painted underneith the text.  This
	component was originally written to allow text command lines with
	semi-transparent backgrounds.

	@author J Kyle Kelso, (c) 1999
*/
public class CommandLine extends Component
	implements KeyListener, FocusListener {

	////////////
	// constants
	
	public static final int GAP = 2;
	public static final int NO_CARET = 0;
	public static final int BAR_CARET = 1;
	
	/////////
	// fields

	private int advance;
	private FontMetrics fm;
	public String text = "";

	public int caretType;
	private boolean haveFocus;

	public Image tile;
	int cells;
	private Dimension tileSize = new Dimension();
	
	//////////////
	// constructor
	
	public CommandLine() {
		addFocusListener(this);
	}

	private void updateMetrics() {
// ******* FontMetrics not available for unshown components !
// THIS KIND OF PISSES ME OFF
		try {
			fm = Toolkit.getDefaultToolkit().getFontMetrics(getFont());
		} catch(NullPointerException npe) { }
	}

	///////////////////////////
	// component override stuff

	public boolean isFocusTraversable() { return true; }

	////////
	// tools

	public String getText() { return text; }
	
	public void setText(String s) {
		Graphics g = getGraphics();
		if(fm == null) updateMetrics();
// this pisses me off !
if(fm == null) {
	advance = 10*s.length();
	text = s;
	return;
}
		if(tile != null && tileSize.width > 0) {
			for(int i=0;i < advance;i+= tileSize.width)
				g.drawImage(tile,i,0,null);
		} else {
			Dimension sz = getSize();
			g.setColor(getBackground());
			g.fillRect(0,0,sz.width,sz.height);
		}
		text = s;
		advance = GAP+fm.stringWidth(text);
		if(tile != null && tileSize.width > 0) {
			cells = advance/tileSize.width+1;
		}
		repaint();
	}

	char [] cs = new char[1];
	
	public void addChar(char c) {
		if(fm == null) updateMetrics();
		text = text + c;
		Graphics g = getGraphics();
		cs[0] = c;
		int oldAdvance = advance;
		advance += fm.charWidth(c);
		if(tile != null && tileSize.width > 0) {
			if(advance > cells*tileSize.width) {
				g.drawImage(tile,cells*tileSize.width,0,null);
				cells++;
			}
		} else {
			g.setColor(getBackground());
			g.fillRect(oldAdvance,0,advance-oldAdvance,getSize().height);
		}
		g.setColor(getForeground());
		g.drawChars(cs,0,1,oldAdvance,GAP+fm.getAscent());
		drawCaret(g);
	}

	public void backspace() {
		if(text.length() < 1) return;
		if(fm == null) updateMetrics();
		char lastChar = text.charAt(text.length()-1);
		text = text.substring(0,text.length()-1);
		advance -= fm.charWidth(lastChar);
		if(tile != null && tileSize.width > 0)
			cells = advance/tileSize.width+1;
		repaint();
	}

	public void clear() {
		setText(""); repaint();
	}
	
	public void setTile(Image i) {
		tile = i;
		if(tile != null)
			tileSize = new Dimension(tile.getWidth(null),tile.getHeight(null));
	}

	public void setCaretType(int ct) {
		caretType = ct;
	}
	
	/////////////////
	// painting stuff

	public void paint(Graphics g) {
		if(fm == null) updateMetrics();
		advance = GAP+fm.stringWidth(text);
		Dimension s = getSize();
		if(tile != null && tileSize.width > 0) {
			for(int i=0;i < advance;i+= tileSize.width)
				g.drawImage(tile,i,0,null);
		} else {
			g.setColor(getBackground());
			g.fillRect(0,0,s.width,s.height);
		}
		g.setColor(getForeground());
		if(text.length() > 0)
			g.drawString(text,GAP,GAP+fm.getAscent());
		
		drawCaret(g);
	}

	private void drawCaret(Graphics g) {
		if(!haveFocus) return;
		switch(caretType) {
			case BAR_CARET:
				g.drawLine(advance,GAP+fm.getHeight(),advance,GAP);
				break;
			case NO_CARET:
			default:
				break;
		}
	}

	///////////////
	// layout stuff

	public Dimension getPreferredSize() {
		int w = 0, h = 0;
//KLUDGE
		if(fm == null) {
			w = text.length()*8;
			h = 12;
		} else {
			w = fm.stringWidth(text);
			h = GAP*2 + fm.getHeight();
		}
		return new Dimension(w,h);
	}

	public Dimension getMinimumSize() {
		return getPreferredSize();
	}

	//////////////////////
	// image observer impl

	public boolean imageUpdate(Image i, int flags, int x, int y, int w, int h) {
		if((flags & ImageObserver.WIDTH) != 0) {
			tileSize.width = w;
		}
		if((flags & ImageObserver.HEIGHT) != 0) {
			tileSize.height = h;
		}
		return false;
	}


	/////////////////
	// event handling

	public void keyPressed(KeyEvent ke) {
		int code = ke.getKeyCode();
		switch(code) {
		default:
			break;
		}
		
	}
	
	public void keyReleased(KeyEvent ke) { }

	public void keyTyped(KeyEvent ke) { }

	public void focusGained(FocusEvent fe) {
		haveFocus = true; repaint();
	}

	public void focusLost(FocusEvent fe) {
		haveFocus = false; repaint();
	}

}
