/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1998
*/

package jkk.gui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;

public class ColorScale extends Component {

	private int PREF_BAND_HEIGHT = 20;
	private Color [] colorMap;
	private int high, low;
	public int nBands = 10;
	public String highLegend = "high";
	public String lowLegend = "low";
	public int GAP;
	
	public ColorScale() { super(); }

	public void setScale(Color [] cMap, int low, int high) {
		colorMap = cMap; this.low = low; this.high = high;
		repaint();
	}

	public void paint(Graphics g) {
		if(colorMap == null) return;
		Dimension size = getSize();
		FontMetrics fm = getFontMetrics(getFont());
		int headSize = fm.getHeight()+GAP*2;
		int bandSize = (size.height - headSize*2)/nBands;
		
		g.setColor(getForeground());
		g.drawString(highLegend,
			(size.width-fm.stringWidth(highLegend))/2,
			fm.getAscent()+GAP);

		for(int i=0;i < nBands;i++) {
			g.setColor(colorMap[low+(nBands-i)*((high-low)/nBands)]);
			g.fillRect(GAP,headSize+i*bandSize,
				size.width-GAP*2,bandSize);
		}

		g.setColor(getForeground());
		g.drawString(lowLegend,
			(size.width-fm.stringWidth(lowLegend))/2,
			size.height-fm.getDescent()-GAP);
	}

	public Dimension getPreferredSize() {
		FontMetrics fm = getFontMetrics(getFont());
		int headSize = fm.getHeight()+GAP*2;
		return new Dimension(Math.max(fm.stringWidth(lowLegend),
			fm.stringWidth(highLegend))+GAP*2,
			headSize*2+nBands*PREF_BAND_HEIGHT);
	}
}
