/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997-1998
*/

package jkk.gui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.LayoutManager;
import java.awt.Rectangle;

import jkk.gui.Draggable;
import jkk.gui.Lib;
import jkk.gui.Style;

public class Bordered extends Draggable {

	public static final int SQUARE = 0;
	public static final int LOSENGE = 1;
	public static final int NONE = 10;
	public static final int PLAIN = 11;
	public static final int RAISED = 12;
	public static final int SUNKEN = 13;
	public static final int ETCHED = 14;
	
	public int cornerStyle;
	public int borderStyle;
	public int borderSize;
	public String title;
	public boolean fillBackground;
	
	private Insets insets;

	/* constructor -------------------------------------------------- */

	public Bordered() { this(SQUARE,NONE,0); }
		
	public Bordered(int crnr, int bdr, int bSize) {
		super(); isDraggable = false;

		cornerStyle = crnr;
		borderStyle = bdr; borderSize = bSize;
		fillBackground = true;
		setLayout(new InsetLayout(this));	
	}

	/* layout stuff ------------------------------------------------- */

	public Insets getInsets() {
		return new Insets(borderSize,borderSize,borderSize,borderSize);
	}

	protected void addImpl(Component comp, Object constraints, int index) {
		super.addImpl(comp,constraints,index);
		comp.addMouseListener(this);
		comp.addMouseMotionListener(this);
	}

	/* painter ------------------------------------------------------ */

	public void update(Graphics g) { paint(g); }
	
	public void paint(Graphics g) {

		Color bgColor = getBackground();
		Dimension size = getSize();
		
		switch(cornerStyle) {
		case LOSENGE:
			Rectangle srect = new Rectangle(0,0,size.width,size.height);
			if(fillBackground) {
				g.setColor(bgColor);
				Style.fillLosenge(g,srect);
			}
			
			switch(borderStyle) {
			case PLAIN:
				g.setColor(getForeground());
				Style.drawLosenge(g,srect);
				break;
			case RAISED:
				Style.draw3DLosenge(g,srect,true);
				break;
			case SUNKEN:
				Style.draw3DLosenge(g,srect,false);
				break;
			case ETCHED:
				int gap = borderSize/2;
				Style.drawEtchedLosenge(g, new 
					Rectangle(gap,gap,size.width-gap*2,size.height-gap*2));
				break;
			case NONE:
			default:
				break;
			}
			break;
		case SQUARE:
		default:
			if(fillBackground) {
				g.setColor(bgColor);
				g.fillRect(0,0,size.width,size.height);
			}
			
			switch(borderStyle) {
			case PLAIN:
				g.setColor(getForeground());
				g.drawRect(0,0,size.width-1,size.height-1);
				break;
			case RAISED:
				g.setColor(getBackground());
				g.draw3DRect(0,0,size.width-1,size.height-1,true);
				break;
			case SUNKEN:
				g.setColor(getBackground());
				g.draw3DRect(0,0,size.width-1,size.height-1,false);
				break;
			case ETCHED:
				g.setColor(getBackground());
				int gap = borderSize/2;
				Style.drawEtchedRect(g, new Rectangle(
					gap,gap,size.width-1-gap*2,size.height-1-gap*2));
				if(title != null) {
					Font f = getFont();	FontMetrics fm = getFontMetrics(f);
					int w = fm.stringWidth(title) + gap;
					int h = fm.getHeight(); int ascent = fm.getAscent();
					g.setColor(getBackground());
					g.fillRect(gap*3,gap-ascent/2,w,h);
					g.setColor(getForeground());
					g.drawString(title,(gap*7)/2,gap+ascent/2);
				} 
				break;
			case NONE:
			default:
				break;
			}
			break;
		}

		super.paint(g);
	}
}

class InsetLayout implements LayoutManager {
	private Component child;
	private Container parent;
	
	public InsetLayout(Container parent) {
		this.parent = parent;
	}

	public void addLayoutComponent(String s, Component c) {
		child = c;
	}

	public void layoutContainer(Container cnt) {
		Insets i = cnt.getInsets();
		child.setLocation(i.left,i.top);
		Dimension cmxs = child.getMaximumSize();
		Dimension cmns = child.getMinimumSize();
		Dimension cs = cnt.getSize();
		cs.width -= i.left + i.right;
		cs.height -= i.top + i.bottom;
		cs.width = Math.min(cs.width,cmxs.width);
		cs.width = Math.max(cs.width,cmns.width);
		cs.height = Math.min(cs.height,cmxs.height);
		cs.height = Math.max(cs.height,cmns.height);
		child.setSize(cs);
	}

	public Dimension minimumLayoutSize(Container cnt) {
		Insets i = cnt.getInsets();
		Dimension childSize = child.getMinimumSize();
		return new Dimension(childSize.width + i.left + i.right,
			childSize.height + i.top + i.bottom);
	}

	public Dimension preferredLayoutSize(Container cnt) {
		Insets i = cnt.getInsets();
		Dimension childSize = child.getPreferredSize();
		return new Dimension(childSize.width + i.left + i.right,
			childSize.height + i.top + i.bottom);
	}

	public void removeLayoutComponent(Component c) {
		child = null;
	}	
}
