/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997
*/

/*	This little baby is component that can be dragged around in
	its parent. */
	
package jkk.gui;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.Point;

import java.awt.event.MouseEvent;

import jkk.gui.ToolTipped;

public class Draggable extends ToolTipped	{

	public boolean isDraggable = true;
	private Point pressPoint;
	
	/* constructor -------------------------------------------------- */

	protected Draggable() { super(); }

	/* event handling------------------------------------------------ */

	public void mouseClicked(MouseEvent evnt) { super.mouseClicked(evnt); }
	public void mouseEntered(MouseEvent evnt) { super.mouseEntered(evnt); }
	public void mouseExited(MouseEvent evnt) { super.mouseExited(evnt); }
	public void mousePressed(MouseEvent evnt) {
		super.mousePressed(evnt);
		Point p = new Point(evnt.getX(),evnt.getY());
		pressPoint = p;
	}
	public void mouseReleased(MouseEvent evnt) { super.mouseReleased(evnt); }

	public void mouseDragged(MouseEvent evnt) {
		if(isDraggable) {
			Point current = getLocation();
			if(pressPoint == null) {
				Dimension size = getSize();
				pressPoint = new Point(size.width/2,size.height/2);
			}
			setLocation(current.x+evnt.getX()-pressPoint.x
				,current.y+evnt.getY()-pressPoint.y);
			getParent().repaint();
		}
		super.mouseDragged(evnt);
	}

	public void mouseMoved(MouseEvent evnt) { super.mouseMoved(evnt); }
}

