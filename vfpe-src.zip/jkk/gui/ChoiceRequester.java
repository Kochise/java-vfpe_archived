/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997-1998
*/

package jkk.gui;

import java.awt.Dialog;
import java.awt.Button;
import java.awt.Frame;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import jkk.gui.MultiLineTextLabel;

public class ChoiceRequester extends Dialog implements ActionListener {	
	private String choice = null;

	public ChoiceRequester(String title, String prompt,
		String [] choices, Frame parent) {
		super(parent,title,true);
		GridBagPanel gbp = new GridBagPanel();
		add("Center",gbp);
		int n = choices.length;
		gbp.add(new MultiLineTextLabel(prompt),
			"position=0,0,"+n+",1");
		for(int i=0;i<n;i++) {
			Button b = new Button(choices[i]);
			gbp.add(b,"position="+i+",1,1,1");
			b.addActionListener(this);
		}
		pack();
	}

	public String getChoice() { return choice; }

	/* event handling */

	public void actionPerformed(ActionEvent ae) {
		choice = ae.getActionCommand();
		setVisible(false); dispose();
	}
}
