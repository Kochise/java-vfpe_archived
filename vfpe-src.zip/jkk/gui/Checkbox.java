/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1999
*/

package jkk.gui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Vector;

/**
	A simple lightweight checkbox, with label component.

	@author J Kyle Kelso, (c) 1999
*/
public class Checkbox extends Container {

	////////////
	// constants

	public static final int boxSize = 15;
	public static final int GAP = 2;

	/////////
	// fields

	private boolean state;
	private Component label;
	private Dimension dim;
	private int checkboxOffset;
	private Vector listeners;

	///////////////
	// constructors

	public Checkbox() { 
		setLayout(null); listeners = new Vector();
		dim = new Dimension(0,0);
		addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent me) {
				int x = me.getX(); int y = me.getY();
				if(x > GAP && x < (boxSize+GAP) &&
				   y > GAP && y < (boxSize+GAP)) 
					setState(!state);
			}
		});
	}

	public Checkbox(Component l) {
		this(); setLabel(l);
	}

	//////////
	// methods

	public void setLabel(Component l) {
		if(label != null)
			remove(label);
		label = l; add(label);
		label.invalidate();
		validate();
	}

	public boolean getState() { return state; }

	public void setState(boolean newState) {
		if(newState == state) return;
		state = newState;
		repaint();
		ActionEvent ae = new ActionEvent(this,
			ActionEvent.ACTION_PERFORMED,state?"true":"false");
		for(int i=0;i < listeners.size();i++)
			((ActionListener)listeners.elementAt(i)).actionPerformed(ae);
	}


	public void addActionListener(ActionListener al) {
		listeners.addElement(al);
	}

	//////////
	// painter

	public void paint(Graphics g) {
		g.setColor(getBackground());
		g.draw3DRect(GAP,GAP+checkboxOffset,boxSize,boxSize,false);
		if(!state) {
			//g.setColor(Color.black);
			//g.fillRect(GAP*2,GAP*2+checkboxOffset,boxSize-GAP*2,boxSize-GAP*2);
			g.draw3DRect(GAP*2,GAP*2+checkboxOffset,boxSize-GAP*2,boxSize-GAP*2,true);
		}
		super.paint(g);
	}

	///////////////
	// layout stuff

	public void validate() {
		int dy = 0; checkboxOffset = 0;
		if(label == null)
			dim = new Dimension(0,0);
		else {
			dim = label.getPreferredSize();
		}
		if(dim.height < boxSize+GAP*2) {
			dy = ((boxSize+GAP*2)-dim.height)/2;
			dim.height = boxSize+GAP*2;
		} else if(dim.height > boxSize+GAP*2) {
			checkboxOffset = (dim.height-(boxSize+GAP*2))/2;
		}
		dim.width += boxSize + GAP*2;
		if(label != null)
			label.setBounds(boxSize+GAP*2,dy,dim.width,dim.height);
		repaint();
	}

	public Dimension getMinimumSize() {
		return new Dimension(dim);
	}

	public Dimension getPreferredSize() {
		return new Dimension(dim);
	}

}
