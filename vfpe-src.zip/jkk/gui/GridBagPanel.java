/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997
*/

package jkk.gui;

import java.awt.Component;
import java.awt.Container;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import jkk.gui.Lib;

public class GridBagPanel extends Container {

	private GridBagConstraints defaults;
	
	public GridBagPanel() {
		super(); setLayout(new GridBagLayout());
		defaults = new GridBagConstraints();
		Lib.setGBConstraints(defaults,Lib.GBC_DEFAULTS);
	}

	public void add(Component c, Object cts)
	{
		GridBagConstraints gbc = (GridBagConstraints)defaults.clone();
		Lib.setGBConstraints(gbc,(String)cts);
		((GridBagLayout)getLayout()).setConstraints(c,gbc);
		add(c);
	}

	public void setDefaults(String cts) {
		Lib.setGBConstraints(defaults,cts);
	}

}

