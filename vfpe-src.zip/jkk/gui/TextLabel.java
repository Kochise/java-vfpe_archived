/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997
*/

package jkk.gui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.MouseEvent;

import jkk.gui.Pressable;

public class TextLabel extends Pressable {
	private static int VPADDING = 0;
	protected static int leadingGap = 1;
	public static final String CENTER = "center";
	public static final String LEFT = "left";
	public static final String RIGHT = "right";
	protected int height, length, ascent;
	public String text;
	public String align = CENTER;
	public boolean opaque = false;
	public Image backdrop;
	protected Color currentColour;
	public Color highlightColour;
	
	public TextLabel(String text, String al) {
		align = al; setText(text);
	}
	
	public TextLabel(String text) {	this(text,CENTER); 	}

	public TextLabel() { this("",CENTER); }
	
	public void setText(String text) {
		this.text = text; command = text; invalidate();
		repaint();
	}

	public void paint(Graphics g) {
		Dimension size = getSize();
		if(opaque) {
			g.setColor(getBackground());
			g.fillRect(0,0,size.width,size.height);
		} else if(backdrop != null) {
			g.drawImage(backdrop,0,0,null);
		}
		int leftOver = size.width-length;
		int indent = 0;
		if(align.equals(CENTER)) indent = (size.width-length)/2;
		else if(align.equals(RIGHT)) indent = size.width-length;
		if(currentColour == null)
			currentColour = getForeground();
		g.setColor(currentColour);
		g.drawString(text,indent+leadingGap,ascent+(size.height-height)/2);
	}

	private void calcSizes() {
		try {
			FontMetrics fm = getFontMetrics(getFont());
			ascent = fm.getAscent();
			height = fm.getHeight()+VPADDING;
			length = fm.stringWidth(text)+leadingGap;
		} catch(NullPointerException npe) {
// ******* FontMetrics not available for unshown components !
// THIS KIND OF PISSES ME OFF
// length = leadingGap; height = 0;
length = 10*text.length(); height = 12; ascent = 10;
		}
	}

	public Dimension getMinimumSize() {
		calcSizes();
		return new Dimension(length,height);
	}

	public Dimension getPreferredSize() {
		return getMinimumSize();
	}

	////////////////
	// eventhandling

	public void mouseEntered(MouseEvent me) {
		if(highlightColour != null) {
			currentColour = highlightColour;
			repaint();
		}
	}

	public void mouseExited(MouseEvent me) {
		if(highlightColour != null) {
			currentColour = getForeground();
			repaint();
		}
	}
}
