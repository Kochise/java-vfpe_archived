/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  joel@babbage.cs.murdoch.edu.au
  *** * * * * copyright 1996
*/

package vfpe;

public class ListParser {
    private char [] buf;
    private int len, ptr;
    private boolean done;

    public ListParser(String s) {
        buf = s.toCharArray(); ptr = 0; len = buf.length;
        done = skipSpaces();
    }

    public boolean more() { return !done; }

    public String next() {
        String r;
        char t = buf[ptr++];

        if(t == '(')
            r = collectSubstring();
        else {
            StringBuffer tmp = new StringBuffer();
            tmp.append(t);
            while((ptr < len) && !Character.isWhitespace(t = buf[ptr++]))
                tmp.append(t);
            r = tmp.toString();
        }
        done = skipSpaces();
        return r;
    }

	public static String head(String s) {
		ListParser ts = new ListParser(s);
		return ts.next();
	}

	public static String tail(String s) {
		ListParser ts = new ListParser(s);
		ts.next();
		StringBuffer buf = new StringBuffer();
		while(ts.more())
			buf.append(" " + ts.next());
		return buf.toString();
	}

    private boolean skipSpaces() {
        while((ptr < len) && Character.isWhitespace(buf[ptr]))
            ptr++;
        return ptr == len;
    }

    private String collectSubstring() {
        int level = 1;
        char t;
        StringBuffer tmp = new StringBuffer();

        while(level > 0) {
            t = buf[ptr++];
            if(t == '(') level++;
            if(t == ')') level--;
            if(level > 0) tmp.append(t);
        }
        return tmp.toString();
    }
}

