/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1998
*/

package vfpe;

public class BadPreludeException extends Exception { 
	public BadPreludeException(String s) { super(s); }
}
