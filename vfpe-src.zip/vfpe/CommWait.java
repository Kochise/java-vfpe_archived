/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1998
*/

package vfpe;

public class CommWait extends EvaluationException {
	public int delay;
	
	public CommWait() { }
	public CommWait(String s) { super(s); }
}
