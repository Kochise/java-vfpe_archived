/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1998
*/

package vfpe;

public class PatternMatchFailure extends EvaluationException { 
	public PatternMatchFailure(String s) { super(s); }
}
