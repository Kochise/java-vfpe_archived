/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997
*/

package vfpe;

public class CodeGenException extends Exception { 
	public CodeGenException(String s) { super(s); }
}
