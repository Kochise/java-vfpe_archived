/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997-1999
*/

/* Local variable abstraction */

package vfpe.syntax;

import java.util.Dictionary;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import jkk.Functor;
import jkk.Lib;
import jkk.Set;
import vfpe.CodeGenException;
import vfpe.EvaluationException;
import vfpe.Reducer;
import vfpe.editor.Editor;
import vfpe.editor.LetAbsLayout;
import vfpe.editor.SyntaxLayout;
import vfpe.syntax.AbsVal;
import vfpe.type.Substitution;
import vfpe.type.Type;
import vfpe.type.TypeException;
import vfpe.type.TypeInferenceState;
import vfpe.type.TypeVar;
import vfpe.type.QuantifiedType;

public class LetAbs extends AbsVal {
    public static final long serialVersionUID = 1;

    public LetAbs() { super(); }
    public LetAbs(Value bd) { super(bd); }

    /* overrides */
    
    public SyntaxLayout makeLayout() {
        return new LetAbsLayout(this);
    }

    public boolean emptyBodyDroppable() { return true; }

    /* type inference */
    /* I wonder who first implemented this ? */

    public Set inferType(TypeInferenceState itypes) throws TypeException {

        Set fvs = new Set();

        // set dummy type for bindings
        for(int i=0;i < arity();i++)
            binding(i).inferBindingType(itypes);

        // infer type for each binding body
        for(int i=0;i < arity();i++)
            fvs.add(arg(i).inferType(itypes));

        // trigger binding type repair for each binding body
        for(int i=0;i < arity();i++)
            arg(i).narrowBindingType(itypes);

        // infer type for body
        // for reasons I don't understand, putting this before
        // the type repair seems to fail.  see eg
        // Dict.sfe and type type of 'put' .
        fvs.add(body().inferType(itypes));

        // set type of Let node
        itypes.setType(this,itypes.getType(body()));
        return removeBoundVars(fvs);
        
    }

    public void narrowBinding(Syntax s, TypeInferenceState itypes)
        throws TypeException {

        int bn = whatNumberIs(s);

        // unify the type of the body of the binding with the binding type
        Type bType = itypes.getType(binding(bn));
        Type vType = itypes.getType(arg(bn));
        // if it doesn't _have_ a type, do we need to fix it ?
        if(vType == null)
            return;
        Substitution subs = Type.unify(bType,vType);
        if(subs.size() == 0)
            return;
// OPTIMISATION: only need to update binding types ?
        itypes.substitute(subs);

        // find all occurrences of the binding(s) affected, unify and
        //    substitute.
// OPTIMISATION: is it possible to calculate the common part
// of the generic var set once and share, or does it get updated
// too much ?
        Vector uses = findAllVars(binding(bn));
        Vector diffs = new Vector();
        Enumeration e = uses.elements();
        while(e.hasMoreElements()) {
            VarVal vv = (VarVal)e.nextElement();
            vType = itypes.getType(vv);
            // this can occur if a body var hasn't been assigned a type
            if(vType == null)
              continue;
            bType = itypes.getType(vv.binding);
            Set nonGenerics = vv.nonGenericTVs(itypes);
            Type bcType = bType.copy(nonGenerics);
            subs = Type.unify(bcType,vType);
            if(subs.size() == 0)
                continue;
            itypes.substitute(subs);
            Value diffRoot = (Value)vv.findBindingBodyRoot();
            if(diffRoot != null && !(diffs.contains(diffRoot)))
                diffs.addElement(diffRoot);
        }
        e = diffs.elements();
        while(e.hasMoreElements()) {
            ((Value)e.nextElement()).narrowBindingType(itypes);
        }
    }
    
    public String syntaxName() { return "local definitions"; }
    
    /*    There needs to be some mechanism for explicit type declarations,
        probably involving some additional type checking. */

    /* tools */

    public int whatNumberIs(Syntax s) {
        if(s instanceof Value)
            return whatNumberIsValue((Value)s);
        else if(s instanceof Binding)
            return whatNumberIsBinding((Binding)s);
        else
            throw new IllegalArgumentException(
                "hey, what's the new Syntax flavour ?");
    }
    
    public int whatNumberIsValue(Value v) {
        for(int i=0;i < arity();i++)
            if(arg(i).equals(v)) return i;
        return -1;
    }

    public int whatNumberIsBinding(Binding b) {
        for(int i=0;i < bindings.size();i++)
            if(binding(i).containsBinding(b)) return i;
        return -1;
    }

    public Binding addBinding(String bName, Vector vNames) {
        Value newBbody;
        if(vNames.size() == 0)
           newBbody = new BtmVal();
        else {
           newBbody = new LamAbs(vNames.size(),vNames);
        }
        return addBindingWithValue(bName,newBbody);
    }

    public Binding addBindingWithValue(String bName, Value newBbody) {
        VarBind newB = new VarBind(this,bName);
        addArg(newBbody);
        bindings.addElement(newB);
        newB.parent = this;
        return newB;
    }

    public void deleteBinding(Binding b,Vector vars) {
        int bn = whatNumberIsBinding(b);
        deleteBinding(bn,vars);
    }

    public void deleteBinding(int bn, Vector vars) {
        removeAllVars(vars);
        bindings.removeElementAt(bn);
        deleteArg(bn);
    }

    public LetAbs promoteBindings() {
        // find parent binding to promote to
        Value pb = (Value)parent;
        while(pb != null && !(pb instanceof LetAbs))
            pb = (Value)pb.parent;
        if(pb == null) return null;
        LetAbs plabs = (LetAbs)pb;
        while(arity() > 0) {
            Binding b = binding(0);
            Value v = arg(0);
            deleteBinding(0,null);
            plabs.addBinding(b); plabs.addArg(v);
        }
        return plabs;
    }

    public void promoteBindings(LetAbs src) {
        while(src.arity() > 0) {
            Binding b = src.binding(0);
            Value v = src.arg(0);
            src.deleteBinding(0,null);
            addBinding(b); addArg(v);
        }        
    }

    public boolean canBeRemoved() {
        return arity() == 0;
    }

    /* you know, a whole-program dependancy analysis and pruning
       operation might be a good idea */
       
    public void prune() {
        Set depend = body().directDependencies(this);
        Set pruneCandidates = new Set(allBindings());
        Set i = new Set();
        while(!pruneCandidates.isEmpty() &&
            !(i = depend.intersection(pruneCandidates)).isEmpty()) {

            // union (map (directDependancies . arg . whatNumberIs) i)

            Set seen = new Set();
            Vector vi = i.vectorise();
            for(int j=0;j < vi.size();j++) {
                int bn = whatNumberIs((Binding)vi.elementAt(j));
                Integer bni = new Integer(bn);
                if(!seen.elem(bni)) {
                    depend.add(arg(bn).directDependencies(this));
                    seen.put(bni,bni);
                }
            }

            pruneCandidates.subtract(i);
        }

        while(!pruneCandidates.isEmpty()) {
            Binding b = (Binding)pruneCandidates.choose();
            int bn = whatNumberIs(b);
            Binding br = binding(bn);
            Set allB = new Set(br.getAllBindings());
            if(br.isTemporary && pruneCandidates.hasSubset(allB)) {
                deleteBinding(bn,new Vector());
            }
            pruneCandidates.subtract(allB);
        }

    }

/*
    public void prune() {
        Vector forDeletion = new Vector();
        for(int i=0;i < arity();i++) {
            Vector v = binding(i).getAllBindings();
            Vector bs = new Vector();
            boolean containsFixed = false;
            for(int j=0;j < v.size();j++) {
                Binding b = (Binding)v.elementAt(j);
                if(!b.isTemporary) {
                    containsFixed = true;
                    break;
                } 
                bs.addElement(b);
            }
            if(containsFixed)
                continue;
            Object r = traverseSyntaxTree(new ContainsVarFunctor(bs));
            if(r == null)
                forDeletion.addElement(binding(i));
        }
        for(int i=0;i < forDeletion.size();i++) {
            Binding b = (Binding)forDeletion.elementAt(i);
            deleteBinding(b,new Vector());
        }
    }
*/

    class ContainsVarFunctor extends Functor {
        Hashtable bTable;
        public ContainsVarFunctor(Vector bnds) {
            bTable = new Hashtable();
            for(int i=0;i < bnds.size();i++)
                bTable.put(bnds.elementAt(i),bnds.elementAt(i));
        }

        public Object eval(Object x) {
            if(x instanceof VarVal) {
                VarVal v = (VarVal)x;
                if(bTable.containsKey(v.binding))
                    return v;
            }
            return null;
        }
    }

    /* maybe do something nice with indentation ? */
    public String writeExp() {
        StringBuffer buf = new StringBuffer("(let {");
        for(int i=0;i < arity();i++) {
            buf.append(binding(i).writeExp());
            buf.append(" = ");
            buf.append(arg(i).writeExp()+";");
        }
        buf.append("} in "); buf.append(body().writeExp());
        buf.append(")"); return buf.toString();
    }

    /* evaluation ------------------------------------------------ */

    public Value reduce(Reducer r) throws EvaluationException {
// OPTIMISATION
        prune();
        if(canBeRemoved()) {
            r.step(Reducer.REMOVE_EMPTY_LET,null,body(),this);
            return body();
        }
        
        Value v = body().reduce(r);
        if(v == null)
            return null;
        else {
            setBody(v); return this;
        }
    }

    public Value getGroundValue() { return body().getGroundValue(); }

    public boolean isWHNF(Reducer r) {
        /* this is a bit tricky.  Do I do a "pseudo-prune" ? */
        if(canBeRemoved())
            return false;
        return body().isWHNF(r);
    }

}
