/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997-1998
*/

package vfpe.syntax;

/* Literal (ie string, int, float, char etc) values */

import java.util.Hashtable;
import java.util.Vector;

import jkk.Set;
import vfpe.CodeGenException;
import vfpe.EvaluationException;
import vfpe.Reducer;
import vfpe.editor.Editor;
import vfpe.editor.LiteralLayout;
import vfpe.editor.SyntaxLayout;
import vfpe.syntax.Value;
import vfpe.type.Type;
import vfpe.type.TypeException;	
import vfpe.type.TypeInferenceState;

public class Literal extends Value {
	public static final long serialVersionUID = 1;
	
	protected String tstr;
	public String str;
	public Object value;

	public Literal() { super(); }
	public Literal(String s) {

		/* This should have some serious checking */

		super(); str = s; tstr = "Foo";

		boolean isInt = false; int i = 0;
		try {
			if(str.equals("-"))
				isInt = false;
			else {
				i = Integer.parseInt(str); isInt = true;
			} 
		} catch(NumberFormatException nfe) {
				isInt = false;
		}

		boolean isFloat = false; Float f = null;
		try {
			if(str.equals("-")) isFloat = false;
			else {
				f = Float.valueOf(str); isFloat = true;
			} 
		} catch(NumberFormatException nfe) {
			isFloat = false;
		}

		if(isFloat) {
			if(isInt) {
				tstr = "Int"; value = new Integer(i);
			} else {
				tstr = "Float"; value = f;
			}
		} else if(str.charAt(0) == '\'') {
			tstr = "Char";
			/* should put Haskell escape-parsing in here */
			value = new Character(str.charAt(1));
		} else if(str.charAt(0) == '"') {
			tstr = "List Char";
			int n = str.lastIndexOf('"');
			if(n < 1) throw new IllegalArgumentException("bad literal: " + str);
			value = str.substring(1,n);
		} else
			throw new IllegalArgumentException("bad literal: " + str);
	}
	
	public String syntaxName() { return "literal"; }

	public SyntaxLayout makeLayout() { return new LiteralLayout(this); }

	/* type inference */

	public Set inferType(TypeInferenceState itypes) {
		itypes.setType(this,Type.parseType(tstr));
		return new Set();
	}

	/* Haskell code generation */

	public String haskell() throws CodeGenException {
		if(tstr.equals("Int"))
			return "(" + str + " :: Int)";
		else if(tstr.equals("Float"))
			return "(" + str + " :: Float)";
		else
			return str;
	}

	/* output */

	public String writeExp() { return str; }

	/* tools */

	public Value toConsForm() {
		String s = (String)value;
		if(s.length() == 0)
			return ConstAbs.makeConst("data/Nil");
		else {
			Value head = null; Value tail = null;
			try {
				head = new Literal("'"+s.substring(0,1)+"'");
				tail = new Literal("\""+s.substring(1,s.length())+"\"");
			} catch(Exception e) {
				Editor.panic("Bad cons for in string literal");
			}
			AppVal av = new AppVal();
			av.addBody(ConstAbs.makeConst("data/Cons"));
			av.addArg(head); av.addArg(tail);
			return av;
		}
	}
	
	/* evaluation ------------------------------------------------ */

	public Value reduce(Reducer r) throws EvaluationException {
		if(value instanceof String) {
			Value retVal = toConsForm();
			r.step(Reducer.STRING_TO_CONS_FORM,null,retVal,this);
			return retVal;
		} else
			return null;
	}

	public boolean isWHNF(Reducer r) {
		return !(value instanceof String);
	}

}
