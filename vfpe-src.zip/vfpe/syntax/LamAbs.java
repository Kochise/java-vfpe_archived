/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997-1999
*/

/* lambda abstractions */

package vfpe.syntax;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import jkk.Set;
import vfpe.CodeGenException;
import vfpe.editor.LamAbsLayout;
import vfpe.editor.SyntaxLayout;
import vfpe.syntax.AbsVal;
import vfpe.type.Type;
import vfpe.type.TypeException;
import vfpe.type.TypeInferenceState;
import vfpe.type.TypeVar;

public class LamAbs extends AbsVal {
	public static final long serialVersionUID = 1;
	
	private static String [] DEF_VAR_NAMES =
	{
		"x", "y", "z", "u", "v"
	};
	
	public LamAbs() { super(); }
	public LamAbs(int nvars) {
		super();
		addBody(new BtmVal());
		for(int i=0;i < nvars;i++) {
			String vname =
				(i < DEF_VAR_NAMES.length ? DEF_VAR_NAMES[i] : ("v"+i));
			bindings.addElement(new VarBind(this,vname));
		}
	}
	public LamAbs(int nvars, Vector vNames) {
		this(nvars);
		for(int i=0;i < vNames.size();i++) {
			Binding lamB = binding(i);
		    lamB.name = (String)vNames.elementAt(i);
		}
	}

	public SyntaxLayout makeLayout() {
		return new LamAbsLayout(this);
	}

	/* overrides */

	public String syntaxName() { return "lambda abstraction"; }

	public void findActiveThreads(Vector v) { return; }

	public String writeExp() {
		StringBuffer buf = new StringBuffer("(\\");
		for(int i=0;i < bindings.size();i++) 
			buf.append(binding(i).writeExp());
		buf.append("->"); buf.append(body().writeExp());
		buf.append(")"); return buf.toString();
	}

	/* tools */

	public void uncurry() {
		Value b = body();
		if(b instanceof LamAbs) {
			LamAbs blabs = (LamAbs)b;
			Binding firstBind = blabs.binding(0);
			blabs.removeBinding(0);
			addBinding(firstBind);
			if(blabs.bindings.size() == 0) {
				blabs.replace(blabs.body());
			}
		}
	}

	public void curry() {
		if(bindings.size() > 1) {
			int i = bindings.size() - 1;
			Binding lastBinding = binding(i);
			Value bd = body();
			LamAbs labs = new LamAbs();
			labs.addBody(bd);
			removeBinding(i);
			labs.addBinding(lastBinding);
			setBody(labs);
		}
	}
	
	/* type inference */

	public Set inferType(TypeInferenceState itypes) 
		throws TypeException {

		/* set initial var types to type vars */

		for(int i=0;i < bindings.size();i++)
			binding(i).inferBindingType(itypes);
			
		/* infer type of body */

		Set v = ((Value)body()).inferType(itypes);

		/* construct type */

		Type rt = new Type(Type.FUNC_TAG,2);
		Type lt = rt;
		lt.args[0] = itypes.getType(binding(0));
		for(int i=1;i < bindings.size();i++) {
			lt.args[1] = new Type(Type.FUNC_TAG,2);
			lt = lt.args[1];
			lt.args[0] = itypes.getType(binding(i));
		}
		lt.args[1] = itypes.getType(body());
		itypes.setType(this,rt);

		return removeBoundVars(v);
	}

}
