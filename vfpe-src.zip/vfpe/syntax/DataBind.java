/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997-1998
*/

/* User-defined constructor functions */

package vfpe.syntax;

import java.util.Vector;

import vfpe.type.Type;

public class DataBind extends ConstBind {
	public static final long serialVersionUID = 1;
	
	public Vector argTypeStrings;
	
	public DataBind() { super(); }
	public DataBind(
		ConstAbs parent, String nm, String nt, String gp,
		String hs, Vector argTypeStrings) {
		super(parent,nm,nt,gp,hs);
		// parent should always be a DataAbs
		isData = true;
		this.argTypeStrings = argTypeStrings;
	}

	/* overrides */

	public String syntaxName() { return "constructor binding"; }
	
	public VarVal makeVar() {
		return new Const(this);
	}

}
