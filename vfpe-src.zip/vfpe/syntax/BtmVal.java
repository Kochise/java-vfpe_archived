/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997-1998
*/

package vfpe.syntax;

/* Undefined or placeholder values */

import java.util.Hashtable;

import jkk.Set;
import vfpe.EvaluationException;
import vfpe.Reducer;
import vfpe.CodeGenException;
import vfpe.editor.BtmLayout;
import vfpe.editor.SyntaxLayout;
import vfpe.syntax.Value;
import vfpe.type.TypeInferenceState;
import vfpe.type.TypeVar;

public class BtmVal extends Value {
    public static final long serialVersionUID = 1;
    public BtmVal() { super(); }

    public SyntaxLayout makeLayout() { return new BtmLayout(this); }

    /* overrides */

    public String syntaxName() { return "placeholder"; }

    /* type inference */

    public Set inferType(TypeInferenceState itypes) {
        itypes.setType(this,new TypeVar());
        return new Set();
    }

    /* tools */

    public String writeExp() { return "undefined"; }

    /* Haskell output */

    public String haskell() throws CodeGenException {
        return "vfpUndefined";
    }

    /* evaluation ------------------------------------------------ */

    public Value reduce(Reducer r) throws EvaluationException {
        throw new EvaluationException("undefined value");
    }

    public boolean isWHNF(Reducer r) { return false; }
    
}
