/*
    * * * * * software from the house of J Kyle Kelso
    * **  ** 
  *** * * * * copyright 1997-1999
*/

/* simple variable pattern */

package vfpe.syntax;

import java.util.Vector;

import vfpe.EvaluationException;
import vfpe.Reducer;
import vfpe.editor.SyntaxLayout;
import vfpe.editor.VarBindLayout;
import vfpe.syntax.AbsVal;
import vfpe.syntax.Binding;
import vfpe.syntax.VarVal;
import vfpe.type.TypeInferenceState;
import vfpe.type.TypeVar;

public class VarBind extends Binding {
	public static final long serialVersionUID = 1;

	public VarBind() { super(); }
	public VarBind(Syntax parent, String name) {
		super(parent,name);
	}

	public String syntaxName() { return "variable binding"; }

	public SyntaxLayout makeLayout() {
		return new VarBindLayout(this);
	}
	
	/* tools */

	public void inferBindingType(TypeInferenceState itypes) {
		itypes.setType(this,new TypeVar());
	}

	public VarVal makeVar() { return new VarVal(this); }

	/* evaluation ------------------------------------------------ */

	public Value match(Value v, Reducer r) throws EvaluationException {
		return null;
	}

}

