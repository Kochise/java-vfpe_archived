/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997-1999
*/

/* patterns */

package vfpe.syntax;

import java.util.Hashtable;
import java.util.Vector;

import vfpe.ListParser;
import vfpe.EvaluationException;
import vfpe.Reducer;
import vfpe.editor.BindingLayout;
import vfpe.editor.Editor;
import vfpe.editor.SyntaxLayout;
import vfpe.syntax.AbsVal;
import vfpe.type.TypeException;
import vfpe.type.TypeInferenceState;

public abstract class Binding extends Syntax {
	public static final long serialVersionUID = 1;
	public String name;
	public Syntax parent;
	public boolean breakpoint;
	public boolean isTemporary;

	public Binding() { super(); }
	public Binding(Syntax parent, String nm) {
		super(); 
		name = nm; this.parent = parent;
	}

	/* overrides ------------------------------------------------- */

	public SyntaxLayout makeLayout() {
		return new BindingLayout(this);
	}

	public Syntax getParent() { return parent; }

	public Vector getChildren() { return new Vector(); }

	public Syntax copy(Hashtable already, boolean interpCopy) {
		Binding tmp = (Binding)super.copy(already,interpCopy);
		tmp.isTemporary = tmp.isTemporary || interpCopy;
		if(already.containsKey(parent))
			tmp.parent = (Syntax)already.get(parent);
		return tmp;
	}

	public String syntaxName() { return "binding"; }

	public String writeExp() { return name; }

	/* tools */

	public String getName() { return writeExp(); }

	public String getLongName() { return writeExp(); }

	public void getPathToBinding(Vector path) {
		if(parent instanceof AbsVal)
			return;
		PatBind pb = (PatBind)parent;
		for(int n=0;n < pb.bindings.size();n++) {
			if(pb.binding(n).equals(this)) {
				path.insertElementAt(new Integer(n),0);
				pb.getPathToBinding(path); return;
			}
		}
		Editor.panic("Can't create path for binding " + name);
	}

	public Binding getBindingFromPath(Vector path) {
		if(path.size() == 0) return this;
		PatBind pb = (PatBind)this;
		int n = ((Integer)path.firstElement()).intValue();
		path.removeElementAt(0);
		return pb.binding(n).getBindingFromPath(path);
	}

	public AbsVal abstraction() {
		Syntax tmp = this;
		while(!(tmp instanceof AbsVal))
			tmp = ((Binding)tmp).parent;
		return (AbsVal)tmp;
	}

	public abstract VarVal makeVar();

	public void replace(Binding b) {
        AbsVal abs = abstraction();
		b.parent = parent;
		if(parent instanceof AbsVal)
			((AbsVal)parent).replaceBindingChild(this,b);
		else if(parent instanceof PatBind)
			((PatBind)parent).replaceBindingChild(this,b);
        Vector v = abs.findAllVars(this);
        for(int i=0;i < v.size();i++) {
            VarVal vv = (VarVal)v.elementAt(i);
            vv.binding = b;
        }
	}

	public Vector getAllBindings() {
		return getAllBindings(true);
	}

	public Vector getAllBindings(boolean includeTemporaries) {
		Vector v = new Vector();
		if(!isTemporary || includeTemporaries)
			v.addElement(this);
		return v;
	}

	public void setTemporary(boolean tmp) {
		isTemporary = tmp;
	}

	public boolean containsBinding(Binding b) {
		return this.equals(b);
	}

	/* type stuff ------------------------------------------------ */

	public void inferBindingType(TypeInferenceState itypes)
		throws TypeException {
		Editor.panic("Whoa there son, why're you trying to do this ?");
	}

	public void narrowBindingType(TypeInferenceState itypes)
		throws TypeException {

		// find the let binding that the change site is part of
		AbsVal absv = abstraction();
		if(absv instanceof LamAbs) {
			absv.narrowBindingType(itypes);
		} else if(absv instanceof LetAbs) {
			LetAbs labs = (LetAbs)absv;
			Binding bbr = (Binding)findBindingBodyRoot();
			if(bbr == null)
				return;
			labs.narrowBinding(bbr, itypes);
		}
	}

	/* evaluation ------------------------------------------------ */

	public /*abstract*/ Value match(Value v, Reducer r) throws EvaluationException {
		return null;
	}

}
