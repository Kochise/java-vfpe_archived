/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1999
*/

/* special syntax for arrays */

package vfpe.syntax;

import jkk.Set;
import vfpe.EvaluationException;
import vfpe.Reducer;
import vfpe.editor.ArrayLayout;
import vfpe.editor.SyntaxLayout;
import vfpe.type.Substitution;
import vfpe.type.Type;
import vfpe.type.TypeException;
import vfpe.type.TypeInferenceState;

public class Array extends Value {
	public static final long serialVersionUID = 1;

	public Array() {
		super(); addBody(null);
	}
	public Array(int size) {
		this();
		for(int i=0;i < size;i++) {
			addArg(new BtmVal());
		}
	}

	/* overrides */

	public String syntaxName() { return "array"; }

	public SyntaxLayout makeLayout() {
		return new ArrayLayout(this);
	}

	public String writeExp() {
		return "array";
	}

	/* tools */

	/* type inference */

	public Set inferType(TypeInferenceState itypes)
		throws TypeException {

		/* set initial type to (Array a) */

		Set tmp = new Set();
		itypes.setType(this,Type.parseType("(Array a)"));

		/* check type for each element */
		
		for(int i=0;i < arity();i++) {
			tmp.add(arg(i).inferType(itypes));
			Type elType = new Type(Type.ARRAY_TAG,1);
			elType.args[0] = itypes.getType(arg(i));
			Substitution subs = Type.unify(
				itypes.getType(this), elType);
			itypes.substitute(subs);
		}
		return tmp;
	}

	/* evaluation ------------------------------------------------ */

	public Value reduce(Reducer r) throws EvaluationException {
		// options: lazy arrays, strict arrays, parallel arrays ...
		return null;
	}

	public boolean isWHNF(Reducer r) { return true; }

}
