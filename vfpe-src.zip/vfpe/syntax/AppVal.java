/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997-1999
*/

/* function application */

package vfpe.syntax;

import java.util.Hashtable;
import java.util.Vector;

import jkk.Set;
import vfpe.CodeGenException;
import vfpe.EvaluationException;
import vfpe.PatternMatchFailure;
import vfpe.PrimEvaluator;
import vfpe.Reducer;
import vfpe.editor.AppLayout;
import vfpe.editor.Editor;
import vfpe.editor.SyntaxLayout;
import vfpe.type.Substitution;
import vfpe.type.Type;
import vfpe.type.TypeException;
import vfpe.type.TypeInferenceState;
import vfpe.type.TypeVar;

import vfpe.syntax.Value;

public class AppVal extends Value {
    public static final long serialVersionUID = 1;
    
    public AppVal() { super(); }
    public AppVal(int n) { 
        super(); addBody(new BtmVal());
        for(int i=0;i < n;i++)
            addArg(new BtmVal());
    }

    public SyntaxLayout makeLayout() {
        return new AppLayout(this);
    }

    public String writeExp() { 
        StringBuffer buf = new StringBuffer();
        buf.append('(');
        buf.append(function().writeExp());
        for(int i=0;i < arity();i++) {
            buf.append(' ');
            buf.append(arg(i).writeExp());
        }
        buf.append(')'); return buf.toString();
    }

    /* tools */

    public Value function() { return (Value)body(); }
    /* setFunction() ? */

    public Value getArgFromPath(Vector path) {
        if(path.size() == 0) return this;
        int n = ((Integer)path.firstElement()).intValue();
        path.removeElementAt(0);
        return ((AppVal)this.arg(n)).getArgFromPath(path);
    }

    public void uncurry() {
        Value f = function();
        if(f instanceof AppVal) {
            AppVal fapp = (AppVal)f;
            int i=fapp.arity()-1;
            Value lastArg = fapp.arg(i);
            fapp.deleteArg(i);
            addArgAt(lastArg,0);
            if(i == 0)
                f.replace(fapp.function());
        }
    }

    public void curry() {
        if(arity() > 1) {
            Value f = function();
            Value firstArg = arg(0);
            AppVal newF = new AppVal();
            newF.addBody(f);
            deleteArg(0);
            newF.addArg(firstArg);
            setBody(newF); f.parent = newF;
        }
    }

    public String syntaxName() { return "application"; }

    /* evaluation ------------------------------------------------ */

    public Value reduce(Reducer r) throws EvaluationException {

        /* promote let */

        if(function() instanceof LetAbs) {
            LetAbs labs = (LetAbs)function(); promoteLet();
            r.step(Reducer.PROMOTE_LET,null,labs,this); return labs;
        }

        /* collect args on spine */

        Vector argV = new Vector();
        Value f = collectArgs(argV);
        int nArgs = argV.size();
        Value [] argv = new Value[nArgs];
        for(int i=0;i < nArgs;i++)
            argv[i] = (Value)argV.elementAt(i);

        /*    We do this here instead of after evaluating the function
            so that we can check for strict constructors.  If it
            _is_ a const its in NF anyway. */

        if(f instanceof Const) {
            Const c = (Const)f;
            ConstBind cb = (ConstBind)c.binding;
            if(cb.isData) {
                if(!r.strictConstructors) return null;
                if(nArgs < cb.arity()) return null;
            }
        }

        /* if this is AOR evaluate arg */

        if(r.reductionOrder == Reducer.AOR)
            if(evalArgs(r,argv) != null)
                return this;

        /* evaluate function */

        Value nf = f.reduce(r);
        if(nf != null) {
            f.replace(nf); return this;
        }

        /* prim-redex */

        if(f instanceof Const) {
            Const c = (Const)f;
            ConstBind cb = (ConstBind)c.binding;
            if(cb.isData) {
                /*    note with NOR and strict constructors,
                    NOR "wins" */
                return null;
            }
            if(cb.primValue != null)
                Editor.panic("value prim not expanded");
            PrimEvaluator evtr = cb.primEval;
            if(nArgs < evtr.arity()) return null;
            Value primRet = evtr.reduce(this,argv,cb,r);
            if(c.binding.breakpoint) {
                r.message = "Stopping at breakpoint for " + c.name();
                r.breakHalt = true;
            }

            return primRet;
        }

        /* pattern sets */

        if(f instanceof Patterns) {
            Patterns pats = (Patterns)f;
            if(nArgs < pats.nArgs) return null;
            LamAbs labs = pats.pattern(0);
            
            /* match patterns */

            try {
                for(int i=0;i < nArgs;i++) {
                    Binding bnd = labs.binding(i);
                    Value matchedArg = bnd.match(argv[i],r);
                    if(matchedArg != null) {
                        argv[i].replace(matchedArg);
                        return this;
                    }
                }
                r.step(Reducer.PATTERN_MATCH,null,labs,pats);
                pats.replace(labs);
            } catch(PatternMatchFailure pmf) {
                if(pats.arity() == 1)
                    throw new EvaluationException("pattern set fall-through");
                pats.deleteArg(0);
                r.step(Reducer.PATTERN_MISMATCH,null,pats,pats);
            }
            
            return this;
        }

        /* beta-reduction */

        if(f instanceof LamAbs) {
            LamAbs labs = (LamAbs)f;

            /* uncurry lambdas */

            if(labs.body() instanceof LamAbs) {
                labs.uncurry();
                r.step(Reducer.UNCURRY_LAMBDA,null,labs,labs);
                return this;
            }

            if(labs.bindings.size() > nArgs)
                return null;
                
            /* match patterns */
            
            for(int i=0;i < nArgs;i++) {
                Binding bnd = labs.binding(i);
                Value matchedArg = bnd.match(argv[i],r);
                if(matchedArg != null) {
                    argv[i].replace(matchedArg);
                    return this;
                }
            }

            /* beta-reduction */

            if(r.callType == Reducer.CALL_BY_NEED) {
                LetAbs letAbs = new LetAbs();
                letAbs.addBody(labs.body());
                for(int i=0;i < nArgs;i++) {
                    Binding bnd = labs.binding(i);
                    bnd.setTemporary(true);
                    letAbs.addBinding(bnd);
                    letAbs.addArg(argv[i]);
                }
                r.step(Reducer.BETA_REDUCE,null,letAbs,this);
                return letAbs;
            } else { // default to call-by-value
                LetAbs lb = new LetAbs();
                lb.addBody(null);
                for(int i=0;i < nArgs;i++) {
                    Vector bnds = labs.binding(i).getAllBindings();
                    for(int k=0;k < bnds.size();k++) {
                        Binding bnd = (Binding)bnds.elementAt(k);
                        Vector bPath = new Vector();
                        bnd.getPathToBinding(bPath);
                        Vector instances = labs.findAllVars(bnd,true);
                        for(int j=0;j < instances.size();j++) {
                            VarVal vv = (VarVal)instances.elementAt(j);
                            Value arg = followBindingPath((Value)argv[i],bPath,lb);
                            vv.replace((Value)arg.copy(true));
                        }
                    }
                }
                Value rv = labs.body();
                if(lb.arity() > 0) {
                    lb.setBody(rv); rv = lb;
                }
                r.step(Reducer.BETA_REDUCE,null,rv,this);
                return rv;
            }
        }
        
        throw new EvaluationException(
            "Don't know how to apply function " + f.writeExp());
    }

    protected Value evalArgs(Reducer r, Value [] argv) throws EvaluationException {
        for(int i=0;i < argv.length;i++) {
            Value argV = argv[i];
            Value argVR = argV.reduce(r);
            if(argVR != null) {
                argV.replace(argVR); return this;
            }
        }
        return null;
    }

    protected Value collectArgs(Vector argv) {
        for(int i=arity()-1;i >= 0;i--)
            argv.insertElementAt(arg(i),0);
        if(!(function() instanceof AppVal)) {
            return function();
        }
        AppVal newApp = (AppVal)function();
        return newApp.collectArgs(argv);
    }

    public static Value followBindingPath(Value v, Vector bPath, LetAbs labs) {
        int n = 0;
        while(n < bPath.size()) {
            if(v instanceof LetAbs) {
                LetAbs lb = (LetAbs)v;
                labs.promoteBindings(lb);
                v = lb.body();
                lb.replace(lb.body());
            } else if(v instanceof AppVal) {
                int head = ((Integer)bPath.elementAt(n)).intValue();
                n++;
                AppVal av = (AppVal)v;
                Vector args = new Vector();
                Value f = av.collectArgs(args);
                v = (Value)args.elementAt(head);
            } else {
                Editor.panic("you've uncovered the bug in followBindingPath()." +
                    "  Bugger.  Tell Joel about this.");
            }
        }
        return v;
    }

    /* note that this is quite a clean abstract interpretation of the redex */

    public boolean isWHNF(Reducer r) {

        /* promote let */

        if(function() instanceof LetAbs)
            return false;

        /* collect args on spine */

        Vector argV = new Vector();
        Value f = collectArgs(argV);
        int nArgs = argV.size();
        Value [] argv = new Value[nArgs];
        for(int i=0;i < nArgs;i++)
            argv[i] = (Value)argV.elementAt(i);

        /*    We do this here instead of after evaluating the function
            so that we can check for strict constructors.  If it
            _is_ a const its in NF anyway. */

        if(f instanceof Const) {
            Const c = (Const)f;
            ConstBind cb = (ConstBind)c.binding;
            if(cb.isData) {
                if(!r.strictConstructors) return true;
                if(nArgs < cb.arity()) return true;
            }
        }

        /* if this is AOR evaluate arg */

        if(r.reductionOrder == Reducer.AOR)
            for(int i=0;i < argv.length;i++)
                if(!argv[i].isWHNF(r))
                    return false;

        /* evaluate function */

        if(!f.isWHNF(r))
            return false;

        /* prim-redex */

        if(f instanceof Const) {
            Const c = (Const)f;
            ConstBind cb = (ConstBind)c.binding;
            if(cb.isData) {
                /*    note with NOR and strict constructors,
                    NOR "wins" */
                return true;
            }
            if(cb.primValue != null)
                Editor.panic("value prim not expanded");
            PrimEvaluator evtr = cb.primEval;
            if(nArgs < evtr.arity()) return true;
            return false;
        }

        /* pattern sets */

        if(f instanceof Patterns) {
            Patterns pats = (Patterns)f;
            if(nArgs < pats.nArgs) return true;

            /* a fully applied pattern is never in normal form */

            return false;
        }

        /* beta-reduction */

        if(f instanceof LamAbs) {
            LamAbs labs = (LamAbs)f;

            /* uncurry lambdas */

            if(labs.body() instanceof LamAbs)
                return false;

            if(labs.bindings.size() > nArgs)
                return true;
                
            return false;
        }
        
        Editor.panic("Unknown function type in AppVal.isWHNF()");
        return true;
    }

    // tidying after reduction

    public void tidy() {
        Value f = function();
        while(f instanceof AppVal) {
            uncurry(); f = function();
        }
    }

    public void promoteLet() {
//OPTIMISATION
// bother only if let vars are in use
        LetAbs labs = (LetAbs)function();
        Value lb = labs.body();
        labs.setBody(this);
        setBody(lb); lb.setParent(this);
        labs.setBody(this); this.setParent(labs);
    }

    /* type inference */

    public Set inferType(TypeInferenceState itypes) 
        throws TypeException {

        /* infer type of function */

        Set tmp = function().inferType(itypes);

        /* infer function argument types */

        for(int i=0;i < arity();i++)
            tmp.add(((Value)arg(i)).inferType(itypes));

        /* build types for args for unification */

        Type ft = new Type(Type.FUNC_TAG,2);
        ft.args[0] = itypes.getType(arg(0));
        Type at = ft;
        for(int i=1;i < arity();i++) {
            at.args[1] = new Type(Type.FUNC_TAG,2);
            at = at.args[1];
            at.args[0] = itypes.getType(arg(i));
        }
        at.args[1] = new TypeVar();

        /* unify */
        
        Substitution subs = Type.unify(itypes.getType(function()),ft);
        itypes.setType(this,ft.funRetType(arity()-1));
        itypes.substitute(subs);

        return tmp;
    }

}

