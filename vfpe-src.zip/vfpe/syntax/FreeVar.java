/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1998
*/

/* place holder value for free variables in serialised expressions */

package vfpe.syntax;

import jkk.Set;
import vfpe.editor.SyntaxLayout;
import vfpe.syntax.Value;
import vfpe.type.TypeException;
import vfpe.type.TypeInferenceState;

public class FreeVar extends VarVal {
	public static final long serialVersionUID = 1;
	
	public String name;
	public String tstr;

	public FreeVar() { super(); }
	public FreeVar(String name, String tstr) { 
		super(); this.name = name; this.tstr = tstr;
	}

	public SyntaxLayout makeLayout() {
		return null;
	}

	/* tools */

	public String writeExp() {
		return "(FV: " + name + ")";
	}

	public String syntaxName() { return "free variable"; }

	/* type inference */

	public Set inferType(TypeInferenceState itypes) 
		throws TypeException {

		throw new TypeException("tried to type FreeVar",null,null);
	}

}
