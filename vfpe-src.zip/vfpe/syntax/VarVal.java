/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997-1999
*/

/* Variable - shared value references */

package vfpe.syntax;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import jkk.Functor;
import jkk.Set;
import vfpe.CodeGenException;
import vfpe.EvaluationException;
import vfpe.ThreadReturnWait;
import vfpe.Reducer;
import vfpe.type.Type;
import vfpe.type.TypeException;
import vfpe.type.TypeInferenceState;
import vfpe.editor.SyntaxLayout;
import vfpe.editor.VarLayout;
import vfpe.syntax.AbsVal;
import vfpe.syntax.Binding;

public class VarVal extends Value {
    public static final long serialVersionUID = 1;
    
    public Binding binding;
    
    public VarVal() { super(); }
    public VarVal(Binding b) {
        super(); binding = b;
    }

    public String syntaxName() { return "variable"; }

    public SyntaxLayout makeLayout() { return new VarLayout(this); }

    // doesn't introduce new bindings for any vars
    public Syntax copy(Hashtable already, boolean interpCopy) {
        Value tmp;
        if(already.containsKey(binding)) {
            tmp = (Value)super.copy(already,interpCopy);
            ((VarVal)tmp).binding = (Binding)already.get(binding);
        } else {
            tmp = (Value)super.copy(already,interpCopy);
            ((VarVal)tmp).binding = binding;
        }
        return tmp;
    }
    
    public Set inferType(TypeInferenceState itypes) throws TypeException {
        if(itypes.getType(binding) == null)
            throw new TypeException("out-of-scope variable " + name(),
                null, null);
        Set nonGeneric = nonGenericTVs(itypes);
        Type gType = itypes.getType(binding).copy(nonGeneric);
        itypes.setType(this,gType);
        itypes.setGenerics(binding,gType.freeVars().difference(nonGeneric));
        return new Set(this,this);
    }
    
    public String name() { return binding.getName(); }

    /* this is a tool used by the "add argument" operation */
    /*
    public void updateWithApp() {

    }
    */

    public boolean inScope() {
        AbsVal ab = binding.abstraction();
        Syntax p = getParent();
        while(p != null) {
            if(p == ab)
                return true;
            p = p.getParent();
        }
        return false;
    }

    public String writeExp() { return name(); }

    /* evaluation ------------------------------------------------ */

    public Value reduce(Reducer r) throws EvaluationException {

        /* I think this should be right */
        /* this check might have to be "not a LetAbs" instead */

        if(binding.abstraction() instanceof LamAbs)
            throw new EvaluationException("tried evaluated lambda-bound var "
                + name());
            // return null;

        /* check to see if we've been here before this time */

        boolean cycleExpansion = false;
        if(r.spine.contains(binding)) {
            if(r.expandCycles) {
                cycleExpansion = true;
            } else {
                /* sufficient condition for non-termination */
                r.step(Reducer.CYCLIC_REDUCTION,binding.name,null,null);
                return this;
            }
        }
        r.spine.addElement(binding);
        
        /* find root of value */
        
        LetAbs labs = (LetAbs)binding.abstraction();
        Vector path = new Vector();
        binding.getPathToBinding(path);
        int vNum = labs.whatNumberIs(binding);
        Value vRoot = labs.arg(vNum);

        /* evaluate until we have the value */

        while(path.size() > 0) {
            if(vRoot.isWHNF(r)) {

                /* its in WHNF - find next constructor */

                int nextPathNum = ((Integer)path.firstElement()).intValue();
                path.removeElementAt(0);
                Value preGround = vRoot;
                vRoot = vRoot.getGroundValue();
                if(preGround != vRoot) {
                    if(preGround instanceof LetAbs) {
                        LetAbs la = (LetAbs)preGround;
                        if(la.canBeRemoved()) {
                            Value bd = la.body();
                            la.replace(bd);
                            r.step(Reducer.REMOVE_EMPTY_LET,null,bd,la);
                            return this;
                        }
                        AbsVal plabs = la.promoteBindings();    
                        r.step(Reducer.PROMOTE_BINDING,null,plabs,plabs);
                        return this;
                    } else {
                        throw new EvaluationException("Joel hasn't written code"+
                            " for dealing with this (binding promotion ?) yet");
                    }
                }
                AppVal app = (AppVal)vRoot;
                Vector argV = new Vector();
                Value f = app.collectArgs(argV);
                int nArgs = argV.size();

                vRoot = (Value)argV.elementAt(nextPathNum);
                
            } else { // value not in normal form
                Value nvRoot = vRoot.reduce(r);
                vRoot.replace(nvRoot);
                return this;
            }
        }

        /* this is for profile keeping */
        
        int stepType;
        if(binding.isTemporary)
            stepType = Reducer.ENVIRONMENT_FETCH;
        else
            stepType = Reducer.BINDING_UNFOLD;

        /* reduce and either copy or step */

        if(vRoot.isWHNF(r) || cycleExpansion) {
            Value copyVal = (Value)vRoot.copy(true);
// OPTIMISATION
// check to see if we can remove the binding
            r.step(stepType,binding.getLongName(),copyVal,this);
            if(binding.breakpoint) {
                r.message = "Stopping at breakpoint for " + name();
                r.breakHalt = true;
            }
            return copyVal;
        } else {
            Value nvRoot = vRoot.reduce(r);
            vRoot.replace(nvRoot); return this;
        }
    }

    public boolean isWHNF(Reducer r) { return false; }

}
