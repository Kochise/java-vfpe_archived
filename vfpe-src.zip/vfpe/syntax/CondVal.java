/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997-1998
*/

/* if-then-else conditional */

package vfpe.syntax;

import java.util.Hashtable;
import java.util.Vector;

import jkk.Lib;
import jkk.Set;
import vfpe.CodeGenException;
import vfpe.EvaluationException;
import vfpe.Reducer;
import vfpe.type.Substitution;
import vfpe.type.Type;
import vfpe.type.TypeException;
import vfpe.type.TypeInferenceState;
import vfpe.editor.CondLayout;
import vfpe.editor.SyntaxLayout;
import vfpe.syntax.Value;

public class CondVal extends Value {
	public static final long serialVersionUID = 1;
	
	public CondVal() { super(); }
	public CondVal(String ignored) { 
		super(); addBody(new BtmVal());
		addArg(new BtmVal()); addArg(new BtmVal());
	}

	public SyntaxLayout makeLayout() {
		return new CondLayout(this);
	}

	/* tools */

	public Value condition() { return (Value)body(); }
	public Value consequent() { return (Value)arg(0); }
	public Value alternative() { return (Value)arg(1); }
	
	/* setFunction() ? */

	public String writeExp() { 
		StringBuffer buf = new StringBuffer("(if ");
		buf.append(condition ().writeExp());
		for(int i=0;i < arity();i++) {
			buf.append(" ");
			buf.append(((Value)arg(i)).writeExp());
		}
		buf.append(")"); return buf.toString();
	}

	public String syntaxName() { return "conditional"; }

	/* type inference */

	public Set inferType(TypeInferenceState itypes) 
		throws TypeException {

		/* infer and unify type of condition */

		Set tmp = condition().inferType(itypes);
		Substitution subs = Type.unify(itypes.getType(condition()),
			new Type("Bool",0));
		itypes.substitute(subs);

		/* infer and unify conseq and alt types */
		
		tmp.add(consequent().inferType(itypes));
		tmp.add(alternative().inferType(itypes));
		subs = Type.unify(itypes.getType(consequent()),
			itypes.getType(alternative()));
		itypes.substitute(subs);
		itypes.setType(this,itypes.getType(consequent()));

		return tmp;
	}

	/* evaluation ------------------------------------------------ */

	public Value reduce(Reducer r) throws EvaluationException {
		Value cond = condition().reduce(r);
		if(cond != null) {
			setBody(cond); return this;
		}
		Const boolConst = (Const)condition().getGroundValue();
		Value rVal;
		if(boolConst.name().equals("True")) {
			rVal = consequent();
			r.step(Reducer.CHOOSE_CONSEQUENT,null,rVal,this);
		} else {
			rVal = alternative();
			r.step(Reducer.CHOOSE_ALTERNATIVE,null,rVal,this);
		}
		return rVal;
	}

	public boolean isWHNF(Reducer r) { return false; }

}
