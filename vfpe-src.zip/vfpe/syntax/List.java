/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1998
*/

/* special syntax for lists */

package vfpe.syntax;

import jkk.Set;
import vfpe.EvaluationException;
import vfpe.Reducer;
import vfpe.editor.ListLayout;
import vfpe.editor.SyntaxLayout;
import vfpe.type.Substitution;
import vfpe.type.Type;
import vfpe.type.TypeException;
import vfpe.type.TypeInferenceState;

public class List extends Value {
	public static final long serialVersionUID = 1;

	public List() {
		super(); addBody(null);
	}

	/* overrides */

	public SyntaxLayout makeLayout() {
		return new ListLayout(this);
	}

	public String syntaxName() { return "list"; }

	public String writeExp() { return "list"; }

	/* tools */

	public Value toConsForm() {
		if(arity() == 0)
			return ConstAbs.makeConst("data/Nil");
		else {
			Value head = arg(0);
			List tail = new List();
			for(int i=1;i < arity();i++)
				tail.addArg(arg(i));
			AppVal av = new AppVal();
			av.addBody(ConstAbs.makeConst("data/Cons"));
			av.addArg(head); av.addArg(tail);
			return av;
		}
	}

	/* type inference */

	public Set inferType(TypeInferenceState itypes)
		throws TypeException {

		/* set initial type to [a] */

		Set tmp = new Set();
		itypes.setType(this,Type.parseType("[a]"));

		/* check type for each element */
		
		for(int i=0;i < arity();i++) {
			tmp.add(arg(i).inferType(itypes));
			Type elType = new Type(Type.LIST_TAG,1);
			elType.args[0] = itypes.getType(arg(i));
			Substitution subs = Type.unify(
				itypes.getType(this), elType);
			itypes.substitute(subs);
		}
		return tmp;
	}

	/* evaluation ------------------------------------------------ */

	public Value reduce(Reducer r) throws EvaluationException {
		Value retVal = toConsForm();
		r.step(Reducer.TO_CONS_FORM,null,retVal,this);
		return retVal;
	}

	public boolean isWHNF(Reducer r) { return false; }

}
