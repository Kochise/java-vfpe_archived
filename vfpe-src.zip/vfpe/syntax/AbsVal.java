/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997-1998
*/

/* abstractions */

package vfpe.syntax;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import jkk.Functor;

import jkk.Set;
import vfpe.editor.SyntaxLayout;
import vfpe.syntax.Binding;
import vfpe.syntax.Value;
import vfpe.syntax.VarVal;

public abstract class AbsVal extends Value {
	public static final long serialVersionUID = 1;
	public static final String DEFAULT_NAMESPACE = "default";
	
	public Vector bindings;
	public String namespace = DEFAULT_NAMESPACE;

	public AbsVal() { super(); bindings = new Vector(); }
	public AbsVal(Value bd) {
		super(); addBody(bd); bindings = new Vector(); 
	}

	/* override stuff -------------------------------------------- */
	
	public String syntaxName() { return "abstraction"; }

	public Vector getChildren() {
		Vector v1 = super.getChildren();
		jkk.Lib.joinVectors(v1,bindings);
		return v1;
	}

	/* type inference tool */

	protected Set removeBoundVars(Set v) {
        VarVal vv;
        Set clonev = (Set)v.clone();
        for(Enumeration e=v.elements();e.hasMoreElements();) {
	    	vv = (VarVal)e.nextElement(); 
	    	if(vv.binding.abstraction().equals(this)) 
	    		clonev.remove(vv); 
	    }
	 	return clonev; 
	 }

	 public Syntax copy(Hashtable already, boolean interpCopy) {
		Value tmp;

		/* syntax init */
		
		tmp = (Value)Syntax.syntaxCopy(this,already);
		
		/* copy bindings */

		AbsVal aTmp = (AbsVal)tmp;
		aTmp.bindings = new Vector();
		for(int i=0;i < bindings.size();i++)
			aTmp.bindings.addElement(
				((Binding)bindings.elementAt(i)).copy(already,interpCopy));

		/* value init */

		tmp.args = copyArgs(tmp,already,interpCopy);
		
		tmp.parent = copyParent(already);
		tmp.layoutInfo.updateFrom(layoutInfo);
		return tmp;
	}

	public Syntax shallowCopy() {
		AbsVal tmp = (AbsVal)super.shallowCopy();
		tmp.bindings = new Vector();
		for(int i=0;i < bindings.size();i++) {
			tmp.bindings.addElement(bindings.elementAt(i));		
		}
		return tmp;
	}

	/* tools ----------------------------------------------------- */

	public Binding binding(int n) { 
		return (Binding)bindings.elementAt(n); 
	}

	public Vector allBindings() {
		Vector v = new Vector();
		for(int i=0;i < bindings.size();i++)
			jkk.Lib.joinVectors(v,binding(i).getAllBindings());
		return v;
	}

	public void addBinding(Binding b) {
		bindings.addElement(b);
		b.parent = this;
	}

	public void removeBinding(int i) {
		Binding b = binding(i);
		bindings.removeElementAt(i);
		b.parent = null;
	}

	public void replaceBindingChild(Binding b, Binding newB) {
		int n = bindings.indexOf(b);
		bindings.setElementAt(newB,n);
	}

	public Vector findAllVars(Binding b) {
		return findAllVars(b,false);
	}
	
	public Vector findAllVars(Binding b, boolean exact) {
		Vector bs = null;
		if(exact) {
			bs = new Vector(); bs.addElement(b);
		} else
			bs = b.getAllBindings();
		FindVarFunctor fvf = new FindVarFunctor(bs);
		traverseSyntaxTree(fvf);
		return fvf.getVars();
	}

	class FindVarFunctor extends Functor {
		private Vector targets;
		private Vector vars;
		
		FindVarFunctor(Vector bs) {
			vars = new Vector(); targets = bs;
		}

		public Object eval(Object x) {
			if(x instanceof VarVal) {
				VarVal v = (VarVal)x;
				if(targets.contains(v.binding))
					vars.addElement(v);
			}
			return null;
		}

		Vector getVars() { return vars; }
	}

}

