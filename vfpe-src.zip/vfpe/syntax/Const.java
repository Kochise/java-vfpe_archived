/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997-1998
*/

/* Names bound outside expression and data functions */

package vfpe.syntax;

import java.util.Hashtable;
import java.util.Vector;

import jkk.Set;
import vfpe.ListParser;
import vfpe.CodeGenException;
import vfpe.Reducer;
import vfpe.syntax.ConstBind;
import vfpe.syntax.VarVal;
import vfpe.type.Type;
import vfpe.type.TypeException;
import vfpe.type.TypeInferenceState;

public class Const extends VarVal {
    public static final long serialVersionUID = 1;

    public Const() { super(); }
    public Const(ConstBind b) { super(b); }
    
    /* type inference */

    public Set inferType(TypeInferenceState itypes) throws TypeException {
        ConstBind cb = (ConstBind)binding;

        /*     we don't keep the type of constants in the assumption
            set.  They just consume type variable names and slow
            down the assumption set substitutions 

            they are correctly specialised by parsing their types
            from a string description in which all types are assumed
            to be quantified
            
            or do we have to do the non-generics thing here as well ?
        */

        itypes.setType(this,Type.parseType(cb.tstr));

        /*    we don't bother including this in the vars set */

        return new Set();
    }

    /* tools */

    public String syntaxName() { return "constant"; }

    /* evaluation ------------------------------------------------ */

    public Value reduce(Reducer r) {
        ConstBind cb = (ConstBind)binding;
        if(cb.primValue != null) {
            Value nv = (Value)cb.primValue.copy(true);
            r.step(Reducer.PRIM_UNFOLD,cb.group+"/"+cb.name,nv,this);
            if(binding.breakpoint) {
                r.message = "Stopping at breakpoint for " + name();
                r.breakHalt = true;
            }
            return nv;
        } else {
            return null;
        }
    }

    public boolean isWHNF(Reducer r) {
        ConstBind cb = (ConstBind)binding;
        return cb.primValue == null;
    }
}
