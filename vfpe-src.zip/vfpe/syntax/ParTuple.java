/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1998-2001
*/

/* special parallel pair value */

package vfpe.syntax;

import jkk.Set;
import vfpe.EvaluationException;
import vfpe.Reducer;
import vfpe.editor.ParTupleLayout;
import vfpe.editor.SyntaxLayout;
import vfpe.type.Substitution;
import vfpe.type.Type;
import vfpe.type.TypeException;
import vfpe.type.TypeInferenceState;

public class ParTuple extends Value {
  public static final long serialVersionUID = 1;

  public ParTuple() {
    super(); addBody(null);
  }
  public ParTuple(int n) {
    super(); addBody(null);
    for(int i=0;i < n;i++)
      addArg(new BtmVal());
  }

  /* overrides */

  public SyntaxLayout makeLayout() {
    return new ParTupleLayout(this);
  }

  public String syntaxName() { return "parallel tuple"; }

  public String writeExp() { return "partuple"; }

  /* tools */

  public Value decayToConstructor() {
    AppVal av = new AppVal();
    av.addBody(ConstAbs.makeConst("data/Tuple-"+arity()));
    for(int i=0;i < arity();i++)
      av.addArg(arg(i));
    return av;
  }

  /* type inference */

  public Set inferType(TypeInferenceState itypes)
    throws TypeException {

    /* infer type of children and set accordingly */

    Set tmp = new Set();
    Type rType = new Type(Type.TUPLE_PREFIX_TAG+arity(),arity());
    for(int i=0;i < arity();i++) {
      tmp.add(arg(i).inferType(itypes));
      rType.args[i] = itypes.getType(arg(i));
    }
    itypes.setType(this,rType);
    return tmp;
  }

  /* evaluation ------------------------------------------------ */

  public Value reduce(Reducer r) throws EvaluationException {
    int oldRCount = r.rCount;
    boolean allNormal = true;
    for(int i=0;i < arity();i++) {
      Value v = arg(i);
      Value nv = v.reduce(r);
      if(nv != null) {
        v.replace(nv); allNormal = false;
      }
    }
    r.rCount = oldRCount;
    if(!allNormal) {
// we could record degree of parallelism in the reducer
      r.step(Reducer.PARALLEL_STEP,null,null,null);
      return this;
    }
    Value retVal = decayToConstructor();
    r.step(Reducer.PARALLEL_DECAY,null,retVal,this);
    return retVal;
  }

  public boolean isWHNF(Reducer r) { return false; }

}
