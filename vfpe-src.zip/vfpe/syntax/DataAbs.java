/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1998
*/

/* Holder for user-defined datatype bindings */

package vfpe.syntax;

import java.util.Vector;

import vfpe.EvaluationException;
import vfpe.Reducer;
import vfpe.editor.DataLayout;
import vfpe.editor.SyntaxLayout;

public class DataAbs extends ConstAbs {
	public static final long serialVersionUID = 1;
	
	public String typeName;
	public Vector typeVarNames;
	public String typeString;
	
	public DataAbs() { super(); }
	public DataAbs(Value bd, String typeName, Vector typeVarNames) {
		super(bd);
		this.typeName = typeName;
		this.typeVarNames = typeVarNames;
		StringBuffer buf = new StringBuffer();
		buf.append('(');
		buf.append(typeName);
		for(int i=0;i < typeVarNames.size();i++) {
			buf.append(' ');
			buf.append((String)typeVarNames.elementAt(i));
		}
		buf.append(')');
		typeString = buf.toString();
	}

	/* override stuff */

	public SyntaxLayout makeLayout() { return new DataLayout(this); }

	public String syntaxName() { return "datatype abstraction"; }

	public String writeExp() {
		return ((Value)body()).writeExp();
	}

	/* evaluation ------------------------------------------------ */

	// inherits

}

