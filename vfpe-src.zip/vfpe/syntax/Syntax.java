/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997-2001
*/

package vfpe.syntax;

import java.io.Serializable;
import java.util.Hashtable;
import java.util.Vector;

import jkk.IntTable;
import vfpe.editor.SyntaxLayout;

public abstract class Syntax implements Serializable, Cloneable {
    public static final long serialVersionUID = 1;
    public SyntaxLayout layoutInfo;
    public String comment;
    
    /* constructor */

    public Syntax() { 
        layoutInfo = makeLayout();
    }

    public abstract SyntaxLayout makeLayout();

    public abstract String syntaxName();

    public abstract Syntax getParent();

    public abstract Vector getChildren();

    public Syntax copy(boolean interpCopy) { return copy(new Hashtable(),interpCopy); }

    public Syntax copy(Hashtable already, boolean interpCopy) {
        return syntaxCopy(this,already);
    }

    public static Syntax syntaxCopy(Syntax s, Hashtable already) {
        Syntax tmp = null;
        try {
            tmp = (Syntax)s.clone();
        } catch(CloneNotSupportedException cnse) {
            System.out.println("Universe out of alignment error.");
            System.exit(10);
        }
        tmp.layoutInfo = tmp.makeLayout();
        already.put(s,tmp);
        return tmp;
    }

    public Syntax shallowCopy() {
        Syntax tmp = null;
        try {
            tmp = (Syntax)this.clone();
        } catch(CloneNotSupportedException cnse) {
            System.out.println("Universe out of alignment error.");
            System.exit(10);
        }
        tmp.layoutInfo = tmp.makeLayout();
        return tmp;
    }

    /* this could carry 'round an indentation value */
    public abstract String writeExp();

    public Syntax findBindingBodyRoot() {
        Syntax v = this;
        while(v != null) {
            if(v.getParent() instanceof LetAbs)
                return v;
            v = (Syntax)v.getParent();
        }
        return v;
    }

    public void countNodes(IntTable nds) {
        nds.add(getClass().getName(),1);
        Vector cs = getChildren();
        for(int i=0;i < cs.size();i++) {
            Syntax c = (Syntax)cs.elementAt(i);
            if(c != null)
                c.countNodes(nds);
        }
    }

}
