/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997-1999
*/

package vfpe.syntax;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import jkk.Functor;
import jkk.Set;
import vfpe.CodeGenException;
import vfpe.EvaluationException;
import vfpe.Reducer;
import vfpe.editor.Editor;
import vfpe.editor.SyntaxLayout;
import vfpe.editor.Config;
import vfpe.syntax.AbsVal;
import vfpe.syntax.Const;
import vfpe.syntax.Syntax;
import vfpe.syntax.VarVal;
import vfpe.type.Substitution;
import vfpe.type.Type;
import vfpe.type.TypeException;
import vfpe.type.TypeInferenceState;

public abstract class Value extends Syntax {
    public static final long serialVersionUID = 1;

    /* fields ---------------------------------------------------- */

    public Vector args;
    public Syntax parent;

    /* constructors ---------------------------------------------- */

    public Value() { 
        super(); args = new Vector();
    }
    
    /* override stuff -------------------------------------------- */

    public String syntaxName() { return "value"; }

    public Syntax getParent() { return parent; }

    public Vector getChildren() { 
        return (Vector)args.clone();
    }

    public Syntax copy(Hashtable already, boolean interpCopy) {
        Value tmp;
        tmp = (Value)Syntax.syntaxCopy(this,already);
        tmp.args = copyArgs(tmp,already,interpCopy);
        tmp.parent = copyParent(already);
        tmp.layoutInfo.updateFrom(layoutInfo);
        return tmp;
    }

    public Syntax copyParent(Hashtable already) {
        if(parent != null && already.containsKey(parent))
            return (Syntax)already.get(parent);
        else {
            return null;
        }
    }

    public Vector copyArgs(Value p, Hashtable already, boolean interpCopy) {
        Vector tmp = new Vector();
        for(int i=0;i < args.size();i++) {
            if(args.elementAt(i) == null) {
                tmp.addElement(null);
            } else {
                Value argCi = (Value)((Value)args.elementAt(i)).copy(already,interpCopy);
                argCi.parent = p;
                tmp.addElement(argCi);
            }
        }
        return tmp;
    }

    public Syntax shallowCopy() {
        Value tmp = (Value)super.shallowCopy();
        tmp.args = new Vector();
        for(int i=0;i < args.size();i++) {
            tmp.args.addElement(args.elementAt(i));        
        }
        return tmp;
    }
    
    public boolean emptyBodyDroppable() { return false; }
    
    /* tools ----------------------------------------------------- */

    public int arity() { return args.size()-1; }
    public Value arg(int n) { return (Value)args.elementAt(n+1); }
    public void setArg(Value s, int n) {
        if(arg(n) != null)
            arg(n).parent = null;
        args.setElementAt(s,n+1);
        if(s != null) s.parent = this;
    }
    public void addArg(Value s) {
        args.addElement(s);
        if(s != null) s.parent = this;
    }
    public void addArgAt(Value s, int pos) {
        args.insertElementAt(s,pos+1);
        if(s != null) s.parent = this;
        
    }
    public void deleteArg(int n) {
        if(arg(n) != null)
            arg(n).parent = null;
        args.removeElementAt(n+1);
    }
    public Value body() { return (Value)args.elementAt(0); }
    public void addBody(Value s) { addArg(s); }
    public void setBody(Value s) { setArg(s,-1); }

    public int whatNumberIsChild(Value c) {
      for(int i=0;i < arity();i++) {
        if(arg(i).equals(c))
          return i;
      }
      return -1;
    }

    public void setParent(Syntax s) { parent = s; }

    public void replace(Value v) {
        if(v == this) return;
        if(parent instanceof PatBind) {
            PatBind pb = (PatBind)parent;
            pb.dataCon = (VarVal)v;    v.parent = pb;
        } else {
            Value p = (Value)parent;
            if(p != null) p.replaceChild(this,v);
            v.parent = p;
        }
        parent = null;
    }

    public void removeAllVars(Vector vars) {
        if(vars != null)
            for(int i=0;i < vars.size();i++) {
                VarVal v = (VarVal)vars.elementAt(i);
                v.replace(new BtmVal());
            }
    }

    public void replaceChild(Syntax oldChild, Syntax newChild) {
        for(int i=0;i < args.size();i++)
            if(oldChild.equals(args.elementAt(i))) {
                args.setElementAt(newChild,i);
            }
    }

    public boolean isDescendantOf(Value a) {
        Value tmp = this;
        while(tmp != null) {
            if(tmp == a)
            /* this will fail for the VarVal child of a PatBind */
                return true;
            tmp = (Value)tmp.getParent();
        }
        return false;
    }

    public Object traverseSyntaxTree(Functor f) {
        /* preorder */
        Object r = null;
        if((r = f.eval(this)) != null) return r;
        for(int i=0;i < args.size();i++) {
            Value tmp = (Value)args.elementAt(i);
            if(tmp != null) {
                r = tmp.traverseSyntaxTree(f);
                if(r != null) return r;
            }
        }
        return null;
    }

    public Object postorderTraversal(Functor f) {
        /* postorder */
        Object r = null;
        for(int i=0;i < args.size();i++) {
            Value tmp = (Value)args.elementAt(i);
            if(tmp != null) {
                r = tmp.postorderTraversal(f);
                if(r != null) return r;
            }
        }
        if((r = f.eval(this)) != null) return r;
        return null;
    }

    public void findActiveThreads(Vector v) {
        for(int i=0;i < args.size();i++) {
            Value child = ((Value)args.elementAt(i));
            if(child != null)
                child.findActiveThreads(v);
        }
    }

    public Vector findFreeVars() {
        FindFVFunctor fcf = new FindFVFunctor();
        traverseSyntaxTree(fcf);
        return fcf.getVars();
    }

    /* NOTE: this always counts consts as fvs */
    /* REQUIRES PREORDER TRAVERSAL */
    class FindFVFunctor extends Functor {
        private Vector vars;
        private Hashtable bindings;
        
        FindFVFunctor() {
            vars = new Vector();
            bindings = new Hashtable();
        }

        public Object eval(Object x) {
            if(x instanceof AbsVal) {
                AbsVal absv = (AbsVal)x;
                for(int i=0;i < absv.bindings.size();i++) {
                    Binding b = (Binding)absv.bindings.elementAt(i);
                    Vector bv = b.getAllBindings();
                    for(int j=0;j < bv.size();j++) {
                        bindings.put(bv.elementAt(j),bv.elementAt(j));
                        if(bv.elementAt(j) instanceof PatBind) {
                            VarVal vv = ((PatBind)bv.elementAt(j)).dataCon;
                            if(!bindings.containsKey(vv.binding))
                                vars.addElement(vv);
                        }
                    }
                }
            } else if(x instanceof VarVal) {
                VarVal vv = (VarVal)x;
                if(!bindings.containsKey(vv.binding))
                    vars.addElement(vv);
            }
            return null;
        }

        Vector getVars() { return vars; }
    }

    public Vector findNodes(String targetClass) {
        FindNodeFunctor fcf = new FindNodeFunctor(targetClass);
        traverseSyntaxTree(fcf);
        return fcf.getVars();
    }

    class FindNodeFunctor extends Functor {
        private Vector vars;
        Class target;
        
        FindNodeFunctor(String targetClass) {
            vars = new Vector();
            try {
                target = Class.forName(targetClass);
            } catch(ClassNotFoundException cnfe) { }
        }

        public Object eval(Object x) {
            if(target.isInstance(x)) vars.addElement(x);

            if(x instanceof AbsVal) {
                AbsVal absv = (AbsVal)x;
                Vector v = new Vector();
                for(int i=0;i < absv.bindings.size();i++) {
                    Binding b = (Binding)absv.bindings.elementAt(i);
                    Vector bv = b.getAllBindings();
                    jkk.Lib.joinVectors(v,bv);
                }
                for(int i=0;i < v.size();i++) {
                    Binding b = (Binding)v.elementAt(i);
                    eval(b);
                    if(b instanceof PatBind) {
                        eval(((PatBind)b).dataCon);
                    }
                }
            }
            return null;
        }

        Vector getVars() { return vars; }
    }

    public Set directDependencies(AbsVal abs) {
        DependFunctor df = new DependFunctor(abs);
        traverseSyntaxTree(df);
        return df.getBinds();
    }

    class DependFunctor extends Functor {
        private Set binds;
        AbsVal abs;

        DependFunctor(AbsVal abs) {
            binds = new Set(); this.abs = abs;
        }

        public Object eval(Object x) {
            if(x instanceof VarVal) {
                VarVal vv = (VarVal)x;
                if(abs != null && vv.binding.abstraction() != abs)
                    return null;
                binds.put(vv.binding,vv.binding);
            }
            return null;
        }

        Set getBinds() { return binds; }
    }

    /* tool for putting expression into normal for WRT currying */

    public void uncurryAll() {
        postorderTraversal(new Functor() {
            public Object eval(Object x) {
                if(x instanceof AppVal)
                    ((AppVal)x).uncurry();
                else if(x instanceof LamAbs)
                    ((LamAbs)x).uncurry();
                return null;
            }
        });
    }

    /* type inference -------------------------------------------- */

    public Set inferType(TypeInferenceState itypes) 
        throws TypeException {
        return new Set();
    }

    public void narrowBindingType(TypeInferenceState itypes)
        throws TypeException {

        // find the let binding that the change site is part of
        Value bbr = (Value)findBindingBodyRoot();
        if(bbr == null)
            return;
        LetAbs labs = (LetAbs)bbr.getParent();
        int bn = labs.whatNumberIs(bbr);
        if(bn == -1) { // must be body not binding
            labs.narrowBindingType(itypes);
            return;
        }
        labs.narrowBinding(bbr, itypes);
    }
    
    // OPTIMISE: cache the non-generic TV set where possible
    public Set nonGenericTVs(TypeInferenceState itypes) {
        Set s = new Set();
        Value p = (Value)getParent();
        while(p != null) {
            if(p instanceof LamAbs) {
                LamAbs lam = (LamAbs)p;
                for(int i=0;i < lam.bindings.size();i++) {
                    Type t = itypes.getType(lam.binding(i));
                    if(t == null)
                        Editor.panic("lambda binding doesn't have type");
                    s.add(t.freeVars());
                }
            }
            p = (Value)p.getParent();
        }
        return s;
    }

    /* evaluation ------------------------------------------------ */

    public /* abstract */ Value reduce(Reducer r)
        throws EvaluationException {
        return null;
    }

    public /* abstract */ boolean isWHNF(Reducer r)  {
        return true;
    }

    public Value runReduction(Reducer r, boolean step)
        throws EvaluationException {
        r.prep();

        Value res;
        if(r.threadParallel)
            res = parallelReduction(r,step);
        else
            res = sequentialReduction(r,step);

        if(!step && Config.tidyAfterReduction) {
            LetAbs labs = new LetAbs();
            labs.addBody(res);
            labs.tidyValueTree();
            return labs.body();
        } else
            return res;
    }

    /*
        Note that this _seriously_ defuct 
    */
    protected Value parallelReduction(Reducer r, boolean step)
        throws EvaluationException {
        
        Value tmpVal = (Value)copy(false);
        boolean again = true;
        int rc = 0;
        
        while(again && rc < r.reductionLimit) {

            // find threads and locate active thread

            Vector threads = new Vector();
            tmpVal.findActiveThreads(threads);
            tmpVal.findActiveThreads(r.threadSet);
            
            if(threads.size() == 0) {
                again = false; continue;
            }
            
            Thread nextT = null;
            for(int i=0;i < threads.size();i++) {
                Thread t = (Thread)threads.elementAt(i);
                if(!t.haveExecuted) {
                    nextT = t; break;
                }
            }
            if(nextT == null) {
                for(int i=0;i < threads.size();i++) {
                    Thread t = (Thread)threads.elementAt(i);
                    t.haveExecuted = false;
                }
                r.cycles++;
                continue;
            }

            // step next thread

            Value tR = nextT.threadStep(r);
            rc++;
            if(tR == null) { // thread still running
                
            } else { // thread finished
                if(nextT.equals(tmpVal)) {
                    tmpVal = tR; again = false; continue;
                } else
                    nextT.replace(tR);
            }

            again = !step && !r.breakHalt;
        }

        return tmpVal;
    }

    protected Value sequentialReduction(Reducer r, boolean step)
        throws EvaluationException {
        
        Value res = null;
        Value tmpVal = (Value)copy(false);
        boolean again = true;
        int rc = 0;

        /*    if we separated the "step" and "eval" modes, we
            might be able to get away without returning the copy
            and thus doing a relayout in some cases */
        
        while(again && rc < r.reductionLimit) {
            r.prep();
            res = tmpVal.reduce(r);
            if(res == null) {
                res = tmpVal; again = false;
            } else {
                rc++;
                if(step) {
                    again = false;
                } else {
                   tmpVal = res; again = !r.breakHalt;
                }
            }
        }

        return res;
    }

    public Value getGroundValue() { return this; }

    public Thread threadParent() {
        Value v = this;
        while(v != null && !(v instanceof Thread))
            v = (Value)v.getParent();
        return (Thread)v;
    }

    /* stuff for putting tree in readable form after reduction */

    public void tidyValueTree() {
        postorderTraversal(tidyValueFunctor);
    }
    
    public void tidy() { }
    
    private static Functor tidyValueFunctor = new Functor() {
        public Object eval(Object x) {
            ((Value)x).tidy(); return null;
        }
    };

}
