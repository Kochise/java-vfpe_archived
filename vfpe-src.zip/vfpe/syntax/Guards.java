/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1998
*/

/* special syntax for guarded expressions */

package vfpe.syntax;

import jkk.Set;
import vfpe.EvaluationException;
import vfpe.Reducer;
import vfpe.editor.GuardLayout;
import vfpe.editor.SyntaxLayout;
import vfpe.type.Substitution;
import vfpe.type.Type;
import vfpe.type.TypeException;
import vfpe.type.TypeInferenceState;

public class Guards extends Value {
	public static final long serialVersionUID = 1;

	public Guards() {
		super(); addBody(null);
		addArg(new BtmVal());
		addArg(new BtmVal());
	}

	public SyntaxLayout makeLayout() {
		return new GuardLayout(this);
	}

	public String syntaxName() { return "guards"; }

	public String writeExp() { return "guards"; }

	public Set inferType(TypeInferenceState itypes)
		throws TypeException {

		Set tmp = new Set();
		Type boolType = new Type("Bool",0);

		/* infer types and unify as we go */

		tmp.add(arg(0).inferType(itypes));
		Substitution subs = Type.unify(itypes.getType(arg(0)), boolType);
		itypes.substitute(subs);
		tmp.add(arg(1).inferType(itypes));

		subs = new Substitution();
		for(int i=2;i < arity();i+=2) {
			tmp.add(arg(i).inferType(itypes));
			subs.apply(Type.unify(itypes.getType(arg(i)), boolType));
			tmp.add(arg(i+1).inferType(itypes));
			/* is this any more efficient ? */
			subs.apply(Type.unify(
				itypes.getType(arg(i+1)),
				itypes.getType(arg(1))));
		}
		itypes.substitute(subs);
		itypes.setType(this,itypes.getType(arg(1)));
		
		return tmp;
	}

	/* evaluation ------------------------------------------------ */

	public Value reduce(Reducer r) throws EvaluationException {
		Value cond = arg(0).reduce(r);
		if(cond != null) {
			setArg(cond,0); return this;
		}
		Const boolConst = (Const)arg(0).getGroundValue();
		Value rVal;
		if(boolConst.name().equals("True")) 
			rVal = arg(1);
		else {
			if(arity() == 2)
				throw new EvaluationException("guard set fall-through");
			deleteArg(0); deleteArg(0);
			rVal = this;
		}
		return rVal;
	}

	public boolean isWHNF(Reducer r) { return false; }

}
