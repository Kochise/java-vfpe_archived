/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997-1998
*/

/* Holder for constant bindings */

package vfpe.syntax;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.StringTokenizer;
import java.util.Vector;

import vfpe.ListParser;

import jkk.OrderedTable;
import jkk.Set;
import jkk.io.Lib;
import vfpe.BadPreludeException;
import vfpe.CodeGenException;
import vfpe.EvaluationException;
import vfpe.PrimEvaluator;
import vfpe.Reducer;
import vfpe.editor.Config;
import vfpe.editor.ConstAbsLayout;
import vfpe.editor.Editor;
import vfpe.editor.SyntaxLayout;
import vfpe.syntax.BtmVal;
import vfpe.type.Type;
import vfpe.type.TypeException;
import vfpe.type.TypeInferenceState;

public class ConstAbs extends AbsVal {
	public static final long serialVersionUID = 1;
	private static final String PRELUDE_CONST_TAG = "prim";
	private static final String PRELUDE_DATA_TAG = "data";
	private static final String PRELUDE_COMMENT_TAG = "#";
	
	public Hashtable defs = new OrderedTable();

	public ConstAbs() { super(); }
	public ConstAbs(Value bd) { super(bd); }
	public ConstAbs(String prelude) {
		super(new BtmVal());
		
		/* parse a prelude from a string description */
		/* is this the best place to parse the prelude ? */

		ListParser toks = new ListParser(prelude);
		while(toks.more()) {
			String tag = toks.next();
			if(tag.equals(PRELUDE_CONST_TAG) ||
			   tag.equals(PRELUDE_DATA_TAG)) {
				String name = toks.next();
				String tstr = toks.next();
				String group = toks.next();
				String val = toks.next();
				ConstBind cb = new ConstBind(this,name,tstr,group,val);
				defs.put(group+"/"+name,cb);
				if(tag.equals(PRELUDE_DATA_TAG)) {
					cb.isData = true;
					cb.varNames = toks.next();
				}
			} else if(tag.equals(PRELUDE_COMMENT_TAG)) {
				toks.next();
			} else
				Editor.panic("Badly formed prelude");
		}

		/* load value expression or evaluator object */

		Enumeration e = defs.elements();
		String primValueDir = Config.getProp("prelude.prim.val.dir");
		String primEvalPkg = Config.getProp("prelude.evaluator.package");
		Hashtable evals = new Hashtable();
		while(e.hasMoreElements()) {
			ConstBind cb = (ConstBind)e.nextElement();
			if(cb.val.endsWith(".sfe")) {
				byte [] b = Lib.resourceToByteArray(primValueDir+cb.val);
				Value v = (Value)Lib.byteArrayToObject(b);
				try {
					v = knitWithPrelude(v);
				} catch(BadPreludeException bpe) {
					Editor.panic(bpe.getMessage());
				}
				cb.primValue = v;
			} else {
				String peName = primEvalPkg+"."+cb.val;
				if(!evals.containsKey(peName))
					evals.put(peName,jkk.Lib.makeObject(peName));
				cb.primEval = (PrimEvaluator)evals.get(peName);
			}
		}
	}

	/* type inference */

	public Set inferType(TypeInferenceState itypes) throws TypeException {
		Set v = ((Value)body()).inferType(itypes);
		itypes.setType(this,itypes.getType((Value)body()));
		return removeBoundVars(v);
	}

	/* overrides ------------------------------------------------ */

	public SyntaxLayout makeLayout() { return new ConstAbsLayout(this); }

	public String syntaxName() { return "constant abstraction"; }

	public Syntax copy(Hashtable already, boolean interpCopy) {
		/*	we duplicate the defs just in case we want to allow editing
			of ConstAbs and ConstBinds */
		ConstAbs tmp = (ConstAbs)super.copy(already,interpCopy);
		tmp.defs = new Hashtable();
		Enumeration e = defs.keys();
		while(e.hasMoreElements()) {
			String key = (String)e.nextElement();
			ConstBind cb = (ConstBind)defs.get(key);
			tmp.defs.put(key,cb.copy(already,interpCopy));
		}
		return tmp;
	}

	public boolean emptyBodyDroppable() { return true; }

	/* tools */

	/* 	try to match constants appearing in newly loaded expressions
		with constants in prelude.  Returns the knitted expression (which
		may be different if the root is a free var), or throws a
		BadPreludeException on failure (in which case the expression
		passed in may be mangled).
	*/
	public Value knitWithPrelude(Value v) throws BadPreludeException {
		Vector cs = v.findNodes("vfpe.syntax.FreeVar");
		Enumeration e = cs.elements();
		Value rootVal = v;
		while(e.hasMoreElements()) {

			/* find const with matching name in prelude */

			FreeVar fv = (FreeVar)e.nextElement();
			String matchName = fv.name;
			ConstBind matchBinding = (ConstBind)defs.get(matchName);
			if(matchBinding == null)
				throw new BadPreludeException(
					"couldn't find constant match for "+matchName);

			/* compare types */

			Type importType = Type.parseType(fv.tstr);
			Type matchType = Type.parseType(matchBinding.tstr);
			if(!importType.isIsomorphicTo(matchType))
				throw new BadPreludeException(
					"types for "+matchName+" don't match");

			/* point imported binding to prelude binding */

			Const newVal = new Const(matchBinding);
			if(fv == v)
				rootVal = newVal;
			else
				fv.replace(newVal);
		}
		
		return rootVal;
	}

	public String writeExp() {
		return ((Value)body()).writeExp();
		/* could do some sort of listing of prims */
	}

	/* evaluation ------------------------------------------------ */

	public Value reduce(Reducer r) throws EvaluationException {
		Value v = body().reduce(r);
		if(v == null) return null;
		setBody(v); return this;
	}

	public Value getGroundValue() { return body().getGroundValue(); }

	public boolean isWHNF(Reducer r) { return body().isWHNF(r); }
	
	/* used by other evaluators */

	public static Const makeConst(String cName) {
		ConstAbs prelude = Editor.prelude;
		ConstBind cb = (ConstBind)prelude.defs.get(cName);
		return (Const)cb.makeVar();
	}

}

/*
class ConstRequester extends Dialog {
	public TextField name,type,group,hask;
	private Button OK;

	public ConstRequester() {
		super(Lib.master, true); setTitle("New constant info");
		setLayout(new GridBagLayout());
		Lib.constrain(this,new Label("Name:"),0,0,1,1);
		Lib.constrain(this,new Label("Type:"),0,1,1,1);
		Lib.constrain(this,new Label("Menu Group:"),0,2,1,1);
		Lib.constrain(this,new Label("Haskell Translation:"),0,3,1,1);
		Lib.constrain(this,name = new TextField(20),1,0,1,1);
		Lib.constrain(this,type = new TextField(20),1,1,1,1);
		Lib.constrain(this,group = new TextField(20),1,2,1,1);
		Lib.constrain(this,hask = new TextField(20),1,3,1,1);
		Lib.constrain(this,new Button("OK"),0,5,2,1);
		pack();
	}

	public boolean action(Event evnt, Object arg) {
		if(evnt.target instanceof Button) {
			hide();dispose();
		}
		return true;
	}
}
*/

//##// this bites
