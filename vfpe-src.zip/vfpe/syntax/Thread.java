/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997-1999
*/

/* Thread values are part of the explicit thread parallel experiment. */

package vfpe.syntax;

import java.util.Hashtable;
import java.util.Vector;

import jkk.Counter;
import jkk.Set;
import vfpe.CodeGenException;
import vfpe.EvaluationException;
import vfpe.Reducer;
import vfpe.editor.Editor;
import vfpe.editor.SyntaxLayout;
import vfpe.editor.ThreadLayout;
import vfpe.CommWait;
import vfpe.ThreadReturnWait;
import vfpe.type.Type;
import vfpe.type.TypeException;
import vfpe.type.TypeInferenceState;

public class Thread extends Value {
	public static final long serialVersionUID = 1;

	/* constants ------------------------------------------------- */

	public static final int PROTOTYPE = 0;
	public static final int READY = 1;
	public static final int DEPEND_WAIT = 2;
	public static final int COMM_WAIT = 3;
	public static final int DONE = 4;
	public static final String [] statusNames = {
		"prototype", "running", "waiting on dependancy",
		"waiting for communication", "done"
	};
	
	/* fields ---------------------------------------------------- */
	
	public String name;
	public int number;
	private Counter counter;

	public boolean haveExecuted;
	public int status;
	public int workCycles;
	public int waitCycles;
	public int commCycles;
	public int delay;

	public Thread() { super(); }

	public Thread(String name) {
		this();
		this.name = name;
		counter = new Counter();
		number = counter.nextInt();
	}

	/* tools */

	public String nodeName() { return name+"-"+number; }

	/* overrides */

	public String syntaxName() { return "thread root"; }

	public SyntaxLayout makeLayout() {
		return new ThreadLayout(this);
	}

	public boolean emptyBodyDroppable() { return true; }

	public void findActiveThreads(Vector v) {
		super.findActiveThreads(v);
		for(int i=0;i < v.size();i++) {
			Thread t = (Thread)v.elementAt(i);
			if(t.name.equals(name)) {	
				v.setElementAt(this,i);
				return;
			}
		}
		v.addElement(this);
	}
	
	/* this could be nicer */
	public String writeExp() {
		return "(THREAD " + body().writeExp() + ")";
	}

	/* type inference */

	public Set inferType(TypeInferenceState itypes) throws TypeException {
		Set v = ((Value)body()).inferType(itypes);
		itypes.setType(this,itypes.getType((Value)body()));
		return v;
	}

	/* evaluation ------------------------------------------------ */

	/* called from parallel interpreter */

	/* return null if not ready, value if done */
	public Value threadStep(Reducer r) throws EvaluationException {
		haveExecuted = true;
		r.currentThread = this;
		if(status == COMM_WAIT) {
			commCycles++; delay--;
			if(delay <= 0)
				status = READY;
			return null;
		}

		Value rv = null;
		try {
			r.spine = new Vector();
			rv = body().reduce(r);
			if(rv == null) {
				status = DONE;
				return body();
			}
			body().replace(rv);
			workCycles++; status = READY;
		} catch(ThreadReturnWait trw) {
			waitCycles++; status = DEPEND_WAIT;
		} catch(CommWait cw) {
			status = COMM_WAIT;
			delay = cw.delay;
		}

		return null;
	}
	
	public Value reduce(Reducer r) throws EvaluationException {
		throw new ThreadReturnWait();
	}

	public Value getGroundValue() { return body().getGroundValue(); }

	public boolean isWHNF(Reducer r) { return false; }
}
