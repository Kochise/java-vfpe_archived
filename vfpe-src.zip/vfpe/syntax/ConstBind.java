/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997-1998
*/

/* Constant bindings - data bindings too */

package vfpe.syntax;

import vfpe.ListParser;
import vfpe.PrimEvaluator;
import vfpe.syntax.Binding;
import vfpe.syntax.Const;
import vfpe.syntax.VarVal;
import vfpe.type.Type;

public class ConstBind extends Binding {
	public static final long serialVersionUID = 1;
	public String tstr, group, val;
	public boolean isData;
	public Value primValue;
	public PrimEvaluator primEval;
	public String varNames;
	
	public ConstBind() { super(); }
	public ConstBind(
		ConstAbs parent, String nm, String nt, String gp, String v) {
		super(parent,nm); tstr = nt; group = gp; val = v;

		isData = false;
	}

	/* tools */

	public int arity() {
		Type type = Type.parseType(tstr);
		return type.funArity();
	}
	
	/* overrides */

	public String getLongName() { return group+"/"+name; }

	public String syntaxName() { return "constant binding"; }
	
	public VarVal makeVar() {
		return new Const(this);
	}

}
