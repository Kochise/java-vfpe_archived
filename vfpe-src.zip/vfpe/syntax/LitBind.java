/*
    * * * * * software from the house of J Kyle Kelso
    * **  ** 
  *** * * * * copyright 1997-1998
*/

/* simple literal pattern */

package vfpe.syntax;

import java.util.Vector;

import vfpe.EvaluationException;
import vfpe.PatternMatchFailure;
import vfpe.Reducer;
import vfpe.editor.LitBindLayout;
import vfpe.editor.SyntaxLayout;
import vfpe.type.Type;
import vfpe.type.TypeInferenceState;
import vfpe.type.TypeVar;

public class LitBind extends Binding {
	public static final long serialVersionUID = 1;

	public Literal literal;

	public LitBind() { super(); }
	public LitBind(Literal literal) {
		super();
		if(literal.value instanceof String)
			throw new IllegalArgumentException("can't make string literal patterns");
		this.literal = literal;
	}

	public String syntaxName() { return "literal pattern"; }

	public SyntaxLayout makeLayout() { return new LitBindLayout(this); }
	
	/* tools */

	public void inferBindingType(TypeInferenceState itypes) {
		itypes.setType(this,Type.parseType(literal.tstr));
	}

	public VarVal makeVar() { return null; }

	/* evaluation ------------------------------------------------ */

	public Value match(Value v, Reducer r)
		throws EvaluationException {

		/* put value in WHNF */
		
		Value rv = v.reduce(r);
		if(rv != null) return rv;
		v = v.getGroundValue();

		/* find literal and match */

		Literal litVal = (Literal)v;
		boolean matchOK = litVal.value.equals(literal.value);
		if(matchOK)
			return null;
		else
			throw new PatternMatchFailure("match failure between " +
				litVal.str + " and " + literal.str);
	}

}

