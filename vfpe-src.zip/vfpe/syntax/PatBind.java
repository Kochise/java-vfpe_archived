/*
    * * * * * software from the house of J Kyle Kelso
    * **  ** 
  *** * * * * copyright 1998
*/

/* data constructor pattern */

package vfpe.syntax;

import java.util.Hashtable;
import java.util.Vector;

import vfpe.EvaluationException;
import vfpe.PatternMatchFailure;
import vfpe.Reducer;
import vfpe.editor.PatBindLayout;
import vfpe.editor.SyntaxLayout;
import vfpe.type.Substitution;
import vfpe.type.Type;
import vfpe.type.TypeException;
import vfpe.type.TypeInferenceState;
import vfpe.type.TypeVar;

public class PatBind extends Binding {
	public static final long serialVersionUID = 1;
	
	public VarVal dataCon;
	public Vector bindings;
	
	public PatBind() { super(); }
	public PatBind(Syntax parent) {
		super(parent,"");
		bindings = new Vector();
	}
	public PatBind(
		Syntax parent, ConstBind dCon, Vector vNames) {
		super(parent,"");
		bindings = new Vector();
		dataCon = dCon.makeVar();
		dataCon.parent = this;
		for(int i=0;i < vNames.size();i++)
			bindings.addElement(new VarBind(this,(String)vNames.elementAt(i)));
	}

	/* override stuff */

	public Vector getChildren() {
		Vector v = (Vector)bindings.clone();
		v.addElement(dataCon);
		return v;
	}

	public String syntaxName() { return "constructor pattern"; }

	public VarVal makeVar() { return new VarVal(this); }
	
	public SyntaxLayout makeLayout() {
		return new PatBindLayout(this);
	}

	public Syntax copy(Hashtable already, boolean interpCopy) {
		PatBind tmp = (PatBind)super.copy(already,interpCopy);
		/* I hope this is right */
		tmp.dataCon = (VarVal)dataCon.copy(already,interpCopy);
		tmp.bindings = new Vector();
		for(int i=0;i < bindings.size();i++)
			tmp.bindings.addElement(
				((Binding)bindings.elementAt(i)).copy(already,interpCopy));
		return tmp;
	}

	public Syntax shallowCopy() {
		PatBind tmp = (PatBind)super.shallowCopy();
		tmp.bindings = new Vector();
		for(int i=0;i < bindings.size();i++) {
			tmp.bindings.addElement(bindings.elementAt(i));		
		}
		return tmp;
	}

	public String writeExp() {
		StringBuffer buf = new StringBuffer();
		buf.append('(');
		buf.append(dataCon.binding.name); 
		for(int i=0;i < bindings.size();i++) {
			buf.append(' ');
			Binding b = (Binding)bindings.elementAt(i);
			buf.append(b.writeExp());
		}
		buf.append(')'); return buf.toString();
	}

	public Vector getAllBindings(boolean includeTemps) {
		Vector v = super.getAllBindings(includeTemps);
		for(int i=0;i < bindings.size();i++) {
			jkk.Lib.joinVectors(v,
				((Binding)bindings.elementAt(i)).getAllBindings(includeTemps));
		}
		return v;
	}

	public void setTemporary(boolean tmp) {
		isTemporary = tmp;
		for(int i=0;i < bindings.size();i++) {
			Binding cb = binding(i);
			cb.setTemporary(tmp);
		}
	}
	
	/* tools */
	
	public Binding binding(int i) {
		return (Binding)bindings.elementAt(i);
	}

	public void replaceBindingChild(Binding b, Binding newB) {
		int n = bindings.indexOf(b);
		bindings.setElementAt(newB,n);
	}

	public boolean containsBinding(Binding b) {
		if(this.equals(b)) return true;
		for(int i=0;i < bindings.size();i++) {
			Binding cb = binding(i);
			if(cb.containsBinding(b)) return true;
		}
		return false;
	}

	/* type checking */

	public void inferBindingType(TypeInferenceState itypes)
		throws TypeException {

		/* like application */

		ConstBind dataConBind = (ConstBind)dataCon.binding;
		itypes.setType(this,Type.parseType(dataConBind.tstr));
		if(bindings.size() == 0)
			return;

		/* infer binding argument types */

		for(int i=0;i < bindings.size();i++)
			binding(i).inferBindingType(itypes);

		/* build types for args for unification */

		Type ft = new Type(Type.FUNC_TAG,2);
		ft.args[0] = itypes.getType(binding(0));
		Type at = ft;
		for(int i=1;i < bindings.size();i++) {
			at.args[1] = new Type(Type.FUNC_TAG,2);
			at = at.args[1];
			at.args[0] = itypes.getType(binding(i));
		}
		at.args[1] = new TypeVar();

		/* unify */
		
		Substitution subs = Type.unify(itypes.getType(this),ft);
		itypes.substitute(subs);
		Type t = itypes.getType(this);
		itypes.setType(this,t.funRetType(t.funArity()-1));
	}

	/* evaluation ------------------------------------------------ */

	public Value match(Value v, Reducer r)
		throws EvaluationException {

		/* put value in WHNF */
		
		Value rv = v.reduce(r);
		if(rv != null) return rv;
		v = v.getGroundValue();

		/* find constructor function bindings */

		Const rc = null;
		AppVal app = null;
		Value [] argv = null;
		int nArgs;
		if(v instanceof Const) {
			rc = (Const)v;
			nArgs = 0;
		} else {
			app = (AppVal)v;

			/* collect args */

			Vector argV = new Vector();
			rc = (Const)app.collectArgs(argV);			
			nArgs = argV.size();
			argv = new Value[nArgs];
			for(int i=0;i < nArgs;i++)
				argv[i] = (Value)argV.elementAt(i);
		}
		ConstBind rcb = (ConstBind)rc.binding;
		Const pc = (Const)dataCon;
		ConstBind pcb = (ConstBind)pc.binding;

		/* if they don't match, fail */
		
		if(!rcb.equals(pcb))
			throw new PatternMatchFailure("match failure between " +
				rcb.name + " and " + pcb.name);

		/* otherwise, match children */

		for(int i=0; i < bindings.size();i++) {
			Binding mb = binding(i);
			Value mrv = mb.match(argv[i],r);
			if(mrv != null) {
				argv[i].replace(mrv); return app;
			}
		}

		return null;
	}

}
