/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1998
*/

/* set of pattern bindings */

package vfpe.syntax;

import java.util.Vector;

import jkk.Set;
import vfpe.editor.PatLayout;
import vfpe.editor.SyntaxLayout;
import vfpe.type.Substitution;
import vfpe.type.Type;
import vfpe.type.TypeException;
import vfpe.type.TypeInferenceState;

public class Patterns extends Value {
	public static final long serialVersionUID = 1;

	public int nArgs;
	public Patterns() { super(); }
	public Patterns(int nArgs) {
		super(); addBody(null);
		this.nArgs = nArgs;
		addArg(new LamAbs(nArgs));
	}

	public Patterns(int nArgs, Vector vNames) {
		super(); addBody(null);
		this.nArgs = nArgs;
		addArg(new LamAbs(nArgs,vNames));
	}

	public SyntaxLayout makeLayout() {
		return new PatLayout(this);
	}

	public String syntaxName() { return "pattern set"; }

	public String writeExp() { return "patterns"; }

	public Set inferType(TypeInferenceState itypes)
		throws TypeException {

		/* infer type and unify as we go */

		Set tmp = arg(0).inferType(itypes);

		for(int i=1;i < arity();i++) {
			tmp.add(arg(i).inferType(itypes));
			Substitution subs = Type.unify(
				itypes.getType(arg(0)), itypes.getType(arg(i)));
			itypes.substitute(subs);
		}
		itypes.setType(this,itypes.getType(arg(0)));
		return tmp;
	}

	/* tools */

	public LamAbs pattern(int i) { return (LamAbs)arg(i); }
	
	public void addNewPattern() {
		addArg(new LamAbs(nArgs));
	}
	
}
