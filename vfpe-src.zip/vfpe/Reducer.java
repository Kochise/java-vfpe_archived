/*
    * * * * * software from the house of J Kyle Kelso
    * **  ** 
  *** * * * * copyright 1998
*/

/* object representing parameters for a reduction sequence */

package vfpe;

import java.io.Serializable;
import java.util.Hashtable;
import java.util.Vector;

import vfpe.syntax.Syntax;
import vfpe.syntax.Thread;
import vfpe.syntax.Value;

public class Reducer implements Serializable {
  public static final long serialVersionUID = 1;
    
  /* constants ------------------------------------------------- */

  /* reduction order and call type */
  public static final int NOR = 0;
  public static final int AOR = 1;
  public static final int CALL_BY_VALUE = 2;
  public static final int CALL_BY_NEED = 3;

  /* reduction step types */

  public static final int N_STEP_TYPES = 21;
   
  public static final int PRIM_EVAL = 0;
  public static final int PRIM_UNFOLD = 1;
  public static final int BINDING_UNFOLD = 2;
  public static final int BETA_REDUCE = 3;
  public static final int CURRY_APP = 4;
  public static final int UNCURRY_LAMBDA = 5;
  public static final int CHOOSE_CONSEQUENT = 6;
  public static final int CHOOSE_ALTERNATIVE = 7;
  public static final int CYCLIC_REDUCTION = 8;
  public static final int TO_CONS_FORM = 9;
  public static final int STRING_TO_CONS_FORM = 10;
  public static final int PROMOTE_BINDING = 11;
  public static final int PROMOTE_LET = 12;
  public static final int REMOVE_EMPTY_LET = 13;
  public static final int PATTERN_MATCH = 14;
  public static final int PATTERN_MISMATCH = 15;
  public static final int DEBUG_REDUCTION = 16;
  public static final int ENVIRONMENT_FETCH = 17;
  public static final int REMOTE_UNFOLD = 18;
  public static final int PARALLEL_STEP = 19;
  public static final int PARALLEL_DECAY = 20;

  public static final String [] messages = {
    "applied primitive", "unfolded primitive", "unfolded function",
    "beta reduction", "curried application", "uncurried lambda",
    "chose consequent", "chose alternative", "cyclic reduction",
    "list to cons form", "string to list form", "promoted bindings",
    "promoted let", "removed empty let", "pattern matched",
    "pattern mismatch", "debug reduction", "environment fetch",
    "remote unfold", "parallel reduction", "parallel reduction " +
    "finished"
  };

  public static final boolean [] isAdmin = {
    false, false, false,
    false, true, true,
    false, false, false,
    true, true, true,
    true, true, false,
    false, true, true,
    false, false, true
  };
    
  /* fields ---------------------------------------------------- */

  /* cycle detection thing */

  transient public Vector spine;
    
  /* reduction semantics */
   
  public int reductionOrder;
  public int callType;
  public boolean threadParallel;
  public boolean strictConstructors;
  public boolean expandCycles;
  public int reductionLimit;

  /* stuff for keeping reduction statistics here */

  public int rCount;
  public transient String message;
  public boolean breakHalt;
  public int [] stats = new int[N_STEP_TYPES];
  public Hashtable unfolds = new Hashtable();

  /* stuff of concurrent reduction */

  public int cycles;
// Thread parallel code
  public Thread currentThread;
  public Vector threadSet = new Vector();

  /* stuff for maintaining layout */

  transient public Vector mutationRoot;
  transient public Vector oldMutationRoot;
    
  /* constructor */

  public Reducer() { }

  public Object clone() {
    try {
      Reducer r = (Reducer)super.clone();
      r.spine = (Vector)spine.clone();
      // note that we don't clone the unfolds or stats tables
      return r;
    } catch(CloneNotSupportedException cnse) {
      return null;
    }
  }

  /* methods */

  public void step(int stepType, String name, Syntax mRoot, Syntax oRoot) {
    rCount++;
    stats[stepType]++;
    message = messages[stepType];
    if(name != null && !isAdmin[stepType]) {
      if(!unfolds.containsKey(name))
        unfolds.put(name,new int[1]);
      int [] n = (int [])unfolds.get(name);
      n[0]++;
    }
    breakHalt = false;
    if(mRoot != null) addMutationRoot(mRoot,oRoot);
  }
    
  public void prep() {
    message = "";
    spine = new Vector();
    mutationRoot = new Vector();
    oldMutationRoot = new Vector();
  }

  public void resetStats() {
    rCount = 0;
    for(int i=0;i < N_STEP_TYPES;i++)
      stats[i] = 0;
    unfolds = new Hashtable();
  }

  public void resetThreadStats() {
    cycles = 0; threadSet = new Vector();
  }

  /*
    Between prep() calls (ie during a reduction sequence)
    we maintain a set of mutation roots with the following
    properties:
      1) they're an anti-chain in the syntax tree partial order
      2) all mutation roots added during sequence are descendants
         of a member of the set
    This is supposed to ensure:
      1) we don't do more tree updating than we need to
      2) every change site gets updated
    I wonder if it'll work ?
  */
  public void addMutationRoot(Syntax v, Syntax o) {
    Value vv = (Value)v;
    for(int i=0;i < mutationRoot.size();i++) {
      Value m = (Value)mutationRoot.elementAt(i);
      if(vv.isDescendantOf(m)) return;
    }
    Vector removeUs = new Vector();
    Vector removeUsOld = new Vector();
    for(int i=0;i < mutationRoot.size();i++) {
      Value m = (Value)mutationRoot.elementAt(i);
      if(m.isDescendantOf(vv)) {
        removeUs.addElement(m);
        removeUsOld.addElement(oldMutationRoot.elementAt(i));
      }
    }
    for(int i=0;i < removeUs.size();i++)
      mutationRoot.remove(removeUs.elementAt(i));
    for(int i=0;i < removeUsOld.size();i++)
      oldMutationRoot.remove(removeUsOld.elementAt(i));
    mutationRoot.addElement(v);
    oldMutationRoot.addElement(o);
  }
}
