/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1998
*/

package vfpe;

public class ThreadReturnWait extends EvaluationException {
	public ThreadReturnWait() { }
	public ThreadReturnWait(String s) { super(s); }
}
