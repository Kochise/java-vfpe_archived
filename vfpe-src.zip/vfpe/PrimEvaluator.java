/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997-1998
*/

/* Interface for primitive evaluator code classes */

package vfpe;

import vfpe.EvaluationException;
import vfpe.Reducer;
import vfpe.syntax.AppVal;
import vfpe.syntax.ConstBind;
import vfpe.syntax.Value;

public interface PrimEvaluator {
	public int arity();
	public Value reduce(AppVal app, Value [] argv, ConstBind cb, Reducer r)
		throws EvaluationException;

}
