/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1998
*/

package vfpe;

import java.io.InputStream;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Vector;

import jkk.Counter;
import jkk.io.Lib;
import vfpe.ListParser;
import vfpe.editor.Editor;
import vfpe.editor.Config;
import vfpe.syntax.*;
import vfpe.type.Type;

/*	we choose to do this in a single class rather than spread it throughout
	the vfpe.syntax classes.  there are some hooks here so that later we
	might put in some fancy code output */
	
public class ToHaskell {
	private static final String VAR_PREFIX = "v";
	private static final int TABSIZE = 4;
	private static final String GUARD_FUNCTION_NAME = "vfpeGuards";

	private static final String PRELUDE_CONST_TAG = "prim";
	private static final String PRELUDE_DATA_TAG = "data";
	private static final String PRELUDE_COMMENT_TAG = "#";
	private static Hashtable translations;
	
	static {
		translations = new Hashtable();
		String s = null;
		try {
			InputStream is = ClassLoader.getSystemResourceAsStream(
				Config.getProp("haskell.translations"));
			s = Lib.byteArrayToString(Lib.slurpStream(is));
		} catch(IOException ioe) {
			Editor.panic("ToHaskell couldn't open translation file");
		}
		ListParser toks = new ListParser(s);
		while(toks.more()) {
			String tag = toks.next();
			if(tag.equals(PRELUDE_CONST_TAG) ||
			   tag.equals(PRELUDE_DATA_TAG)) {
				String key = toks.next();
				String trans = toks.next();
				translations.put(key,trans);
			} else if(tag.equals(PRELUDE_COMMENT_TAG)) {
				toks.next();
			} else
				Editor.panic("Badly formed prelude");
		}	
	}

	private StringBuffer buf;
	private StringBuffer dataAbsBuf;
	private Hashtable vNumTable;
	private Counter vNums;
	private boolean writeOutputVars;
	private Hashtable outputVars;
	
	public ToHaskell() {
		buf = new StringBuffer(); dataAbsBuf = new StringBuffer();
		vNumTable = new Hashtable(); vNums = new Counter();
		writeOutputVars = false; outputVars = new Hashtable();
	}

	public String writeModule(Value v) throws CodeGenException {
		if(v instanceof DataAbs) {
			writeOutputVars = true;
			write(v,-1,null);
			writeOutputVars = false;
			return writeModule(v.body());
		} else if(v instanceof LetAbs) {
			return writeModuleDefs((LetAbs)v);
		}
		throw new CodeGenException("module not Let or Data abstration");
	}

	public String writeModuleDefs(LetAbs lebs) throws CodeGenException {

		/* write header preamble */

		buf.append(vfpe.editor.Config.haskellHeader);

		/* write defs */

		writeDefList(lebs,-1,null,true);

		/* return */
		
		return getOutput();
	}

	public String getOutput() {
		buf.append(dataAbsBuf.toString());
		return buf.toString();
	}

	public void write(Syntax s, int indent, Object scope) throws CodeGenException {

		String cName = s.getClass().getName();

		if(cName.equals("vfpe.syntax.Const")) {
			ConstBind cb = (ConstBind)((Const)s).binding;
			buf.append(getTranslation(cb));
		} else if(s instanceof VarVal) {
			writeVar(((VarVal)s).binding);
		} else if(cName.equals("vfpe.syntax.AppVal")) {
			AppVal av = (AppVal)s;
			buf.append('(');
			write(av.body(),indent,scope);
			for(int i=0;i < av.arity();i++) {
				buf.append(' '); write(av.arg(i),indent,scope);
			}
			buf.append(')');
		} else if(cName.equals("vfpe.syntax.VarBind")) {
		   writeVar((VarBind)s);
		} else if(cName.equals("vfpe.syntax.PatBind")) {
			PatBind pb = (PatBind)s;
			ConstBind dataCon = (ConstBind)pb.dataCon.binding;
			if(dataCon.name.startsWith("Tuple-")) {
				writeTuple(pb.bindings,indent,scope);
			} else {
				buf.append('(');
				buf.append(getTranslation(dataCon));
				for(int i=0;i < pb.bindings.size();i++) {
					buf.append(' ');
					write((Syntax)pb.bindings.elementAt(i),indent,scope);
				}
				buf.append(')');
			}
		} else if(cName.equals("vfpe.syntax.LamAbs")) {
			LamAbs labs = (LamAbs)s;
			buf.append("(\\");
			write((Syntax)labs.bindings.elementAt(0),indent,scope);
			for(int i=1;i < labs.bindings.size();i++) {
				buf.append(' ');
				write((Syntax)labs.bindings.elementAt(i),indent,scope);
			}
			buf.append("->");
			write(labs.body(),indent,scope);
			buf.append(')');
		} else if(cName.equals("vfpe.syntax.BtmVal")) {
			buf.append("undefined");
		} else if(cName.equals("vfpe.syntax.LetAbs")) {
			LetAbs lebs = (LetAbs)s;
			buf.append("(let {\n");
			writeDefList(lebs,indent,scope,false);
			spaces(indent);
			buf.append("} in ");
			write(lebs.body(),indent,scope);
			buf.append(')');
		} else if(cName.equals("vfpe.syntax.Literal")) {
			/*	if I remember rightly, I have to put a type dec in for
				numeric types */
			buf.append(((Literal)s).str);
		} else if(cName.equals("vfpe.syntax.Patterns")) {
			Patterns pats = (Patterns)s;

			/* write lambda part */
			
			buf.append("(\\");
			String tuple = writeCaseVars(pats);
			buf.append(" -> ");

			/* write case part */

			writeCaseBody(pats,tuple,indent,scope);
		} else if(cName.equals("vfpe.syntax.Guards")) {
			Guards gds = (Guards)s;
			buf.append("("+GUARD_FUNCTION_NAME+" [\n");
			for(int i=0;i < gds.arity();i+=2) {
				if(i>0) buf.append(",\n");
				spaces(indent+1);
				buf.append('(');
				write(gds.arg(i),indent+1,scope);
				buf.append(',');
				write(gds.arg(i+1),indent+1,scope);
				buf.append(')');
			}
			buf.append('\n'); spaces(indent+1);
			buf.append("])");
		} else if(cName.equals("vfpe.syntax.CondVal")) {
			CondVal cv = (CondVal)s;
			buf.append("(if ");
			write(cv.condition(),indent,scope);
			buf.append(" then ");
			write(cv.consequent(),indent,scope);
			buf.append(" else ");
			write(cv.alternative(),indent,scope);
			buf.append(')');
		} else if(cName.equals("vfpe.syntax.DataAbs")) {
			DataAbs dabs = (DataAbs)s;
			dataAbsBuf.append("data ");
			String dtString = dabs.typeString.substring(1,
				dabs.typeString.length()-1);
			dataAbsBuf.append(dtString);
			dataAbsBuf.append(" = ");
			for(int i=0;i < dabs.bindings.size();i++) {
				if(i > 0) dataAbsBuf.append(" | ");
				DataBind db = (DataBind)dabs.bindings.elementAt(i);
				dataAbsBuf.append(db.name);
				for(int j=0;j < db.argTypeStrings.size();j++) {
					dataAbsBuf.append(" (");
					dataAbsBuf.append((String)db.argTypeStrings.elementAt(j));
					dataAbsBuf.append(')');
				}
			}
			dataAbsBuf.append(" deriving (Eq, Show, Ord)\n\n");
			if(!writeOutputVars)
				write(dabs.body(),indent,scope);
		} else if(cName.equals("vfpe.syntax.List")) {
			List list = (List)s;
			buf.append('[');
			Vector args = (Vector)list.args.clone();
			args.removeElementAt(0);
			writeCommaList(args,indent,scope);
			buf.append(']');
		} else {
			throw new CodeGenException("Whoops: haven't written output for " +
				cName + " yet.");
		}
	}

	private String getTranslation(ConstBind cb) {
		return (String)translations.get(cb.group+"/"+cb.name);
	}

	private void writeCaseBody(Patterns pats, String tuple, int indent, Object scope)
		throws CodeGenException {
		buf.append("case ");
		buf.append(tuple);
		buf.append(" of {\n");

		/* write patterns */

		for(int i=0;i < pats.arity();i++) {
			spaces(indent+1);
			writeTuple(((LamAbs)pats.arg(i)).bindings,indent,scope);
			buf.append(" -> ");
			write(((LamAbs)pats.arg(i)).body(),indent+1,scope);
			buf.append(";\n");
		}
		spaces(indent); buf.append("})");
	}

	private String writeCaseVars(Patterns pats) {
		String tuple = "(";
		for(int i=0;i < pats.nArgs;i++) {
			String var = VAR_PREFIX + vNums.next();
			if(i > 0) {
				buf.append(' '); tuple += ", ";
			}
			buf.append(var); tuple += var;
		}
		return tuple + ")";
	}

	private void writeBindingList(AbsVal absv, int indent, Object scope)
		throws CodeGenException {
		for(int i=0;i < absv.bindings.size();i++) {
			buf.append(' ');
			write((Binding)absv.bindings.elementAt(i),indent,scope);
		}
	}

	private void writeCommaList(Vector v, int indent, Object scope)
		throws CodeGenException {
		int arity = v.size();
		if(arity == 0) return;
		write((Syntax)v.elementAt(0),indent,scope);
		for(int i=1;i < arity;i++) {
			buf.append(", ");
			write((Syntax)v.elementAt(i),indent,scope);
		}
	}

	private void writeTuple(Vector v,int indent,Object scope)
		throws CodeGenException {
		buf.append('(');
		writeCommaList(v,indent,scope);
		buf.append(')');
	}

	private void writeDefList(
		LetAbs lebs,int indent,Object scope,boolean outputVars)
		throws CodeGenException {

			
		for(int i=0;i < lebs.bindings.size();i++) {
			spaces(indent+1);
			boolean tmp = writeOutputVars;
			
			
			/* we put in functions explicitly to avoid the dreaded monomorphism
			   restriction */
			
			Value def = lebs.arg(i);
			Binding b = (Binding)lebs.bindings.elementAt(i);
			
			writeOutputVars = outputVars;
			write(b,indent,scope);
			writeOutputVars = tmp;
			
			if(def instanceof LamAbs) {
				LamAbs labs = (LamAbs)def;
				writeBindingList(labs,indent,scope);
				buf.append(" = ");
				write(labs.body(),indent+1,scope);
				if(!outputVars)	buf.append(';');
				buf.append('\n');
			} else if(def instanceof Patterns) {
				Patterns pats = (Patterns)def;
				buf.append(' ');
				String tuple = writeCaseVars(pats);
				buf.append(" = (");
				writeCaseBody(pats,tuple,indent+1,scope);
				if(!outputVars)	buf.append(';');
				buf.append('\n');
			} else {
			   	buf.append(" = ");
			   	write(lebs.arg(i),indent+1,scope);
			   	if(!outputVars)	buf.append(';');
			   	buf.append('\n');
			}
			
		}
	}

	private void spaces(int n) {
		for(int i=0;i<n*TABSIZE;i++) buf.append(' ');
	}

	private void writeVar(Binding b) throws CodeGenException {
		if(writeOutputVars || outputVars.containsKey(b)) {
			checkHaskellId(b.name);
			buf.append(b.name);
			if(!outputVars.containsKey(b))
				outputVars.put(b,b);
		} else {
			if(!vNumTable.containsKey(b))
				vNumTable.put(b,vNums.next());
			int n = ((Integer)vNumTable.get(b)).intValue();
			buf.append(VAR_PREFIX+n+b.name);
		}
	}
	
	private void checkHaskellId(String name) throws CodeGenException {

	}

	private void checkHaskellTypeId(String tname) throws CodeGenException {

	}

}
