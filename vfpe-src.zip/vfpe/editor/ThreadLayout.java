/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997-1999
*/

package vfpe.editor;

import java.awt.Component;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import jkk.gui.ToolTipButton;
import vfpe.editor.SyntaxFace;
import vfpe.editor.SyntaxControl;
import vfpe.editor.SyntaxLayout;
import vfpe.editor.ValueLayout;
import vfpe.editor.ValueControl;
import vfpe.syntax.Thread;
import vfpe.syntax.Value;

public class ThreadLayout extends ValueLayout {
	public static final long serialVersionUID = 1;
	
	public Thread thread;
	
	public ThreadLayout(Thread t) {
		super(t); thread = t;
	}

	/* overridden tool stuff */

	protected String syntaxName() { return "thread root"; }

	protected SyntaxFace makeFace() { 
		return new ImageFace(this,(Image)Config.iconLib.get("thread"));
	}

	protected Component makeControls() {
		return new ThreadControl(this);
	}

}

class ThreadControl extends ValueControl {
	private static final String REMOVE_BUTTON = "remove";
	private static final String RENAME_BUTTON = "rename";

	public ThreadControl(ThreadLayout tl) {
		super(tl);

		ToolTipButton b = new ToolTipButton(Editor.sharedInstance,
			REMOVE_BUTTON,REMOVE_BUTTON);
		cp.add(b,"position=0,4,3,1");
		b.addActionListener(this); b.setCommand(REMOVE_BUTTON);

		b = new ToolTipButton(Editor.sharedInstance,
			RENAME_BUTTON,RENAME_BUTTON);
		cp.add(b,"position=3,4,3,1");
		b.addActionListener(this); b.setCommand(RENAME_BUTTON);
	}

	/* event handling */

	public void actionPerformed(ActionEvent ae) {
		String cmd = ae.getActionCommand();
		Thread t = (Thread)body.syntax;
		if(cmd.equals(REMOVE_BUTTON)) {
			Value bd = t.body();
			t.replace(bd);
			t.layoutInfo.replaceMe(bd.layoutInfo);
			close = true;
		} else if(cmd.equals(RENAME_BUTTON)) {
			String s = jkk.gui.Lib.requestString("Rename",
				"New name", Editor.sharedInstance,"thread",false,this);
			if(s != null && !s.equals("")) {
				t.name = s;
				t.layoutInfo.replaceMe(t.layoutInfo);
			}
		}

		super.actionPerformed(ae);
	}
	
}



