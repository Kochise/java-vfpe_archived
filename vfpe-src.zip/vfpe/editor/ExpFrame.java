/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1998-1999
*/

package vfpe.editor;

import java.awt.Dialog;
import java.awt.Font;
import java.awt.Frame;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import jkk.gui.SlidingPane;
import vfpe.editor.Config;
import vfpe.editor.Editor;
import vfpe.editor.ExpPanel;
import vfpe.editor.SyntaxLayout;

public class ExpFrame extends /* Dialog */ Frame implements WindowListener {
	public SyntaxLayout root;
	protected ExpPanel ep;

	public ExpFrame(String title, SyntaxLayout r) {
		super(title); // for frames
		//super(Editor.sharedInstance,title,false); // for dialogs
		setIconImage(Config.getIcon("lambda")); // for frames
		setFont(Font.decode(Config.getProp("font.standard")));
		setBackground(Config.faceColour);
		addWindowListener(this);
		root = r; r.faceFrame = this;
		ep = new ExpPanel();
		SlidingPane sp = new SlidingPane(ep);
		add("Center",sp);
		ep.setExp(root);
		pack();
		Editor.sharedInstance.frames.addElement(this);
	}

	/* window manager events */
	
	public void windowActivated(WindowEvent event) { }

	public void windowClosed(WindowEvent event) { }
	public void windowClosing(WindowEvent event) {
		if(Config.takeSnapshots) {
			Editor.shotToFile(this);
		} else {
			root.removeFaces();
		}
	}
	
	public void windowDeactivated(WindowEvent event) { }
	public void windowDeiconified(WindowEvent event) { }
	public void windowIconified(WindowEvent event) { }
	public void windowOpened(WindowEvent event) { }
}
