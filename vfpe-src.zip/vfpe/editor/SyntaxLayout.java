/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997-1999
*/

package vfpe.editor;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.Label;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.Serializable;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import jkk.gui.Bordered;
import jkk.gui.GridBagPanel;
import jkk.gui.LinkPanel;
import jkk.gui.MultiLineTextLabel;
import jkk.gui.StringRequester;
import jkk.gui.TextLabel;
import vfpe.editor.ExpFrame;
import vfpe.editor.ExpPanel;
import vfpe.editor.SyntaxFace;
import vfpe.syntax.Syntax;
import vfpe.type.Type;

public abstract class SyntaxLayout implements Serializable {
    public static final long serialVersionUID = 1;
    
    /* constants ---------------------------------------------- */

    protected static int GAP = 4;
    protected static String NO_TYPE_STRING = "no type";
    protected static String TYPE_LABEL = " type:";
    protected static String CAT_LABEL  = " flavour:";
    private static final String COMMENT_DIALOG_TITLE = "Edit comment";
    private static final String EDIT_COMMENT_PROMPT = "Enter new comment";

    protected static final int NO_SPINE = 0;
    protected static final int LEFT_SPINE = 1;
    protected static final int RIGHT_SPINE = 2;

    /* fields ------------------------------------------------- */

    protected Syntax syntax;
    protected Point pos;
    protected transient SyntaxFace face = null;
    protected transient ExpFrame faceFrame = null;

    /* constructors ------------------------------------------- */

    public SyntaxLayout(Syntax syntax) {
        this.syntax = syntax;
        pos = new Point(0,0);
    }

    /* tools -------------------------------------------------- */

    protected void handleSyntaxOp(String cmd) {
        if(cmd.equals(SyntaxControl.LAYOUT_LABEL)) {
            ExpPanel ep = (ExpPanel)face.getParent();
            ep.root.layoutSubtree(new Point(SyntaxLayout.GAP,
                SyntaxLayout.GAP));
            ep.validate();
        } else if(cmd.equals(SyntaxControl.COMMENT_LABEL)) {
            StringRequester sr = new StringRequester(COMMENT_DIALOG_TITLE,
                EDIT_COMMENT_PROMPT,Editor.sharedInstance,
                    syntax.comment,5,40);
            sr.tf.setBackground(Config.textBackdropColour);
            jkk.gui.Lib.screenCentre(sr);
            sr.setVisible(true);
            String newComment =    sr.getString();
            if(newComment != null)
                syntax.comment = newComment;
        }
    }
    
    protected String getTypeString() {
        Type t = Editor.types.getType(syntax);
        if(t == null)
            return NO_TYPE_STRING;
        else
            return t.writeType();
    }

    protected String getDescription(boolean includeComment) {
        StringBuffer desc = new StringBuffer();
        desc.append(TYPE_LABEL); desc.append(' ');
        desc.append(getTypeString());
        desc.append('\n');
        desc.append(CAT_LABEL); desc.append(' ');
        desc.append(syntax.syntaxName());
        if(includeComment && syntax.comment != null) {
            desc.append('\n'); desc.append(syntax.comment);
        }
        return desc.toString();
    }

    protected Component getDescPanel(boolean includeComment) {
        Bordered border = new Bordered(Bordered.SQUARE,
            Bordered.PLAIN,2);
        border.setBackground(Config.infoBackdropColour);        
        border.add("",new MultiLineTextLabel(
            getDescription(includeComment)));
        return border;
    }

    /* syntax specific things --------------------------------- */

    protected abstract SyntaxFace makeFace();

    protected Component makeControls() {
        return new SyntaxControl(this);
    }

    public void updateFrom(SyntaxLayout template) { }

    /*    this implementation does tree layout with Syntax args ... */

    protected abstract Vector layoutChildren();

    protected abstract void drawIncomingLinks();

    protected abstract int spineLink();
    
    /* face component control --------------------------------- */

    protected void makeFaces(Container c) {
        if(face == null || face.getParent() == null) {
            face = makeFace(); 
            c.add(face);
        }
        Vector args = layoutChildren();
        Enumeration e = args.elements();
        while(e.hasMoreElements()) {
            Syntax s = (Syntax)e.nextElement();
            s.layoutInfo.makeFaces(c);
        }
        drawLinks();
    }

    protected void removeFaces() { removeFaces(true); }
    
    protected void removeFaces(boolean removeRootFrame) {
        ExpPanel ep = null;
        if(face != null) {
            ep = (ExpPanel)face.getParent();
            ep.remove(face);
            face = null;
        }

        removeChildFaces();
        
        if(faceFrame != null && removeRootFrame) {
            Editor.sharedInstance.frames.removeElement(this.faceFrame);
            faceFrame.dispose(); faceFrame = null;
        }
    }

    protected void removeChildFaces() {
        Vector args = layoutChildren();
        Enumeration e = args.elements();
        while(e.hasMoreElements()) {
            Syntax s = (Syntax)e.nextElement();
            s.layoutInfo.removeFaces(true);
        }
    }

    protected void replaceMe(SyntaxLayout sl) {
        replaceMe(sl,true);
    }

    protected void replaceMe(SyntaxLayout sl, boolean doRedraw) {
        if(face == null) {
            System.out.println("trying to replace something without a face");
            return;
        }
        ExpPanel ep = (ExpPanel)face.getParent();
        
        /* if its root let the ExpPanel handle it */
        
        if(ep.root == this) {
            removeFaces(false);
            ep.setExp(sl); return;
        }

        /* otherwise replace subtree */

        removeFaces();
        sl.makeFaces(ep);    

        /*    re-layout tree ... eventually we may want to do something
            tricky like try to make the root of the new tree appear in
            the same places as the old node ... */

        sl.drawIncomingLinks();
        if(doRedraw) {
            ep.redraw();
        }
    }

    public ExpPanel findRootPanel() {
        SyntaxFace sf = face;
        if(face != null) {
            return (ExpPanel)sf.getParent();
        } else {
            Syntax p = syntax.getParent();
            if(p != null)
                return p.layoutInfo.findRootPanel();
            else
                return null;
        }
    }

    public abstract SyntaxLayout findVisibleParent();

    /* Layout stuff ------------------------------------------- */

    /* general SyntaxLayout tools */

    protected Dimension layoutSubtree(Point base) {
        Hashtable bounds = new Hashtable();
        calculateBounds(bounds);
        setLocations(base,bounds);
        Rectangle r = (Rectangle)bounds.get(this);
        return new Dimension(r.width+GAP*2,r.height+GAP*2);
    }

    protected void calculateBounds(Hashtable bounds) {
        Vector args = layoutChildren();
        int w = 0;
        int h = 0;
        Enumeration e = args.elements();
        while(e.hasMoreElements()) {
            Syntax s = (Syntax)e.nextElement();
            s.layoutInfo.calculateBounds(bounds);
            Rectangle d = (Rectangle)bounds.get(s.layoutInfo);
            if(Config.horizontalLayout) {
              h += d.height; w = Math.max(w,d.width);
            } else {
              w += d.width; h = Math.max(h,d.height);
            }
        }
        if(Config.horizontalLayout) {
          if(args.size() > 1)
            h += (args.size()-1)*GAP;
          if(w > 0) w += GAP;
        } else {
          if(args.size() > 1)
            w += (args.size()-1)*GAP;
          if(h > 0) h += GAP;
        }

        Dimension thisSize = face.getPreferredSize();
        if(Config.horizontalLayout){
          int height = Math.max(thisSize.height,h);
          int width = thisSize.width+w;
          if(Config.rootAtTop)
            bounds.put(this, new Rectangle(
              0,(height-thisSize.height)/2,width,height));
          else
            bounds.put(this, new Rectangle(
              width-thisSize.width,(height-thisSize.height)/2,
              width,height));
        } else {
          int width = Math.max(thisSize.width,w);
          int height = thisSize.height+h;
          if(Config.rootAtTop)
            bounds.put(this, new Rectangle(
              (width-thisSize.width)/2,0,width,height));
          else
            bounds.put(this, new Rectangle(
              (width-thisSize.width)/2,height-thisSize.height,width,height));
        }
    }

    protected void setLocations(Point base, Hashtable bounds) {
      Rectangle d = (Rectangle)bounds.get(this);
      Dimension psize = this.face.getPreferredSize();
      face.setLocation(base.x+d.x,base.y+d.y);
      face.setSize(psize);
      pos = new Point(base.x+d.x,base.y+d.y);

      if(Config.horizontalLayout) {
        int topEdge = base.y;
        int childBaseline;
        if(Config.rootAtTop)
            childBaseline = base.x+psize.width+GAP;
        else
            childBaseline = base.x+d.width-psize.width-GAP;
        Vector args = layoutChildren();
        //##// center only-children ?
        Enumeration e = args.elements();
        while(e.hasMoreElements()) {
            Syntax s = (Syntax)e.nextElement();
            d = (Rectangle)bounds.get(s.layoutInfo);
            if(Config.rootAtTop)
                s.layoutInfo.setLocations(
                    new Point(childBaseline,topEdge),bounds);
            else
                s.layoutInfo.setLocations(
                    new Point(childBaseline-d.width,topEdge),bounds);
            topEdge += d.height + GAP;
        }
      } else {
        int leftEdge = base.x;
        int childBaseline;
        if(Config.rootAtTop)
            childBaseline = base.y+psize.height+GAP;
        else
            childBaseline = base.y+d.height-psize.height-GAP;
        Vector args = layoutChildren();
        //##// center only-children ?
        Enumeration e = args.elements();
        while(e.hasMoreElements()) {
            Syntax s = (Syntax)e.nextElement();
            d = (Rectangle)bounds.get(s.layoutInfo);
            if(Config.rootAtTop)
                s.layoutInfo.setLocations(
                    new Point(leftEdge,childBaseline),bounds);
            else
                s.layoutInfo.setLocations(
                    new Point(leftEdge,childBaseline-d.height),bounds);
            leftEdge += d.width + GAP;
        }
      }
    }

    protected void drawLinks() {
        if(face == null) {
            return;
        }
        ExpPanel ep = (ExpPanel)face.getParent();
        Vector args = layoutChildren();

        for(int i=0;i < args.size();i++) {
            Syntax s = (Syntax)args.elementAt(i);
            int spine = spineLink();
            if(s.layoutInfo.face != null) {
                ep.addLink(face,s.layoutInfo.face);
                if(i == 0 && spine == LEFT_SPINE)
                    ep.setLinkAttribute(face,s.layoutInfo.face,LinkPanel.HEAVY);
                else if(i == (args.size()-1)&& spine == RIGHT_SPINE)
                    ep.setLinkAttribute(face,s.layoutInfo.face,LinkPanel.HEAVY);
            }
        }
    }
 
    public static void redoLayoutForNodes(Vector v) {
        Enumeration e = v.elements();
        Hashtable affectedPanels = new Hashtable();
        while(e.hasMoreElements()) {
            Syntax s = (Syntax)e.nextElement();
            if(s.layoutInfo.face != null) {
                ExpPanel ep = (ExpPanel)s.layoutInfo.face.getParent();
                if(!affectedPanels.contains(ep)) {
                    affectedPanels.put(ep,ep);
                    ep.root.replaceMe(ep.root);
                    ep.validate();
                }
            }
        }
    }
    
    /* control-click handling --------------------------------- */
    
    protected void controlClick() {
        Dialog d = new ControlDialog(this);
        d.show();
    }
    
    protected void click() { }
}

class ControlDialog extends Dialog implements WindowListener {
    private static final String TITLE = "Subexpression Control";
    
    ControlDialog(SyntaxLayout sl) {
        super(Editor.sharedInstance,TITLE,true);
        add("Center",sl.makeControls());
        addWindowListener(this);
        pack();  jkk.gui.Lib.locateNear(this,sl.face);
    }

    /* window manager events */
    
    public void windowActivated(WindowEvent event) { }

    public void windowClosed(WindowEvent event) { }
    public void windowClosing(WindowEvent event) {
        if(Config.takeSnapshots)
            Editor.shotToFile(this);
        setVisible(false); dispose();
    }
    
    public void windowDeactivated(WindowEvent event) { }
    public void windowDeiconified(WindowEvent event) { }
    public void windowIconified(WindowEvent event) { }
    public void windowOpened(WindowEvent event) { }
    
}
