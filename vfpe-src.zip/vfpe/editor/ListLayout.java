/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1998
*/

package vfpe.editor;

import java.awt.Component;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.util.Vector;

import jkk.gui.ToolTipButton;
import vfpe.syntax.BtmVal;
import vfpe.syntax.List;
import vfpe.syntax.Value;
import vfpe.type.Type;

public class ListLayout extends ValueLayout implements NowShowingLayout {
    public static final long serialVersionUID = 1;
    
    public List list;
    protected int nShowing;

    public ListLayout(List list) {
        super(list); this.list = list; nShowing = -1;
    }

    protected String syntaxName() { return "list"; }

    protected SyntaxFace makeFace() {
        return new FocusFace(this,(Image)Config.iconLib.get("list"));
    }

    protected Vector layoutChildren() {
        Vector v = new Vector();
        if(list.arity() > 0) {
            if(nShowing < 0) nShowing = 0;
            v.addElement(list.arg(nShowing));
        }
        return v;
    }

    protected Component makeControls() {
        return new ListControl(this);
    }

    /* control effects */

    public String nowShowing() {
        return " " + (nShowing+1) + " of " + list.arity();
    }

    public void leftArrowClick() {
        if(list.arity() == 0) return;
        list.arg(nShowing).layoutInfo.removeFaces();
        nShowing = jkk.math.Lib.mod(nShowing-1,list.arity());
        replaceMe(this);
    }

    public void rightArrowClick() {
        if(list.arity() == 0) return;
        list.arg(nShowing).layoutInfo.removeFaces();
        nShowing = jkk.math.Lib.mod(nShowing+1,list.arity());
        replaceMe(this);
    }

    public void showChild(Value v) {
        nShowing = ((Value)syntax).whatNumberIsChild(v);
    }
}

class ListControl extends ValueControl {
    private static final String DEL_VAL_LABEL = "delete element";
    private static final String ADD_VAL_AFTER = "add element after";
    private static final String SWAP_WITH_NEXT = "swap with next";
    
    ListLayout pl;
    
    ListControl(SyntaxLayout sl) {
        super(sl);
        pl = (ListLayout)sl;
        ToolTipButton b = new ToolTipButton(Editor.sharedInstance,
            DEL_VAL_LABEL,null);
        cp.add(b,"position=0,4,2,1");
        b.addActionListener(this);
        b = new ToolTipButton(Editor.sharedInstance,
            ADD_VAL_AFTER,null);
        cp.add(b,"position=2,4,2,1");
        b.addActionListener(this);
        b = new ToolTipButton(Editor.sharedInstance,
            SWAP_WITH_NEXT,null);
        cp.add(b,"position=4,4,2,1");
        b.addActionListener(this);
    }

    /* event handling */

    public void actionPerformed(ActionEvent event) {
        String cmd = event.getActionCommand();
        List pts = (List)pl.syntax;

        if(cmd.equals(DEL_VAL_LABEL)) {
            if(pl.nShowing == -1) {
                Editor.showMessage("Nothing to delete"); return;
            }
            pts.arg(pl.nShowing).layoutInfo.removeFaces();
            pts.deleteArg(pl.nShowing);
            if(pl.nShowing >= pts.arity())
                pl.nShowing = pts.arity()-1;
            Statistics.addOp("shrink","list");
// OPTIMISATION - restricted type inference
            if(Editor.typeless) Editor.goTyped();
            String s = Statistics.rebuildTypes("shrink");
            pl.replaceMe(pl);    close = true;
        } else if(cmd.equals(ADD_VAL_AFTER)) {
            BtmVal newEl = new BtmVal();
            pts.addArgAt(newEl,pl.nShowing+1);
            if(pl.nShowing >= 0)
                pts.arg(pl.nShowing).layoutInfo.removeFaces();
            pl.nShowing++;
            Statistics.addOp("grow","list");

            String r = null;
            if(Editor.typeless || !Config.optimiseGrow) {
                Editor.goTyped(); r = Statistics.rebuildTypes("grow");
            } else {
                Statistics.startTiming();
                // must be list type
                Type lt = Editor.types.getType(pts);
                Type lbt = lt.args[0];
                Editor.types.setType(newEl,lbt);
                Statistics.addTiming("grow");
            }
            if(r != null) {
                Thread.dumpStack();
                Editor.panic("Universe out of alignment error (see stack trace)");
            }

            pl.replaceMe(pl); close = true;
        } else if(cmd.equals(SWAP_WITH_NEXT)) {
            if(pts.arity() < 2) {
                Editor.showMessage("swap with what ?"); return;
            }
            int next = (pl.nShowing+1) % pts.arity();
            Value first = pts.arg(pl.nShowing);
            pts.arg(pl.nShowing).layoutInfo.removeFaces();
            pts.deleteArg(pl.nShowing);
            pts.addArgAt(first,next);
            pl.replaceMe(pl);
            Statistics.addOp("reorder","list");
        }

        
        super.actionPerformed(event);
    }    
}

