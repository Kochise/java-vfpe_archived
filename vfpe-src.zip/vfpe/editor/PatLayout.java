/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1998
*/

package vfpe.editor;

import java.awt.Component;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.util.Vector;

import jkk.gui.ToolTipButton;
import vfpe.syntax.LamAbs;
import vfpe.syntax.Patterns;
import vfpe.syntax.Value;
import vfpe.type.Type;
import vfpe.type.TypeException;
import vfpe.type.Substitution;

public class PatLayout extends ValueLayout implements NowShowingLayout {
    public static final long serialVersionUID = 1;
    
    public Patterns pv;
    protected int nShowing;

    public PatLayout(Patterns pv) {
        super(pv);
        this.pv = pv; nShowing = 0;
    }

    protected String syntaxName() { return "pattern set"; }

    protected SyntaxFace makeFace() {
        return new FocusFace(this,(Image)Config.iconLib.get("patterns"));
    }

    protected Vector layoutChildren() {
        return pv.arg(nShowing).layoutInfo.layoutChildren();
    }

    protected int spineLink() {
        return pv.arg(nShowing).layoutInfo.spineLink();
    }

    protected Component makeControls() {
        return new PatControl(this);
    }

    /* control effects */

    public String nowShowing() {
        return " " + (nShowing+1) + " of " + pv.arity();
    }

    public void leftArrowClick() {
        pv.arg(nShowing).layoutInfo.removeFaces();
        nShowing = jkk.math.Lib.mod(nShowing-1,pv.arity());
        replaceMe(this);
    }

    public void rightArrowClick() {
        pv.arg(nShowing).layoutInfo.removeFaces();
        nShowing = jkk.math.Lib.mod(nShowing+1,pv.arity());
        replaceMe(this);
    }

    public void showChild(Value v) {
        nShowing = ((Value)syntax).whatNumberIsChild(v);
    }
}

class PatControl extends ValueControl {
    private static final String DEL_PAT_LABEL = "delete pattern";
    private static final String ADD_PAT_AFTER = "add pattern after";
    private static final String SWAP_WITH_NEXT = "swap with next";
    
    PatLayout pl;
    
    PatControl(SyntaxLayout sl) {
        super(sl);
        pl = (PatLayout)sl;
        ToolTipButton b = new ToolTipButton(Editor.sharedInstance,
            DEL_PAT_LABEL,null);
        cp.add(b,"position=0,4,2,1");
        b.addActionListener(this);
        b = new ToolTipButton(Editor.sharedInstance,
            ADD_PAT_AFTER,null);
        cp.add(b,"position=2,4,2,1");
        b.addActionListener(this);
        b = new ToolTipButton(Editor.sharedInstance,
            SWAP_WITH_NEXT,null);
        cp.add(b,"position=4,4,2,1");
        b.addActionListener(this);
    }

    /* event handling */

    public void actionPerformed(ActionEvent event) {
        String cmd = event.getActionCommand();
        Patterns pts = pl.pv;

        if(cmd.equals(DEL_PAT_LABEL)) {
            if(pts.arity() < 2) {
                Editor.showMessage("can't delete last pattern"); return;
            }
            pts.arg(pl.nShowing).layoutInfo.removeFaces();
            pts.deleteArg(pl.nShowing);
            if(pl.nShowing >= pts.arity())
                pl.nShowing = pts.arity()-1;
// OPTIMISATION - restricted type inference ?
            if(Editor.typeless) Editor.goTyped();
            String s = Statistics.rebuildTypes("shrink");
            pl.replaceMe(pl);
            close = true;
            Statistics.addOp("shrink","pattern");
        } else if(cmd.equals(ADD_PAT_AFTER)) {
            LamAbs labs = LamAbsLayout.makeLamAbs(this,pts.nArgs);
            if(labs == null) {
                Editor.showMessage("pattern addition canceled"); return;
            }
            if(labs.bindings.size() != pts.nArgs) {
                Editor.showAlert("wrong arity for new pattern " +
                   labs.bindings.size() + " and pts.nArgs is " + pts.nArgs); return;
            }
            pts.addArgAt(labs,pl.nShowing+1);

            String r = null;
            if(Editor.typeless || !Config.optimiseGrow) {
                Editor.goTyped(); r = Statistics.rebuildTypes("grow");
            } else {
                // infer new lam abs type and unify with head
                Statistics.startTiming();
                try {
                    labs.inferType(Editor.types);
                    Type patType = Editor.types.getType(pts);
                    Substitution subs = Type.unify(Editor.types.getType(labs),patType);
                    Editor.types.substitute(subs);
                } catch(TypeException te) {
                    r = te.explain();
                }
                Statistics.addTiming("grow");
            }
            if(r != null) {
                Thread.dumpStack();
                Editor.panic("Universe out of alignment error (see stack trace)");
            }

            pl.replaceMe(pl); close = true;
            Statistics.addOp("grow","pattern");
        } else if(cmd.equals(SWAP_WITH_NEXT)) {
            if(pts.arity() < 2) {
                Editor.showMessage("swap with what ?"); return;
            }
            int next = (pl.nShowing+1) % pts.arity();
            Value first = pts.arg(pl.nShowing);
            pts.arg(pl.nShowing).layoutInfo.removeFaces();
            pts.deleteArg(pl.nShowing);
            pts.addArgAt(first,next);
            pl.replaceMe(pl);
            Statistics.addOp("reorder","pattern");
        }        
        
        super.actionPerformed(event);

    }    
}
