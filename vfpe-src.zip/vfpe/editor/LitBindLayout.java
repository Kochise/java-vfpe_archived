/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1998
*/

package vfpe.editor;

import java.awt.Component;
import java.util.Vector;

import vfpe.syntax.AppVal;
import vfpe.syntax.Binding;
import vfpe.syntax.AppVal;
import vfpe.syntax.Literal;
import vfpe.syntax.LitBind;

public class LitBindLayout extends BindingLayout {
	public static final long serialVersionUID = 1;
	
	LitBind lb;
		
	public LitBindLayout(LitBind lb) { 
		super(lb); this.lb = lb;
	}

	protected String syntaxName() { return "literal pattern"; }

	protected SyntaxFace makeFace() { 
		return new BindingFace(lb.literal.str,this);
	}

	protected Component makeControls() {
		return new BindingControl(this);
	}

	protected Vector layoutChildren() {
		return new Vector();
	}

}

