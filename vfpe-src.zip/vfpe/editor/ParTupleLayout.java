/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1998
*/

package vfpe.editor;

import java.awt.Component;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.util.Vector;

import jkk.gui.ToolTipButton;
import vfpe.syntax.BtmVal;
import vfpe.syntax.ParTuple;
import vfpe.syntax.Value;
import vfpe.type.Type;

public class ParTupleLayout extends ValueLayout {
    public static final long serialVersionUID = 1;
    
    public ParTuple parTuple;

    public ParTupleLayout(ParTuple parTuple) {
        super(parTuple); this.parTuple = parTuple;
    }

    protected String syntaxName() { return "parallel tuple"; }

    protected SyntaxFace makeFace() {
        return new ImageFace(this,(Image)Config.iconLib.get("parallel"));
    }

    protected Vector layoutChildren() {
        Vector v = new Vector();
        for(int i=0;i < parTuple.arity();i++)
            v.addElement(parTuple.arg(i));
        return v;
    }
}

