/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997-1999
*/

package vfpe.editor;

import java.awt.Color;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.Panel;
import java.awt.SystemColor;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Hashtable;
import java.util.Properties;
import java.util.StringTokenizer;

import jkk.io.Lib;
import vfpe.editor.Editor;

public class Config {
  
  private static final String DEF_PROP_FILE = "vfpe/vfpe.cfg";
  private static final String IMG_EXT = ".gif";
  
  protected static Properties props;
  protected static Hashtable iconLib;
  protected static String prelude;
  public static String haskellHeader;

  /* some cached prop values for conveinence */

  public static boolean rootAtTop;
        public static boolean horizontalLayout;
  public static boolean bindingsOnLeft;
  public static boolean letBindingsOnLeft;
  public static boolean applyVars;
  public static boolean tidyAfterReduction;
  public static boolean grabOverwrite;
  public static boolean useTypedGrabs;
  public static boolean takeSnapshots;
  public static boolean doubleBufferExp;
  public static boolean recordStats;
  public static boolean promptForPatNames;
  public static Color nodeColour;
  public static Color textBackdropColour;
  public static Color faceColour;
  public static Color selectedColour;
  public static Color infoBackdropColour;
  public static Color infoTextColour;
  public static boolean optimiseAttach;
  public static boolean optimiseGrow;

  protected static void loadConfig(String [] argv) {

    /* eventually try to load properties from:
      command line specified location
      home directory
      current directory
      default via Class.getResource (implemented)
    */

    InputStream propStream =
      ClassLoader.getSystemResourceAsStream(DEF_PROP_FILE);
    if(propStream == null)
      Editor.panic("couldn't open properties file");

    props = new Properties();
    try {
      props.load(propStream);
    } catch(IOException ioe) {
      Editor.panic("problem loading properties");
    }

    /* load prelude */

    String preludeFile = props.getProperty("prelude.file");
    prelude = Lib.resourceToString(preludeFile);

    /* load haskell header */

    preludeFile = props.getProperty("haskell.header");
    haskellHeader = Lib.resourceToString(preludeFile);

    /* load icon library */

    iconLib = new Hashtable();
    String iconDir = props.getProperty("icon.dir");
    Panel dummyPanel = new Panel();
    int iNum = 1;
    MediaTracker mTrack = new MediaTracker(dummyPanel);
    while(true) {
      String iList = props.getProperty("icon.list."+iNum);
      if(iList == null) break;
      StringTokenizer ics = new StringTokenizer(iList,",");
      while(ics.hasMoreTokens()) {
        String iconName = ics.nextToken();
        URL url = ClassLoader.getSystemResource(iconDir+"/"+iconName+IMG_EXT);
        Image icon = jkk.gui.Lib.imageFromURL(url,null);
        if(icon == null)
          Editor.panic("problem loading icon " + iconName);
        mTrack.addImage(icon,0);
        iconLib.put(iconName,icon);
      }
      iNum++;
    }
    try {
      mTrack.waitForAll();
    } catch(InterruptedException ie) {
      Editor.panic("problem waiting for icon: " + ie);
    }

    /* set cached prop values */

    rootAtTop = Boolean.valueOf(
      getProp("behaviour.layout.rootAtTop")).booleanValue();
    horizontalLayout = Boolean.valueOf(
      getProp("behaviour.layout.horizontal")).booleanValue();
    bindingsOnLeft = Boolean.valueOf(
      getProp("behaviour.layout.bindingsOnLeft")).booleanValue();
    letBindingsOnLeft = Boolean.valueOf(
      getProp("behaviour.layout.letBindingsOnLeft")).booleanValue();
    applyVars = Boolean.valueOf(
      getProp("behaviour.editor.apply.vars")).booleanValue();
    tidyAfterReduction = Boolean.valueOf(
      getProp("behaviour.editor.tidyafterreduction")).booleanValue();
    grabOverwrite = Boolean.valueOf(
      getProp("behaviour.editor.grab.overwrite")).booleanValue();
    useTypedGrabs = Boolean.valueOf(
      getProp("behaviour.editor.usetypedgrab")).booleanValue();
    takeSnapshots = Boolean.valueOf(
      getProp("behaviour.editor.takesnapshots")).booleanValue();
    doubleBufferExp = Boolean.valueOf(
      getProp("behaviour.editor.doublebufferexp")).booleanValue();
    recordStats = Boolean.valueOf(
      getProp("behaviour.editor.recordstats")).booleanValue();
    promptForPatNames = Boolean.valueOf(
      getProp("behaviour.editor.patnameprompt")).booleanValue();
    optimiseAttach = Boolean.valueOf(
      getProp("behaviour.typecheck.optimise.attach")).booleanValue();
    optimiseGrow = Boolean.valueOf(
      getProp("behaviour.typecheck.optimise.grow")).booleanValue();

    /* colour style stuff */

    if(!Boolean.valueOf(
      getProp("colour.use.system")).booleanValue()) {
      textBackdropColour = Color.decode(getProp("colour.text.backdrop"));
      faceColour = Color.decode(getProp("colour.face"));
      nodeColour = Color.decode(getProp("colour.node"));
      selectedColour = nodeColour.darker();
      infoBackdropColour = faceColour.brighter();
      infoTextColour = Color.decode(getProp("colour.infoText"));
    } else {
      textBackdropColour = SystemColor.window;
      faceColour = SystemColor.control;
      nodeColour = SystemColor.control;
      selectedColour = nodeColour.darker();
      infoBackdropColour = SystemColor.info;
      infoTextColour = SystemColor.infoText;
    }

  }

  public static String getProp(String pname) {
    return props.getProperty(pname);
  }

  public static Image getIcon(String iName) {
    return (Image)iconLib.get(iName);
  }
}
