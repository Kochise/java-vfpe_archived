/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997-2001
*/

package vfpe.editor;

import java.awt.Checkbox;
import java.awt.CheckboxGroup;
import java.awt.Font;
import java.awt.Label;
import java.awt.TextArea;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.TextEvent;
import java.awt.event.TextListener;
import java.util.Vector;

import jkk.Comparator;
import jkk.gui.GridBagPanel;
import jkk.gui.ToolTipButton;
import jkk.text.Lib;
import vfpe.Reducer;
import vfpe.syntax.Thread;

public class ReducerPanel extends GridBagPanel implements
    ItemListener, ActionListener, TextListener {
    private static final String AOR_LABEL = "AOR";
    private static final String NOR_LABEL = "NOR";
    private static final String BY_VALUE_LABEL = "call-by-value";
    private static final String BY_NEED_LABEL = "call-by-need";
    private static final String STRICT_CONS_LABEL = "strict constructors";
    private static final String EXPAND_CYCLES_LABEL = "expand cycles";
    private static final String THREAD_PARALLEL_LABEL = "thread parallel";
    private static final String RLIMIT_LABEL = "Evaluation Limit";
    private static final String RCOUNT_LABEL = "Reduction Count";
    private static final String RCOUNT_RESET_LABEL = "Reset";
    private static final String CYCLE_LABEL = "Cycle Count";
    private static final String CYCLE_RESET_LABEL = "Cycle Reset";
    
    private Reducer r;
    Checkbox aBox, nBox, vBox, needBox, sConsBox;
    Checkbox tBox, cBox;
    TextField limitField;
    TextField countField;
    TextArea profile;
    TextField cycleField;
    TextArea threadStats;

    public ReducerPanel(Reducer r) {
        super(); this.r = r;
        setDefaults("padding=2,2");

        CheckboxGroup orderGroup = new CheckboxGroup();
        add(aBox = new Checkbox(AOR_LABEL),"position=0,0,2,1 weight=1.0,0.0");
        aBox.setCheckboxGroup(orderGroup);
        aBox.addItemListener(this);
        add(nBox = new Checkbox(NOR_LABEL),"position=2,0,2,1 weight=1.0,0.0");
        nBox.setCheckboxGroup(orderGroup);
        nBox.addItemListener(this);
        CheckboxGroup callTypeGroup = new CheckboxGroup();
        add(vBox = new Checkbox(BY_VALUE_LABEL),"position=0,1,2,1 weight=1.0,0.0");
        vBox.setCheckboxGroup(callTypeGroup);
        vBox.addItemListener(this);
        add(needBox = new Checkbox(BY_NEED_LABEL),"position=2,1,2,1 weight=1.0,0.0");
        needBox.setCheckboxGroup(callTypeGroup);
        needBox.addItemListener(this);
        
        add(sConsBox = new Checkbox(STRICT_CONS_LABEL),"position=0,2,2,1 weight=1.0,0.0");
        sConsBox.addItemListener(this);
/* thread parallel code
        add(tBox = new Checkbox(THREAD_PARALLEL_LABEL),"position=2,2,2,1 weight=1.0,1.0");
        tBox.addItemListener(this);
*/
/* this replaces the thread parallel checkbox */
        add(cBox = new Checkbox(EXPAND_CYCLES_LABEL),"position=2,2,2,1 weight=1.0,1.0");
        cBox.addItemListener(this);
        
        add(limitField = new TextField(),"position=0,3,2,1 weight=1.0,0.0");
        limitField.setBackground(Config.textBackdropColour);
        limitField.addTextListener(this);
        add(new Label(RLIMIT_LABEL),"position=2,3,1,1 weight=1.0,0.0");
        
        add(countField = new TextField(),"position=0,4,2,1 weight=1.0,0.0");
        countField.setBackground(Config.textBackdropColour);
        add(new Label(RCOUNT_LABEL),"position=2,4,1,1 weight=1.0,0.0");
        
        ToolTipButton b = new ToolTipButton(Editor.sharedInstance,
            RCOUNT_RESET_LABEL,null);
        b.setBackground(Config.faceColour);
        add(b,"position=3,3,1,2 weight=1.0,1.0");
        b.addActionListener(this);

        add(profile = new TextArea(), "position=0,5,4,1 weight=1.0,1.0");
        profile.setBackground(Config.textBackdropColour);
        profile.setFont(Font.decode("monospaced"));
/* thread parallel code
        add(new Label(CYCLE_LABEL),"position=2,6,1,1 weight=1.0,0.0");
        add(cycleField = new TextField(),"position=0,6,2,1 weight=1.0,0.0");
        cycleField.setBackground(Config.textBackdropColour);
        b = new ToolTipButton(Editor.sharedInstance,CYCLE_RESET_LABEL,null);
        b.setBackground(Config.faceColour);
        add(b,"position=3,6,1,1 weight=1.0,0.0");
        b.addActionListener(this);

        add(threadStats = new TextArea(), "position=0,7,4,1 weight=1.0,1.0");
        threadStats.setBackground(Config.textBackdropColour);
        threadStats.setFont(Font.decode("monospaced"));
*/
        
        updatePanel(); validate();
    }

    // tools
    
    public static String makeThreadStats(Reducer r) {
        Vector ts = r.threadSet;
        StringBuffer buf = new StringBuffer();
        for(int i=0;i < ts.size();i++) {
            Thread t = (Thread)ts.elementAt(i);
            buf.append(Lib.justify(t.name,16,"left"));
            buf.append(' ');
            buf.append(Lib.justify(t.workCycles,5,"right"));
            buf.append(' ');
            buf.append(Lib.justify(t.waitCycles,5,"right"));
            buf.append("\n");
        }
        return buf.toString();
    }

    public static String makeProfile(Reducer r) {
        Object [] keys = jkk.Lib.sortOnValues(r.unfolds, new Comparator() {
            public int compare(Object a, Object b) {
                int [] x = (int [])a; int [] y = (int [])b;
                return y[0] - x[0];
            }
        });
        StringBuffer buf = new StringBuffer();
        for(int i=0;i < keys.length;i++) {
            buf.append(Lib.justify(((int [])r.unfolds.get(keys[i]))[0],6,"right"));
            buf.append(' ');
            buf.append(keys[i]);
            buf.append('\n');
        }
        return buf.toString();
    }

    void updatePanel() {
        aBox.setState(r.reductionOrder == Reducer.AOR);
        nBox.setState(r.reductionOrder == Reducer.NOR);
        vBox.setState(r.callType == Reducer.CALL_BY_VALUE);
        needBox.setState(r.callType == Reducer.CALL_BY_NEED);
        sConsBox.setState(r.strictConstructors);
        cBox.setState(r.expandCycles);
/* thread parallel code
        tBox.setState(r.threadParallel);
*/
        limitField.setText(Integer.toString(r.reductionLimit));
        countField.setText(Integer.toString(r.rCount));
        profile.setText(makeProfile(r));
/* thread parallel code
        cycleField.setText(Integer.toString(r.cycles));
        threadStats.setText(makeThreadStats(r));
*/
    }

    void updateReducer() {
        if(aBox.getState())
            r.reductionOrder = Reducer.AOR;
        else if(nBox.getState())
            r.reductionOrder = Reducer.NOR;
        if(vBox.getState())
            r.callType = Reducer.CALL_BY_VALUE;
        else if(needBox.getState())
            r.callType = Reducer.CALL_BY_NEED;
        r.strictConstructors = sConsBox.getState();
        r.expandCycles = cBox.getState();
/* thread parallel code
        r.threadParallel = tBox.getState();
*/
        try {
            r.reductionLimit = Integer.parseInt(limitField.getText());
        } catch(NumberFormatException nfe) {
            
        }
    }

    // event handling
    public void itemStateChanged(ItemEvent e) {
        updateReducer();
    }

    public void actionPerformed(ActionEvent event) {
        String cmd = event.getActionCommand();

        if(cmd.equals(RCOUNT_RESET_LABEL)) {
            r.resetStats(); updatePanel();
        } else if(cmd.equals(CYCLE_RESET_LABEL)) {
            r.resetThreadStats();
            updatePanel();
        }
    }

    public void textValueChanged(TextEvent te) {
        updateReducer();
    }
}

