/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1998
*/

package vfpe.editor;

import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;

import jkk.gui.GridBagPanel;
import jkk.gui.ImageLabel;
import jkk.gui.TextLabel;
import vfpe.syntax.Value;

public class FocusFace extends SyntaxFace implements ActionListener {

	private TextLabel  tl;
	ImageLabel leftButton;
	ImageLabel rightButton;
	
	public FocusFace(SyntaxLayout body,  Image img) {
		super(body);
		ImageLabel lbl = new ImageLabel(img);
		GridBagPanel gbp = new GridBagPanel();
		gbp.add(lbl,"position=0,0,1,1 fill=NONE");
		lbl.addMouseListener(this);
		lbl.addMouseMotionListener(this);
		tl = null;
		if(body instanceof NowShowingLayout) {
			NowShowingLayout pl = (NowShowingLayout)body;
			tl = new TextLabel(pl.nowShowing());
		}
		gbp.add(tl,"position=1,0,1,1");
		tl.addMouseListener(this);
		tl.addMouseMotionListener(this);
		leftButton = new ImageLabel((Image)Config.iconLib.get("left"));
		gbp.add(leftButton,"position=2,0,1,1 fill=NONE");
		leftButton.addActionListener(this);
		rightButton = new ImageLabel((Image)Config.iconLib.get("right"));
		gbp.add(rightButton,"position=3,0,1,1 fill=NONE");
		rightButton.addActionListener(this);
		add("",gbp);
	}

	/* event handling */

	public void actionPerformed(ActionEvent ae) {
		if(body instanceof NowShowingLayout) {
			NowShowingLayout pl = (NowShowingLayout)body;
			if(ae.getSource().equals(rightButton))
				pl.rightArrowClick();
			else if(ae.getSource().equals(leftButton))
				pl.leftArrowClick();
		}
	}
}
