/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997-1999
*/

package vfpe.editor;

import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowListener;

import jkk.gui.Bordered;
import jkk.gui.GridBagPanel;
import jkk.gui.TextLabel;
import jkk.gui.ToolTipButton;
import vfpe.CodeGenException;
import vfpe.ToHaskell;
import vfpe.editor.SyntaxLayout;

class SyntaxControl extends Bordered implements ActionListener {
	protected static final String LAYOUT_LABEL = "auto layout";
	protected static final String COMMENT_LABEL = "edit comment";
	private static final String CLOSE_LABEL = "close";
	
	protected SyntaxLayout body;
	protected boolean close;
	protected GridBagPanel cp;
	
	SyntaxControl(SyntaxLayout sl) {
		super(Bordered.SQUARE,Bordered.NONE,2);
		body = sl; close = false;
		cp = new GridBagPanel();
		cp.setDefaults("padding=2,2");
		add("",cp);
		setBackground(Config.faceColour);
		cp.setBackground(Config.faceColour);
		
		/* info fields */

		cp.add(body.getDescPanel(false),"position=0,0,6,2 insets=0,0,2,0");

		/* generic controls */

		ToolTipButton lb = new ToolTipButton(Editor.sharedInstance,
			Config.getIcon("AlignCenter"),LAYOUT_LABEL);
		cp.add(lb,"position=0,2,2,1");
		lb.tipBackground = Config.infoBackdropColour;
		lb.addActionListener(this); lb.setCommand(LAYOUT_LABEL);
		lb = new ToolTipButton(Editor.sharedInstance,
			Config.getIcon("DocumentDraw"),COMMENT_LABEL);
		cp.add(lb,"position=2,2,2,1");
		lb.tipBackground = Config.infoBackdropColour;
		lb.addActionListener(this); lb.setCommand(COMMENT_LABEL);
		lb = new ToolTipButton(Editor.sharedInstance,
			Config.getIcon("Exit"),CLOSE_LABEL);
		cp.add(lb,"position=4,2,2,1");
		lb.tipBackground = Config.infoBackdropColour;
		lb.addActionListener(this); lb.setCommand(CLOSE_LABEL);
	}

	/* event handling */

	public void actionPerformed(ActionEvent event) {
		
		String cmd = event.getActionCommand();

		body.handleSyntaxOp(cmd);
		if(cmd.equals(CLOSE_LABEL)) {
			close = true;
		}

		/* this bit should be called at end of all control panels */

		if(close) {
			((WindowListener)getParent()).windowClosing(null);
		}

	}
}
