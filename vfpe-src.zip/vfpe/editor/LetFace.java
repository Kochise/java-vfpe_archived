/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1998
*/

package vfpe.editor;

import java.awt.Component;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.util.Vector;

import jkk.gui.GridBagPanel;
import jkk.gui.ImageLabel;
import jkk.gui.TextLabel;
import vfpe.syntax.Value;
import vfpe.syntax.Binding;
import vfpe.syntax.LetAbs;

public class LetFace extends SyntaxFace implements ActionListener {

	ImageLabel button;
	ImageLabel lrButton;
	ImageLabel plusButton;
	Vector bindingButtons;
	
	public LetFace(LetAbsLayout body, boolean bindingsShowing) {
		super(body);
		GridBagPanel gbp = new GridBagPanel();
		
		if(bindingsShowing)
			button = new ImageLabel(Config.getIcon("up"));
		else
			button = new ImageLabel(Config.getIcon("down"));
		button.addActionListener(this);
		gbp.add(button,"position=0,0,1,1 fill=NONE");

		if(body.bindingBranches)
			lrButton = new ImageLabel(Config.getIcon("left"));
		else
			lrButton = new ImageLabel(Config.getIcon("right"));
		lrButton.addActionListener(this);
		gbp.add(lrButton,"position=1,0,1,1 fill=NONE");
		
		ImageLabel letImage = new ImageLabel((Image)Config.iconLib.get("let"));
		gbp.add(letImage,"position=3,0,1,1 fill=NONE padding=5,0");
		letImage.addMouseListener(this);
		letImage.addMouseMotionListener(this);
		
		plusButton = new ImageLabel((Image)Config.iconLib.get("plus"));
		plusButton.addActionListener(this);
		gbp.add(plusButton,"position=2,0,1,1 fill=NONE");
		
		if(bindingsShowing) {
			bindingButtons = new Vector();
			LetAbs labs = (LetAbs)body.syntax;
			for(int i=0;i < labs.bindings.size();i++) {
				Binding b = (Binding)labs.bindings.elementAt(i);
				TextLabel tl = new TextLabel(b.getName(),"center");
				bindingButtons.addElement(tl);
				tl.addActionListener(this);
				gbp.add(tl,"position=0,"+(i+1)+",3,1 fill=NONE");
			}	
		}
		
		add("",gbp);
	}

	/* event handling */

	public void actionPerformed(ActionEvent ae) {
		LetAbsLayout lal = (LetAbsLayout)body;
		
		if(ae.getSource().equals(button)) {
			lal.listBindings = !(lal.listBindings);
			lal.replaceMe(lal); return;
		}

		if(ae.getSource().equals(lrButton)) {
			lal.changeBAB(!lal.bindingBranches); return;
		}

		if(ae.getSource().equals(plusButton)) {
			lal.addBinding((Component)this);
		}
		
		int bn = bindingButtons.indexOf(ae.getSource());
		if(bn == -1) return;
		LetAbs labs = (LetAbs)lal.syntax;
		int mods = ae.getModifiers();
		if((mods & (InputEvent.CTRL_MASK |
					InputEvent.BUTTON2_MASK |
					InputEvent.BUTTON3_MASK)) != 0)
			lal.showDef(bn);
		else {
			Binding b = (Binding)labs.bindings.elementAt(bn);
			b.layoutInfo.click();
		}
	}
}
