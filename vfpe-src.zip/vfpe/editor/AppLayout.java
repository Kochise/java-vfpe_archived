/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997-1999
*/

package vfpe.editor;

import java.awt.Checkbox;
import java.awt.Component;
import java.awt.Image;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.Vector;

import jkk.gui.ToolTipButton;
import vfpe.editor.Config;
import vfpe.editor.ImageFace;
import vfpe.editor.SyntaxLayout;
import vfpe.editor.SyntaxControl;
import vfpe.editor.ValueLayout;
import vfpe.syntax.AppVal;
import vfpe.syntax.Value;
import vfpe.syntax.VarVal;

public class AppLayout extends ValueLayout {
    public static final long serialVersionUID = 1;
    
    protected boolean hideApply;

    public AppLayout(AppVal app) {
        super(app); hideApply = true;
    }

    protected String syntaxName() { return "function application"; }

    protected SyntaxFace makeFace() {
        /* this possibly isn't the best place to fix this */
        AppVal av = (AppVal)syntax;
        if(!(av.function() instanceof VarVal))
            hideApply = false;
        if(hideApply)
            return new LabelFace(this,((VarVal)av.function()).name());
        else
            return new ImageFace(this,(Image)Config.iconLib.get("arrow"));
    }

    protected Vector layoutChildren() {
        Vector all = super.layoutChildren();
        if(hideApply) {
            Vector v = new Vector();
            for(int i=1;i < all.size();i++)
                v.addElement(all.elementAt(i));
            all = v;
        }
        return all;
    }

    protected Component makeControls() {
        return new AppControl(this);
    }
}

class AppControl extends ValueControl implements ItemListener {
    private static final String HIDE_CHECKBOX_LABEL =
        "hide apply node";
    private static final String CURRY_LABEL = "curry";
    private static final String UNCURRY_LABEL = "uncurry";

    protected Checkbox hideCheckbox;
    protected AppLayout al;
    
    AppControl(SyntaxLayout sl) {
        super(sl);
        al = (AppLayout)sl;

        /* controls */
        
        hideCheckbox = new Checkbox(HIDE_CHECKBOX_LABEL,al.hideApply);
        hideCheckbox.setBackground(Config.faceColour);
        cp.add(hideCheckbox,"position=0,4,6,1");
        hideCheckbox.addItemListener(this);

        ToolTipButton b = new ToolTipButton(Editor.sharedInstance,
            CURRY_LABEL,null);
        cp.add(b,"position=0,5,3,1");
        b.addActionListener(this);
        b = new ToolTipButton(Editor.sharedInstance,
            UNCURRY_LABEL,null);
        cp.add(b,"position=3,5,3,1");
        b.addActionListener(this);
    }

    /* event handling */

    public void actionPerformed(ActionEvent ae) {
        String cmd = ae.getActionCommand();
        AppVal apv = (AppVal)al.syntax;
        if(cmd.equals(CURRY_LABEL)) {
            if(apv.arity() < 2) {
                Editor.showMessage("Nothing to split");
                return;
            }
            apv.function().layoutInfo.removeFaces();
            apv.curry();
            al.replaceMe(al);
        } else if(cmd.equals(UNCURRY_LABEL)) {
            Value f = apv.function();
            if(!(f instanceof AppVal)) {
                Editor.showMessage("Nothing to merge");
                return;
            }
            apv.uncurry();
            f.layoutInfo.removeFaces();
            al.replaceMe(al);
        }

        super.actionPerformed(ae);
    }

    public void itemStateChanged(ItemEvent event) {
        AppLayout al = (AppLayout)body;
        AppVal av = (AppVal)al.syntax;
        if(hideCheckbox.getState()) {    
            if(av.function() instanceof VarVal) {
                al.hideApply = true;
            } else {
                Editor.showMessage("can't abbreviate this funciton");
                hideCheckbox.setState(false);
                return;
            }
        } else {
            al.hideApply = false;    
        }
        al.replaceMe(al);
        if(hideCheckbox.getState()) {
            av.function().layoutInfo.removeFaces();
        }
        close = true;
        super.actionPerformed(new ActionEvent(this,0,"some shit"));
    }
}
