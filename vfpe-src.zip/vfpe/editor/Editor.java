/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997-2001
*/

package vfpe.editor;

import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.awt.FileDialog;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.GridBagLayout;
import java.awt.Label;
import java.awt.Point;
import java.awt.TextArea;
import java.awt.Toolkit;
import java.io.File;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;
import java.util.Vector;

import jkk.gui.Bordered;
import jkk.gui.ChoiceRequester;
import jkk.gui.ShotTaker;
import jkk.gui.SlidingPane;
import jkk.gui.TextLabel;
import jkk.IntTable;
import jkk.Set;
import vfpe.BadPreludeException;
import vfpe.CodeGenException;
import vfpe.Reducer;
import vfpe.syntax.ConstAbs;
import vfpe.syntax.ConstBind;
import vfpe.syntax.FreeVar;
import vfpe.syntax.LetAbs;
import vfpe.syntax.Syntax;
import vfpe.syntax.Value;
import vfpe.syntax.VarVal;
import vfpe.ToHaskell;
import vfpe.type.Type;
import vfpe.type.TypeException;
import vfpe.type.TypeInferenceState;

public class Editor extends Frame 
    implements ActionListener, WindowListener {

    /* constants -------------------------------------------- */

    private static String FRAME_TITLE = "VFP Editor";
    
    protected static int GAP = 16;

    /* GUI elements ----------------------------------------- */

    private Bordered mainPanel;
    private TextLabel messageArea;
    private Pallet palletPanel;

    /* editor state stuff ----------------------------------- */

    protected static Editor sharedInstance;
    protected Vector frames;
    public static ConstAbs prelude;
    protected static TypeInferenceState types;
    protected static boolean typeless;
    protected Syntax grabbed = null;
    protected boolean grabIsTyped = false;
    protected SyntaxFace selected = null;
    protected Reducer defaultReducer = makeDefaultReducer();

    /* other stuff ------------------------------------------ */

    private static File lastFile;
    public static ShotTaker shotTaker;
    
    /* main ------------------------------------------------- */

    public static void main(String [] argv) {
        Config.loadConfig(argv);            
        Editor e = new Editor();
    }

    /* constructor ------------------------------------------ */

    public Editor() {
        super(FRAME_TITLE);
        if(sharedInstance != null)
            panic("We're not reentrant.  Piss off.");
        sharedInstance = this;
//FEATURE put this back in when this is fixed in Java
        //setIconImage(Config.getIcon("lambda"));
        setFont(Font.decode(Config.getProp("font.standard")));
        frames = new Vector();
        prelude = null;

        /* gui ------------------------------------------------------- */

        addWindowListener(this);
        
        setLayout(new GridBagLayout());
        setBackground(Config.faceColour);
        
        /* "main" expression panel */
        
        mainPanel = 
            new Bordered(Bordered.SQUARE,Bordered.ETCHED,GAP);
        mainPanel.fillBackground = false;
        mainPanel.title = "Main Expression";
        jkk.gui.Lib.constrain(this,mainPanel,"position=0,1,1,1 weight=1.0,1.0");
        ExpPanel ep = new ExpPanel();
        SlidingPane sp = new SlidingPane(ep);
        mainPanel.add("",sp);

        /* load & parse prelude */

        Value v = new ConstAbs(Config.prelude);
        prelude = (ConstAbs)v;
        ep.setExp(v.layoutInfo);
        
        /* "pallet" */
        
        palletPanel = new Pallet();
        jkk.gui.Lib.constrain(this,palletPanel,"position=1,1,1,1 weight=0.0,1.0");        
        //palletBorder.add("",palletPanel);

        /* "message center" */

        messageArea = new TextLabel();
        jkk.gui.Lib.constrain(this,messageArea,
            "position=0,0,2,1 weight=0.0,0.0 fill=HORIZONTAL insets="+
            "0,"+GAP+",0,"+GAP);
        messageArea.setText(WELCOME_MSG);
        
        /* build types */

        String s = rebuildTypes();
        if(s != null)
            panic("type inference failure checking prelude: " + s);
    
        /* select the prelude to make the info panel start with a good size */

        select(prelude.layoutInfo.face);

        pack();
        Dimension ss = Toolkit.getDefaultToolkit().getScreenSize();
        setLocation(ss.width-getSize().width,0);
        setVisible(true);
    }

    /* type checking --------------------------------------------- */

    public static void goTyped() {
        typeless = false;
    }

    public static String rebuildTypes() {

        if(typeless)
            return "In typeless mode";
            
        TypeInferenceState newTypes = new TypeInferenceState();

        Set unboundVars = null;
        try {
            unboundVars = prelude.inferType(newTypes);
        } catch(TypeException te) {
            String s = "Type inference failed: " + te.explain();
            return s; 
        }

        if(unboundVars.size() > 0) {
            StringBuffer buf = new StringBuffer();
            buf.append("there are unbound variables:");
            Vector v = unboundVars.vectorise();
            for(int i=0;i < v.size();i++) {
                buf.append("\n");
                buf.append(((VarVal)v.elementAt(i)).name());
                buf.append(" ");
                buf.append(((VarVal)v.elementAt(i)).binding.abstraction().writeExp());
            }
            return buf.toString();
        }

        types = newTypes;
        return null;
    }

    /* expression loading/saving/output --------------------------- */
    
    public static boolean saveValue(Value v) {
        
        /*    make copy so we can mangle it */

        Value cv = (Value)v.copy(new Hashtable(),false);

        /* replace constants with FreeVars */
        /* at this point we only allow constants as free vars */

        Class cClass = null;
        try {
            cClass = Class.forName("vfpe.syntax.ConstAbs");
        } catch(ClassNotFoundException cnfe) {
            panic("can't find class ConstAbs");
        }

        /* serialise and write */
            
        Vector fvs = cv.findFreeVars();
        for(int i=0;i < fvs.size();i++) {
            VarVal vv = (VarVal)fvs.elementAt(i);
            if(!(vv.binding.abstraction().getClass().equals(cClass))) {
                showAlert("That's got a free variable in it (" + vv.binding.name + ")");
                return false;
            }
            ConstBind cb = (ConstBind)vv.binding;
            if(vv.equals(cv)) {
                cv = new FreeVar(cb.group+"/"+cb.name,cb.tstr);
                break;
            }
            vv.replace(new FreeVar(cb.group+"/"+cb.name,cb.tstr));
        }

        byte [] expBytes = jkk.io.Lib.objectToByteArray(cv);
        if(expBytes == null)
            panic("couldn't serialise value");

        FileDialog fd = new FileDialog(sharedInstance,
            Config.getProp("title.save.value"),FileDialog.SAVE);
        if(lastFile != null && lastFile.getParent() != null) {
            fd.setDirectory(lastFile.getParent());
        }
        fd.setVisible(true);
        String fname = fd.getDirectory()+File.separator+fd.getFile();

        try {
            jkk.io.Lib.byteArrayToFile(fname,expBytes);
            lastFile = new File(fname);
        } catch(IOException ioe) {
            showMessage(Config.getProp("error.save.fail")+" "+fname);
            return false;
        }
        return true;
    }

    public static String writeHaskell(Value v) {

        /* check this is a LetAbs */

        if(!(v instanceof vfpe.syntax.LetAbs ||
             v instanceof vfpe.syntax.DataAbs)) {
            return "at this point we only write Let expressions";
        }
        
        /* check for free vars */

        Class cClass = null;
        try {
            cClass = Class.forName("vfpe.syntax.ConstAbs");
        } catch(ClassNotFoundException cnfe) {
            panic("can't find class ConstAbs");
        }
            
        Vector fvs = v.findFreeVars();
        for(int i=0;i < fvs.size();i++) {
            VarVal vv = (VarVal)fvs.elementAt(i);
            if(!(vv.binding.abstraction().getClass().equals(cClass))) {
                return "That's got a free variable in it (" + vv.binding.name + ")";
            }
        }

        /* generate */

        String output = null;
        try {
            ToHaskell hask = new ToHaskell();
            output = hask.writeModule(v);
        } catch(CodeGenException cge) {
            return "error whilst generating code: " + cge;
        }

        /* get file */

        FileDialog fd = new FileDialog(sharedInstance,
            Config.getProp("title.save.value"),FileDialog.SAVE);
        if(lastFile != null && lastFile.getParent() != null) {
            fd.setDirectory(lastFile.getParent());
        }
        fd.setVisible(true);
        String fname = fd.getDirectory()+File.separator+fd.getFile();

        /* write */

        try {
            jkk.io.Lib.stringToFile(fname,output);
            lastFile = new File(fname);
        } catch(IOException ioe) {
            return "failed to write to " +fname;
        }

        return null;
    }

/*
    public static boolean analyseDepend(Value v) {
        Depend depend = new Depend();
        String report = depend.analyse(v);

        final Dialog d = new Dialog(Editor.sharedInstance,
            "Dependancy Analysis",false);
        d.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent we) {
                d.setVisible(false); d.dispose();
            }
        });

        d.add(new DependPanel(depend,sharedInstance),"Center");
        d.pack(); d.setVisible(true);
        
        return true;
    }
*/

    public static Value loadValue() {
    
        FileDialog fd = new FileDialog(sharedInstance,
            Config.getProp("title.load.value"),FileDialog.LOAD);
        if(lastFile != null && lastFile.getParent() != null) {
            fd.setDirectory(lastFile.getParent());
        }
        fd.setVisible(true);
        String fname = fd.getDirectory()+File.separator+fd.getFile();
        
        byte [] expBytes = jkk.io.Lib.fileToByteArray(fname);
        if(expBytes == null) {
            showMessage(Config.getProp("error.load.fail")+" "+fname);
            return null;
        }
        lastFile = new File(fname);

        /* reconstitute */
            
        Value v = (Value)jkk.io.Lib.byteArrayToObject(expBytes);

        try {
            v = prelude.knitWithPrelude(v);
        } catch(BadPreludeException bpe) {
            showAlert("Problem knitting loaded expression: " + bpe.getMessage());
            return null;
        }
        
        return v;
    }

    /* reduction stuff ------------------------------------------- */

    public static Reducer makeDefaultReducer() {
        Reducer r = new Reducer();
        
        r.strictConstructors = new Boolean(Config.getProp(
            "behaviour.reduction.strict.constructors")).booleanValue();
        if(Config.getProp("behaviour.reduction.order").equals("NOR"))
            r.reductionOrder = Reducer.NOR;
        else
            r.reductionOrder = Reducer.AOR;
        if(Config.getProp("behaviour.reduction.calltype").equals(
            "CALL_BY_NEED"))
            r.callType = Reducer.CALL_BY_NEED;
        else
            r.callType = Reducer.CALL_BY_VALUE;
        try {
            r.reductionLimit = Integer.parseInt(
                Config.getProp("behaviour.reduction.limit"));
        } catch(NumberFormatException nfe) {
            Editor.showMessage("bad reduction limit");
        }
        return r;
    }

    public static Reducer makeReducer() { return sharedInstance.defaultReducer; }
    
    /* sssshhhhhhTHUNK.  "message for you, sir" ------------------ */

    private static String WELCOME_MSG =
        "Welcome to the Visual Functional Program Editor";
    private static String ALERT_TITLE = "VFPE Alert";
    private static String [] OK_CHOICE = { "OK" };

    // for single-line incidental messages
    public static void showMessage(String msg) {
        sharedInstance.messageArea.setText(msg);
    }

    // for alert messages
    public static void showAlert(String msg) {
        ChoiceRequester d = new ChoiceRequester(ALERT_TITLE,
            msg, OK_CHOICE, sharedInstance);
        jkk.gui.Lib.screenCentre(d);
        d.setVisible(true);
    }

    /* shutdown code (graceful and otherwise) -------------------- */

    private void exit() { 

        /* exit confirmations, close frames nicely etc here */

        if(Config.recordStats) {
            Statistics.dump();
        }
        System.exit(0);
    }

    public static void panic(String msg) {
        System.err.println("VFPE panics: " + msg);
        System.exit(10);
    }

    /* global program layout ------------------------------------- */

    protected static void redrawAll() {
    
        Editor e = Editor.sharedInstance;
        Enumeration fs = e.frames.elements();
        Vector deadHeads = new Vector();
        while(fs.hasMoreElements()) {
            ExpFrame ef = (ExpFrame)fs.nextElement();
            if(!isAlive(ef.ep.root.syntax)) {
                deadHeads.addElement(ef);
            } else {
                ef.ep.rebuild();
            }
        }
        for(int i=0;i < deadHeads.size();i++) {
            ExpFrame ef = (ExpFrame)deadHeads.elementAt(i);
            ef.setVisible(false); ef.dispose();
        }
        e.prelude.layoutInfo.findRootPanel().rebuild();
    }

    protected static boolean isAlive(Syntax s) {
        while(s != null) {
            if(s.equals(prelude))
                return true;
            s = s.getParent();
        }
        return false;
    }

    /* statistics thing ------------------------------------------ */

    public static IntTable countNodes() {
        IntTable nds = new IntTable();
        prelude.countNodes(nds);
        return nds;
    }

    /* grabbed expression handling ------------------------------- */
    
    public static Cursor grabCursor =
        Cursor.getPredefinedCursor(HAND_CURSOR);
    public static Cursor normalCursor =
        Cursor.getPredefinedCursor(DEFAULT_CURSOR);
    public static Cursor waitCursor =
        Cursor.getPredefinedCursor(WAIT_CURSOR);

    public static Syntax getGrabbed() {
        return sharedInstance.grabbed;
    }

    public static void grab(Syntax s) { grab(s,false); }

    public static void grab(Syntax s, boolean typed) {
        if(sharedInstance.grabbed != null) {
            if(Config.grabOverwrite)
                sharedInstance.drop();
            else {
                showMessage("Drop that expression and I'll consider it");
                return;
            }
        }
        sharedInstance.grabbed = s;

        if(!Config.useTypedGrabs) typed = false;
        if(typed) {
            try {
                Statistics.startTiming();
                Value v = (Value)s;
                v.inferType(sharedInstance.types);
                Statistics.addTiming("create");
            } catch(TypeException te) {
                panic("type error during type expression grab: " + te);
            }
            sharedInstance.grabIsTyped = true;
        } 
        
        setCursorOnAll(grabCursor);
        
        if(getSelected() != null)
            deselect();
        sharedInstance.palletPanel.updateInfo();
    }

    public static void drop() { drop(false); }

    public static void drop(boolean removeTypes) {
        if(removeTypes && sharedInstance.grabIsTyped) {
            sharedInstance.types.removeTypes((Value)sharedInstance.grabbed);
        }
        sharedInstance.grabbed = null;
        sharedInstance.grabIsTyped = false;
        
        setCursorOnAll(normalCursor);
        sharedInstance.palletPanel.updateInfo();
    }

    public static void setCursorOnAll(Cursor c) {
        for(int i=0;i < sharedInstance.frames.size();i++)
            jkk.gui.Lib.setCursorForTree(
                (Component)sharedInstance.frames.elementAt(i), c);
        jkk.gui.Lib.setCursorForTree(sharedInstance,c);
    }

    public static SyntaxFace getSelected() {
        return sharedInstance.selected;
    }

    public static void select(SyntaxFace sel) {
        if(getGrabbed() != null) return;
        if(getSelected() != null) deselect();
        sharedInstance.selected = sel;
        sel.addKeyListener(sel); sel.requestFocus();
        sel.setBackground(Config.selectedColour);
        sel.repaint();
        sharedInstance.palletPanel.updateInfo();
    }

    public static void deselect() {
        if(getSelected() == null) return;
        SyntaxFace oldSel = getSelected();
        sharedInstance.selected = null;
        oldSel.removeKeyListener(oldSel);
        oldSel.setBackground(Config.faceColour);
        oldSel.repaint();
        sharedInstance.palletPanel.updateInfo();
    }

    /* make-node-visible operation ----------------------------- */

    public static void makeVisible(Syntax s) {
        SyntaxLayout sl;
        while(true) {
            if(s == null)
                Editor.panic("Error in makeVisible.");
            sl = s.layoutInfo;

            // if we have a face, redraw panel
            if(sl.face != null) {
                sl.findRootPanel().rebuild(); break;
            }

            // if our parent is "now showing" sort,
            // select correct case
            Syntax p = s.getParent();
            if(p.layoutInfo instanceof NowShowingLayout) {
                ((NowShowingLayout)p.layoutInfo).showChild((Value)s);

            // if our parent is LetAbs and we're a
            // binding (body or pattern), pop up new ExpFrame
            } else if(p instanceof LetAbs) {
                LetAbs labs = (LetAbs)p;
                LetAbsLayout lal = (LetAbsLayout)labs.layoutInfo;
                if(s != labs.body() && !lal.bindingBranches) {
                    int n = labs.whatNumberIs(s);
                    lal.showDef(n); break;
                }

            // if our parent is the prelude, and we're a binding,
            // pop out prelude binding
            } else if(p instanceof ConstAbs) {
                if(s instanceof ConstBind) {
                    ConstAbsLayout cal = (ConstAbsLayout)p.layoutInfo;
                    cal.showingBind = (ConstBind)s;
                }
            }

            // move up to parent
            s = s.getParent();
        }
        
        select(sl.face);
    }

    /* snapshot taker --------------------------------------------- */

    public static void shotToFile() {
        if(!Config.takeSnapshots) return;
        if(shotTaker == null) {
            shotTaker = new ShotTaker(sharedInstance);
        }
        try {
            shotTaker.shotToFile();
        } catch(IOException ioe) { }
    }

    public static void shotToFile(Component c) {
        if(!Config.takeSnapshots) return;
        if(shotTaker == null) {
            shotTaker = new ShotTaker(sharedInstance);
        }
        try {
            shotTaker.shotToFile(c);
        } catch(IOException ioe) { }
    }

    /* frame event handling --------------------------------------- */
        
    public void actionPerformed(ActionEvent event) {

    }

    /* window manager events */
    
    public void windowActivated(WindowEvent event) { }

    public void windowClosed(WindowEvent event) { exit(); }
    public void windowClosing(WindowEvent event) {
        if(Config.takeSnapshots) {
            shotToFile();
        } else {
            exit();
        }
    }
    
    public void windowDeactivated(WindowEvent event) { }
    public void windowDeiconified(WindowEvent event) { }
    public void windowIconified(WindowEvent event) { }
    public void windowOpened(WindowEvent event) { }

}
