/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997
*/

package vfpe.editor;

import jkk.gui.TextLabel;
import vfpe.editor.SyntaxFace;
import vfpe.editor.SyntaxLayout;

/* this implementation is for simple text-labeled buttons */

public class LabelFace extends SyntaxFace {
	private TextLabel lComp;
	
	/* constructor -------------------------------------------------- */

	protected LabelFace(SyntaxLayout body, String label) { 
        super(body);
		add("",lComp = new TextLabel(label));
		//lComp.addActionListener(this);
	}
}


