/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997
*/

package vfpe.editor;

import jkk.gui.Bordered;
import vfpe.editor.LabelFace;
import vfpe.editor.SyntaxLayout;

public class BindingFace extends LabelFace {

	/* constructor -------------------------------------------------- */

	protected BindingFace(String label, SyntaxLayout body) { 
		super(body," "+label+" "); cornerStyle = Bordered.LOSENGE;
	}
}
