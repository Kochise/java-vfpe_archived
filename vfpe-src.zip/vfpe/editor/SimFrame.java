/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1998-1999
*/

package vfpe.editor;

import jkk.gui.GridBagPanel;
import jkk.gui.ToolTipButton;

public class SimFrame extends ExpFrame {
	private static final String FRAME_TITLE = "PGR Simulation";

	public SimFrame(SyntaxLayout sl) {
		super(FRAME_TITLE,sl);
		add(new SimControls(),"East");
		pack();
	}
}

class SimControls extends GridBagPanel {

}
