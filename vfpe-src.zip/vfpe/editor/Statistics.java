/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 2000
*/

package vfpe.editor;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.util.Enumeration;
import java.util.Vector;

import vfpe.editor.Config;
import jkk.IntTable;

public class Statistics {
	public static final long serialVersionUID = 1;

	////////////
	// constants

	public static final String TIMING_FILE = "typecheck-timings-";

	////////////////
	// static fields

	public static PrintStream out = System.out;

	/* these are
		create attach grow shrink reorder detach copy rename
	*/
	public static IntTable categories = new IntTable();

	/* these are
		create-
			literal guards datatype patterns list
			lambda apply let if load var
		attach
			value binding empty-let
		grow-
			let array guard list pattern
		shrink-
			let array guard list pattern
		reorder-
			array guard list pattern
		detach-
			value binding empty-let
		rename-
			binding
		copy
			value
	*/
	public static IntTable operations = new IntTable();

	/* these are
		shrink-let-safe shrink-let-undef
		detach-binding-safe detach-binding-undef
		create-var-function create-var-apply
		grow-let-function grow-let-value
		create-prim-var create-user-var
	*/
	public static IntTable variants = new IntTable();
		
	public static long timerStart = 0;
	public static Vector timings = new Vector();

	/////////////////////
	// data input methods

	public static void addOp(String cat, String op) {
       if(Config.recordStats) {
            categories.add(cat,1);
            if(op != null)
                operations.add(cat+"-"+op,1);
        }
	}

	public static void addVariant(String v) {
		if(Config.recordStats) {
			variants.add(v,1);
		}
	}

	public static void startTiming() {
		timerStart = System.currentTimeMillis();
	}

	public static void addTiming(String category) {
		if(Config.recordStats) {
			long millis = System.currentTimeMillis() - timerStart;
			IntTable nds = Editor.countNodes();
			timings.addElement(new TypecheckTiming(millis,nds.sum(),category));
		}
	}

	public static String rebuildTypes(String cat) {
		timerStart = System.currentTimeMillis();
		String r = Editor.rebuildTypes();
		addTiming(cat);
		return r;
	}

	//////////
	// control

	public static void reset() {
		categories = new IntTable();
		operations = new IntTable();
		variants = new IntTable();
		timings = new Vector();
	}

	////////////////////
	// reporting methods

	public static void dump() {
		dumpCategories();
		dumpOperations();
		dumpVariants();
		dumpTimings();
	}

	public static void dumpCategories() {
		out.println("statistics categories");
		Enumeration e = categories.keys();
		while(e.hasMoreElements()) {
			Object k = e.nextElement();
			out.println("statistics category " + k + " = " +
				categories.getVal(k));
		}
	}

	public static void dumpOperations() {
		out.println("statistics operations");
		Enumeration e = operations.keys();
		while(e.hasMoreElements()) {
			Object k = e.nextElement();
			out.println("statistics operation " + k + " = " +
				operations.getVal(k));
		}
	}

	public static void dumpVariants() {
		out.println("statistics variants");
		Enumeration e = variants.keys();
		while(e.hasMoreElements()) {
			Object k = e.nextElement();
			out.println("statistics variant " + k + " = " +
				variants.getVal(k));
		}
	}
	
	public static void dumpTimings() {
		int n = 0;
		while((new File(TIMING_FILE+n)).exists()) n++;
		try {
			FileOutputStream fos = new FileOutputStream(TIMING_FILE+n);
			OutputStreamWriter osw = new OutputStreamWriter(fos);
			TypecheckTiming tt;
			osw.write("typecheck timings: ");
			osw.write("(time in milliseconds, node count, operation category)\n");
			for(int i=0;i < timings.size();i++) {
				tt = (TypecheckTiming)timings.elementAt(i);
				osw.write(tt.toString()); osw.write("\n");
			}
			osw.flush(); osw.close();
		} catch(IOException ioe) {
			ioe.printStackTrace();
		}
	}
}

class TypecheckTiming {
	public static final String DELIM = " ";
	public long millis;
	public int nodes;
	public String category;
	public String operation;

	public TypecheckTiming(long millis, int nodes, String category) {
		this.millis = millis; this.nodes = nodes; this.category = category;
	}

	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append(millis); sb.append(DELIM);
		sb.append(nodes); sb.append(DELIM);
		sb.append(category);
		return sb.toString();
	}
}
