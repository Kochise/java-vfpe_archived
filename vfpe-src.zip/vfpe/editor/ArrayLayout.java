/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1998
*/

package vfpe.editor;

import java.awt.Checkbox;
import java.awt.Component;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.Vector;

import jkk.gui.ToolTipButton;
import vfpe.syntax.Array;
import vfpe.syntax.BtmVal;
import vfpe.syntax.Value;
import vfpe.type.Type;

public class ArrayLayout extends ValueLayout implements NowShowingLayout {
    public static final long serialVersionUID = 1;
    
    public Array array;
    protected int nShowing;
    protected boolean showAll;

    public ArrayLayout(Array array) {
        super(array); this.array = array; nShowing = -1;
    }

    protected String syntaxName() { return "array"; }

    protected SyntaxFace makeFace() {
        return new FocusFace(this,(Image)Config.iconLib.get("array"));
    }

    protected Vector layoutChildren() {
        Vector v = new Vector();
        if(array.arity() > 0) {
            if(showAll) {
                for(int i=0;i < array.arity();i++)
                    v.addElement(array.arg(i));
            } else {
                if(nShowing < 0) nShowing = 0;
                    v.addElement(array.arg(nShowing));
            }
        }
        return v;
    }

    protected Component makeControls() {
        return new ArrayControl(this);
    }

    /* control effects */

    public String nowShowing() {
        if(showAll)
            return "all";
        if(array.arity() > 0) {
            if(nShowing < 0) nShowing = 0;
            return " " + (nShowing+1) + " of " + array.arity();
        } else
            return "empty array";
    }

    public void leftArrowClick() {
        if(showAll) return;
        if(array.arity() == 0) return;
        array.arg(nShowing).layoutInfo.removeFaces();
        nShowing = jkk.math.Lib.mod(nShowing-1,array.arity());
        replaceMe(this);
    }

    public void rightArrowClick() {
        if(showAll) return;
        if(array.arity() == 0) return;
        array.arg(nShowing).layoutInfo.removeFaces();
        nShowing = jkk.math.Lib.mod(nShowing+1,array.arity());
        replaceMe(this);
    }

    public void showChild(Value v) {
        nShowing = ((Value)syntax).whatNumberIsChild(v);
    }
}

class ArrayControl extends ValueControl implements ItemListener {
    private static final String DEL_VAL_LABEL = "delete element";
    private static final String ADD_VAL_AFTER = "add element after";
    private static final String SWAP_WITH_NEXT = "swap with next";
    private static final String SHOWALL_CHECKBOX_LABEL =
        "show all";
        
    ArrayLayout al;
    private Checkbox showBox;
    
    ArrayControl(SyntaxLayout sl) {
        super(sl);
        al = (ArrayLayout)sl;
        ToolTipButton b = new ToolTipButton(Editor.sharedInstance,
            DEL_VAL_LABEL,null);
        cp.add(b,"position=0,4,2,1");
        b.addActionListener(this);
        b = new ToolTipButton(Editor.sharedInstance,
            ADD_VAL_AFTER,null);
        cp.add(b,"position=2,4,2,1");
        b.addActionListener(this);
        b = new ToolTipButton(Editor.sharedInstance,
            SWAP_WITH_NEXT,null);
        cp.add(b,"position=4,4,2,1");
        b.addActionListener(this);

        showBox = new Checkbox(SHOWALL_CHECKBOX_LABEL,
            al.showAll);
        showBox.setBackground(Config.faceColour);
        cp.add(showBox,"position=0,5,6,1");
        showBox.addItemListener(this);
    }

    /* event handling */

    public void actionPerformed(ActionEvent event) {
        String cmd = event.getActionCommand();
        Array array = (Array)al.syntax;

        if(cmd.equals(DEL_VAL_LABEL)) {
            if(al.nShowing == -1) {
                Editor.showMessage("Nothing to delete"); return;
            }
            array.arg(al.nShowing).layoutInfo.removeFaces();
            array.deleteArg(al.nShowing);
            if(al.nShowing >= array.arity())
                al.nShowing = array.arity()-1;
            al.replaceMe(al); close = true;
            Statistics.addOp("shrink","array");
// OPTIMISATION - cut optimisation
            if(Editor.typeless) Editor.goTyped();
            Statistics.rebuildTypes("shrink");
        } else if(cmd.equals(ADD_VAL_AFTER)) {
            BtmVal newEl = new BtmVal();
            array.addArgAt(newEl,al.nShowing+1);
            if(al.nShowing >= 0)
                array.arg(al.nShowing).layoutInfo.removeFaces();
            al.nShowing++;
            Statistics.addOp("grow","array");

            String r = null;
            if(Editor.typeless || !Config.optimiseGrow) {
                Editor.goTyped(); r = Statistics.rebuildTypes("grow");
            } else {
                // must be array type
                Statistics.startTiming();
                Type lt = Editor.types.getType(array);
                Type lbt = lt.args[0];
                Editor.types.setType(newEl,lbt);
                Statistics.addTiming("grow");
            }
            if(r != null) {
                Thread.dumpStack();
                Editor.panic("Universe out of alignment error (see stack trace)");
            }

            al.replaceMe(al); close = true;
        } else if(cmd.equals(SWAP_WITH_NEXT)) {
            if(array.arity() < 2) {
                Editor.showMessage("swap with what ?"); return;
            }
            int next = (al.nShowing+1) % array.arity();
            Value first = array.arg(al.nShowing);
            array.arg(al.nShowing).layoutInfo.removeFaces();
            array.deleteArg(al.nShowing);
            array.addArgAt(first,next);
            al.replaceMe(al);
            Statistics.addOp("reorder","array");
        }

        super.actionPerformed(event);
    }

    public void itemStateChanged(ItemEvent event) {
        al.removeChildFaces();
        al.showAll = showBox.getState();
        al.replaceMe(al);
    }
}

