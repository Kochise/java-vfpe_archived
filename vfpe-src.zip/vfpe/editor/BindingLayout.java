/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997-1998
*/

package vfpe.editor;

import java.awt.Component;
import java.util.Vector;

import vfpe.syntax.AppVal;
import vfpe.syntax.Binding;
import vfpe.syntax.BtmVal;
import vfpe.syntax.ConstBind;
import vfpe.syntax.Value;
import vfpe.type.Type;
import vfpe.editor.BindingControl;
import vfpe.editor.SyntaxLayout;

public class BindingLayout extends SyntaxLayout {
	public static final long serialVersionUID = 1;

	public BindingLayout(Binding bv) { super(bv); }

	protected String syntaxName() { return "generic binding"; }

	protected String getTypeString() {
		// if we ever make "ConstBindLayout" this should be moved
		if(syntax instanceof ConstBind)
			return ((ConstBind)syntax).tstr;
		Type t = Editor.types.getType(syntax);
		if(t == null)
			return NO_TYPE_STRING;
		else
			return t.writeType();
	}
	
	protected SyntaxFace makeFace() { 
		return new BindingFace(((Binding)syntax).name,this);
	}

	protected Component makeControls() {
		return new BindingControl(this);
	}

	public SyntaxLayout findVisibleParent() {
		if(face == null)
			return ((Binding)syntax).parent.layoutInfo.findVisibleParent();
		else
			return this;
	}

	protected Vector layoutChildren() { return new Vector(); }

	protected int spineLink() { return NO_SPINE; }

	protected void drawIncomingLinks() {
		Binding b = (Binding)syntax;
		SyntaxLayout bpl = (SyntaxLayout)b.parent.layoutInfo;
		bpl.drawLinks();
	}
	
	/* edit operation handling */
	
	protected void click() {
		Value v = null;
		Binding b = (Binding)syntax;
		if(Config.applyVars) {
			v = new AppVal(); v.addBody(b.makeVar());
			Type t;
			if(b instanceof ConstBind)
				t = Type.parseType(((ConstBind)b).tstr);
			else
				t = Editor.types.getType(b);
			int arity = t.funArity();
			if(arity == 0) {
				v = b.makeVar();
				Statistics.addVariant("create-var-function");
			} else {
				for(int i=0;i < arity;i++)
					v.addArg(new BtmVal());
				((AppLayout)v.layoutInfo).hideApply = true;	
				Statistics.addVariant("create-var-apply");
			}
		} else {
			v = b.makeVar();
			Statistics.addVariant("create-var-function");
		}
		Editor.grab(v,true);
		Statistics.addOp("create","var");
		if(b instanceof ConstBind)
			Statistics.addVariant("create-var-prim");
		else
			Statistics.addVariant("create-var-user");
	}
}
