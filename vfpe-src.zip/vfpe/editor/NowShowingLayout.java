/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1998
*/

package vfpe.editor;

import vfpe.syntax.Value;

public interface NowShowingLayout {
	public String nowShowing();
	public void rightArrowClick();
	public void leftArrowClick();
    public void showChild(Value v);
}
