/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997-1999
*/

package vfpe.editor;

import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.util.Hashtable;
import java.util.Vector;

import vfpe.EvaluationException;
import vfpe.Reducer;
import vfpe.editor.Editor; 
import vfpe.editor.SyntaxControl;
import vfpe.editor.SyntaxLayout;
import vfpe.syntax.AbsVal;
import vfpe.syntax.BtmVal;
import vfpe.syntax.DataAbs;
import vfpe.syntax.LetAbs;
import vfpe.syntax.Syntax;
import vfpe.syntax.Value;

public abstract class ValueLayout extends SyntaxLayout {
    public static final long serialVersionUID = 1;

    public ValueLayout(Syntax syntax) {
        super(syntax);
    }

    protected Vector layoutChildren() {
        Value v = (Value)syntax;
        Vector c = new Vector();
        if(v.args.size() > 0) {
            c.addElement(v.body());
            for(int i=0;i < v.arity();i++)
                c.addElement(v.arg(i));
        }
        return c;
    }

    protected int spineLink() { return NO_SPINE; }

    protected void drawIncomingLinks() {
        Value v = (Value)syntax;
        v.parent.layoutInfo.drawLinks();
    }

    protected void drawLinks() {
        if(face == null)
            drawIncomingLinks();
        else
            super.drawLinks();
    }

    protected Component makeControls() {
        return new ValueControl(this);
    }

    public SyntaxLayout findVisibleParent() {
        if(face == null)
            return ((Value)syntax).parent.layoutInfo.findVisibleParent();
        else
            return this;
    }

    /* click -------------------------------------------------- */

    protected void click() {
        Value gv = (Value)Editor.getGrabbed();
        if(gv == null) {
            if(face != null && face.isVisible()) {
                Editor.select(face);
            }
            return;
        }
        handleDrop(gv,Editor.sharedInstance.grabIsTyped);
    }
    
    protected void handleDrop(Value gv, boolean typed) {
        if(gv.emptyBodyDroppable()) {
            if(!(gv.body() instanceof BtmVal) ||
                gv.arity() > 0) {
                Editor.showMessage("I'll only introduce empty abstractions here");
                return;
            }
            Value newBody = (Value)this.syntax;
            newBody.replace(gv);
            gv.body().replace(newBody);
            replaceMe(gv.layoutInfo);
            Editor.types.setType(gv,Editor.types.getType(this.syntax));
            Editor.drop();
            Statistics.addOp("attach","empty-let");
        }
    }
    
    public void cut() {
        if(Editor.getGrabbed() != null) return;
        Value oldVal = (Value)syntax;
        BtmVal replacement = new BtmVal();
        oldVal.replace(replacement);

        /* this type check should be superfluous */

        String res = null;
        if(Editor.typeless) Editor.goTyped();
        res = Statistics.rebuildTypes("detach");
        if(res != null) {
            /* type inference failure */
            Editor.panic("Oh dear... undefinition cause type error: " + res);
        } else {
            /* success, rebuild faces */
            replaceMe(replacement.layoutInfo);
            Editor.grab(oldVal);
            Statistics.addOp("detach","value");
        }
    }

    public boolean handleValueOp(String cmd, Reducer r) {
        if(cmd.equals(ValueControl.CUT_LABEL)) {
            cut(); return true;
        } else if(cmd.equals(ValueControl.COPY_LABEL)) {
            if(Editor.getGrabbed() != null) return false;
            Editor.grab(syntax.copy(false));
            Statistics.addOp("copy","value");
            return true;
        } else if(cmd.equals(ValueControl.REDUCE_LABEL) ||
            cmd.equals(ValueControl.EVAL_LABEL)) {
            
            boolean step = cmd.equals(ValueControl.REDUCE_LABEL);
            Value v = (Value)syntax;
            if(v.parent == null) {
                Editor.showMessage("Value doesn't have parent ..."); return false;
            }

            // Actual evaluation

            Value res = null;
            Cursor oldCursor = Editor.sharedInstance.getCursor();
            Editor.setCursorOnAll(Editor.waitCursor);
            try {
                res = v.runReduction(r,step);
            } catch(EvaluationException ee) {
                Editor.showAlert("Program error: " + ee.getMessage() +
                    "\nAborting.");
// FEATURE could try and do some last-known-good thing here
                return false;
            } finally {
                Editor.setCursorOnAll(oldCursor); 
            }
            if(r.message.equals("")) {
                Editor.showMessage("Expression in normal form");
            } else {
                Editor.showMessage(r.message);
            }
            Editor.deselect();
            doReplacement(res, r, step);
            if(res.layoutInfo.face != null && res.layoutInfo.face.isVisible())
                Editor.select(res.layoutInfo.face);
            return true;
        } else
            return false;
    }

    public void doReplacement(Value res, Reducer r, boolean step) {
        Value v = (Value)syntax;
        v.replace(res);
        for(int i=0;i < r.mutationRoot.size();i++) {
            Syntax m = (Syntax)r.mutationRoot.elementAt(i);
            Syntax o = (Syntax)r.oldMutationRoot.elementAt(i);
            o.layoutInfo.replaceMe(m.layoutInfo,false);
        }
        this.replaceMe(res.layoutInfo,false);
        Editor.redrawAll();

        for(int i=0;i < r.mutationRoot.size();i++) {
            Syntax m = (Syntax)r.mutationRoot.elementAt(i);
            if(m.layoutInfo.face != null)
                m.layoutInfo.face.setBackground(Color.red);
        }

        /*    we may want to do something more sophisticated,
            using the reducer's mutationRoot field to figure out
            which panels to redraw */

        /* can we get away with restriced type inference here ? */
        Editor.typeless = true;
    }
    
}

