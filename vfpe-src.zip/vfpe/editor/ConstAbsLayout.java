/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997-1998
*/

package vfpe.editor;

import java.awt.Component;
import java.awt.Image;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import jkk.gui.ToolTipButton;
import vfpe.editor.LabelFace;
import vfpe.editor.SyntaxFace;
import vfpe.editor.SyntaxControl;
import vfpe.editor.SyntaxLayout;
import vfpe.editor.ValueLayout;
import vfpe.editor.ValueControl;
import vfpe.syntax.ConstAbs;
import vfpe.syntax.ConstBind;

public class ConstAbsLayout extends ValueLayout {
	public static final long serialVersionUID = 1;
	
	protected ConstBind showingBind = null;
	
	public ConstAbsLayout(ConstAbs cbs) { super(cbs); }

	/* overridden tool stuff */

	protected String syntaxName() { return "prelude"; }

	protected Vector layoutChildren() {
		Vector v = super.layoutChildren();
		if(showingBind != null)
			v.addElement(showingBind);
		return v;
	}

	protected int spineLink() { return LEFT_SPINE; }

	protected SyntaxFace makeFace() { 
		return new ImageFace(this,(Image)Config.iconLib.get("prelude"));
	}

	protected Component makeControls() {
		return new ConstAbsControl(this);
	}

}

class ConstAbsControl extends ValueControl implements ItemListener {
	private static final String SHOW_BUTTON_LABEL = "show binding";
	private static final String HIDE_BUTTON_LABEL = "hide binding";
	
	private List bindList;
	private ConstAbsLayout cal;
	private ConstAbs cabs;

	public ConstAbsControl(SyntaxLayout sl) {
		super(sl); cal = (ConstAbsLayout)sl;
		cabs = (ConstAbs)cal.syntax;

		/* add controls */

		ToolTipButton sb = new ToolTipButton(Editor.sharedInstance,
			SHOW_BUTTON_LABEL,null);
		cp.add(sb,"position=0,4,3,1");
		sb.addActionListener(this);
		sb = new ToolTipButton(Editor.sharedInstance,
			HIDE_BUTTON_LABEL,null);
		cp.add(sb,"position=3,4,3,1");
		sb.addActionListener(this);
		
		bindList = new List();
		cp.add(bindList,"position=0,5,6,3");
		bindList.addActionListener(this);

		Enumeration e = cabs.defs.keys();
		while(e.hasMoreElements()) 
			bindList.add((String)e.nextElement());	
	}

	/* event handling */
	
	public void actionPerformed(ActionEvent event) {
		super.actionPerformed(event);
		String cmd = event.getActionCommand();
		if(cmd.equals(SHOW_BUTTON_LABEL)) {
			String selString = bindList.getSelectedItem();
			if(selString == null) {
				Editor.showMessage("Show what ?"); return;
			}
			if(cal.showingBind != null)
				cal.showingBind.layoutInfo.removeFaces();
			cal.showingBind = (ConstBind)cabs.defs.get(selString);
			cal.replaceMe(cal);
			
		} else if(cmd.equals(HIDE_BUTTON_LABEL)) {
			if(cal.showingBind != null) {
				cal.showingBind.layoutInfo.removeFaces();
				cal.showingBind = null;
				cal.replaceMe(cal);
			}
		}
	}

	public void itemStateChanged(ItemEvent event) { }


}
