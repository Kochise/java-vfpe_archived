/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1998
*/

package vfpe.editor;

import java.awt.Component;
import java.awt.Dialog;
import java.awt.Frame;
import java.awt.Image;
import java.awt.Label;
import java.awt.TextArea;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.StringTokenizer;
import java.util.Vector;

import jkk.gui.GridBagPanel;
import jkk.gui.TextLabel;
import jkk.gui.ToolTipButton;
import jkk.text.Lexer;
import vfpe.syntax.DataAbs;
import vfpe.syntax.DataBind;
import vfpe.type.Type;
import vfpe.type.TypeException;

public class DataLayout extends ValueLayout {
	public static final long serialVersionUID = 1;
	
	private DataAbs dabs;
	
	public DataLayout(DataAbs dabs) { 
		super(dabs); 
		this.dabs = dabs;
	}

	/* overridden tool stuff */

	protected Vector layoutChildren() {
		Vector v = (Vector)dabs.bindings.clone();
		v.insertElementAt(dabs.body(),0);
		return v;
	}

	protected int spineLink() { return LEFT_SPINE; }

	protected String syntaxName() { return "datatype definition"; }

	protected SyntaxFace makeFace() { 
		return new ImageFace(this,(Image)Config.iconLib.get("datatyp"));
	}

	protected Component makeControls() {
		return new DataControl(this);
	}

}

class DataControl extends ValueControl {
	private static final String TYPE_CAPTION = "definition for datatype";
	private static final String ADD_LABEL = "add constructor";
	private static final String PROMPT = "Enter name and type of constructor.\n" +
		"eg Node :: (Tree a) -> a -> (Tree a) -> (Tree a)\n";
	private DataLayout dl;
	private DataAbs dabs;
	private String promptEnd;

	public DataControl(SyntaxLayout sl) {
		super(sl); dl = (DataLayout)sl;
		dabs = (DataAbs)dl.syntax;
		promptEnd = "Return type should be " + dabs.typeString;

		cp.add(new TextLabel(TYPE_CAPTION),"position=0,4,3,1");
		TextLabel cat = new TextLabel(dabs.typeString);
		cat.setBackground(Config.infoBackdropColour);
		cat.setForeground(Config.infoTextColour);
		cp.add(cat,"position=3,4,3,1");
		ToolTipButton cb = new ToolTipButton(Editor.sharedInstance,
			ADD_LABEL,null);
		cp.add(cb,"position=0,5,6,1");
		cb.addActionListener(this);
	}

	/* event handling */

	public void actionPerformed(ActionEvent event) {
		String cmd = event.getActionCommand();

		if(cmd.equals(ADD_LABEL)) {

			/* request constructor details */

			NewConstructorDialog d = new NewConstructorDialog(Editor.sharedInstance,this);
			d.setVisible(true);
			if(d.results == null) {
				Editor.showMessage("constructor addition canceled"); return;
			}

			String name = (String)d.results.firstElement();
			String pNames = (String)d.results.elementAt(1);
			
			/* build type string, so we can use the old code for checking */

			StringBuffer typeBuf = new StringBuffer();
			for(int i=2;i < d.results.size();i++) {
				typeBuf.append((String)d.results.elementAt(i));
				typeBuf.append(" -> ");
			}
			typeBuf.append(dabs.typeString);
			String typeString = typeBuf.toString();

			/* make type */

			Type parsedType = null;
			Hashtable vars = new Hashtable();
//DEBUG was
/*
			try {
				parsedType = Type.parseType(typeString,vars);
			} catch(Exception e) {
				Editor.showAlert("Can't parse a type from that"); return;
			}
*/
			parsedType = Type.parseType(typeString,vars);
			if(parsedType == null) {
				Editor.showAlert("Can't parse a type from that"); return;
			}
			
			for(Enumeration e=vars.keys();e.hasMoreElements();) {
				String v = (String)e.nextElement();
				if(!dabs.typeVarNames.contains(v)) {
					Editor.showAlert("unkown type variable " + v);
					return;
				}
			}
			
			/* everything's ok - add the binding */

			d.results.removeElementAt(0);
			d.results.removeElementAt(0);
			DataBind db =
				new DataBind(dabs,name,typeString,"user defined","("+name+")",d.results);
			db.varNames = pNames;
			dabs.bindings.addElement(db);
			dl.replaceMe(dl); close = true;
		}

		super.actionPerformed(event);
	}
}

class NewConstructorDialog extends Dialog implements ActionListener {
	private static final String CANCEL_LABEL = "Cancel";
	private static final String OK_LABEL = "OK";
	private static final String TITLE = "New Constructor";
	private static final String CON_NAME_PROMPT = "new constructor name:";
	private static final String ARG_TYPE_PROMPT = "argument types (one per line)";
	private static final String PAT_NAME_PROMPT = "default argument names (optional)";
// NOTE this should probably be in VarBind
	private static final String DEF_DEF_PAT_NAME = "_";
	
	public Vector results;
	private TextField cNameField,patNameField;
	private TextArea argArea;
	private ToolTipButton okB, cancelB;

	NewConstructorDialog(Frame parent,Component nearMe) {
		super(parent,TITLE,true);
		GridBagPanel gbp = new GridBagPanel();
		add("Center",gbp);
		gbp.add(new Label(CON_NAME_PROMPT),"position=0,0,1,1");
		gbp.add(cNameField=new TextField(),"position=1,0,1,1");
		cNameField.setBackground(Config.textBackdropColour);
		gbp.add(new Label(ARG_TYPE_PROMPT),"position=0,1,2,1");
		gbp.add(argArea=new TextArea(),"position=0,2,2,1");
		argArea.setBackground(Config.textBackdropColour);
		gbp.add(new Label(PAT_NAME_PROMPT),"position=0,3,2,1");
		gbp.add(patNameField=new TextField(),"position=0,4,2,1");
		patNameField.setBackground(Config.textBackdropColour);
		gbp.add(okB = new ToolTipButton(Editor.sharedInstance,
			OK_LABEL,null),"position=0,5,1,1");
		gbp.add(cancelB = new ToolTipButton(Editor.sharedInstance,
			CANCEL_LABEL,null),"position=1,5,1,1");
		okB.addActionListener(this);
		cancelB.addActionListener(this);
		pack();
		jkk.gui.Lib.locateNear(this,nearMe);
	}

	/* event handling */

	public void actionPerformed(ActionEvent ae) {
		if(ae.getActionCommand().equals(OK_LABEL)) {
// FEATURE should check arg types and default names
			// constructor name
			results = new Vector();
			results.addElement(cNameField.getText());

			// count args
			StringTokenizer argToks = new StringTokenizer(argArea.getText(),"\n");
			int arity = argToks.countTokens();

			// default pattern names
			String pNames = patNameField.getText();
			StringTokenizer patNames = new StringTokenizer(pNames);
			int pCount = patNames.countTokens();
			for(int i=0;i < arity-pCount;i++)
				pNames += " "+DEF_DEF_PAT_NAME;
			results.addElement(pNames);
				
			// arg type strings
			while(argToks.hasMoreTokens())
				results.addElement(argToks.nextToken());
		}
		setVisible(false); dispose();
	}
}
