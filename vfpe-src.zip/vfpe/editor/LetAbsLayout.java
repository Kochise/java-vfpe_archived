/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997-1999
*/

package vfpe.editor;

import java.awt.Checkbox;
import java.awt.Component;
import java.awt.Dialog;
import java.awt.Image;
import java.awt.Label;
import java.awt.List;
import java.awt.TextComponent;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.StringTokenizer;
import java.util.Enumeration;
import java.util.Vector;

import jkk.gui.GridBagPanel;
import jkk.gui.ToolTipButton;
import vfpe.editor.Config;
import vfpe.editor.ExpFrame;
import vfpe.editor.ImageFace;
import vfpe.editor.ValueLayout;
import vfpe.syntax.AbsVal;
import vfpe.syntax.Binding;
import vfpe.syntax.Patterns;
import vfpe.syntax.Value;
import vfpe.syntax.VarBind;
import vfpe.syntax.LetAbs;
import vfpe.syntax.Syntax;
import vfpe.type.TypeException;

public class LetAbsLayout extends ValueLayout {
    public static final long serialVersionUID = 1;
    
    protected boolean bindingBranches = false;
    protected boolean listBindings = true;

    public LetAbsLayout(LetAbs labs) { super(labs); }

    public void updateFrom(SyntaxLayout template) {
        if(template instanceof LetAbsLayout) {
            bindingBranches = ((LetAbsLayout)template).bindingBranches;
            listBindings = ((LetAbsLayout)template).listBindings;
        }
    }

    /* tools */

    public void showDef(int i) {
        LetAbs labs = (LetAbs)syntax;
        Binding targetBinding = labs.binding(i);
        BindingLayout bl = (BindingLayout)targetBinding.layoutInfo;

        if(!bindingBranches) {
            if(bl.faceFrame == null) {        
                ExpFrame f = new ExpFrame("definition of " +
                    targetBinding.getName(),bl);
                f.pack();
                f.setVisible(true);
            } else {
                bl.faceFrame.toFront();
            }
        }
    }

    protected void addBinding(Component near) {
        LetAbs labs = (LetAbs)this.syntax;
        NewBindingRequester nbr = new NewBindingRequester(near);
        nbr.setVisible(true);
        String bName = nbr.getString();
        if(bName == null) {
            Editor.showMessage("Binding addition canceled"); return;
        }
        StringTokenizer toks = new StringTokenizer(bName);
        if(toks.countTokens() < 1) {
            Editor.showMessage("Binding addition canceled"); return;
        }
        String fName = toks.nextToken();
        Vector varNames = new Vector();
        while(toks.hasMoreTokens())
           varNames.addElement(toks.nextToken());
        if(nbr.getMakePatterns()) {
            if(varNames.size() < 1) {
                Editor.showMessage("Patterns must have at least one var");
                return;
            }
            labs.addBindingWithValue(fName,
                new Patterns(varNames.size(),varNames));
            Statistics.addVariant("grow-let-function");
        } else {
            labs.addBinding(fName,varNames);
            Statistics.addVariant("grow-let-value");
        }

        String r = null;
        if(Editor.typeless || !Config.optimiseGrow) {
            Editor.goTyped(); r = Statistics.rebuildTypes("grow");
        } else {
            Statistics.startTiming();
            Binding b = (Binding)labs.bindings.lastElement();
            Value bd = (Value)labs.args.lastElement();
            try {
                b.inferBindingType(Editor.types);
                bd.inferType(Editor.types);
                bd.narrowBindingType(Editor.types);
            } catch(TypeException te) {
                r = te.explain();
            }
            Statistics.addTiming("grow");
        }
        if(r != null) {
            Thread.dumpStack();
            Editor.panic("Universe out of alignment error (see stack trace)");
        }
        if(near instanceof LetAbsControl) {
            List bindingList = ((LetAbsControl)near).bindingList;
            bindingList.add(fName);
            bindingList.select(bindingList.getItemCount()-1);
        }
        this.replaceMe(this);
        Statistics.addOp("grow","let");
    }

    /* overridden tool stuff */

    protected String syntaxName() { return "let expression"; }

    protected Vector layoutChildren() {
        Vector v = new Vector();
        LetAbs lebs = (LetAbs)syntax;
        if(bindingBranches) {
            if(!Config.letBindingsOnLeft)
                v.addElement(lebs.body());
            for(int i=0;i < lebs.bindings.size();i++)
                    v.addElement(lebs.binding(i));
            if(Config.letBindingsOnLeft)
                v.addElement(lebs.body());
        } else {
            v.addElement(lebs.body());
        }
        return v;
    }

    protected int spineLink() {
        if(Config.letBindingsOnLeft)
            return RIGHT_SPINE;
        else
            return LEFT_SPINE;
    }

    protected SyntaxFace makeFace() { 
        return new LetFace(this,listBindings);
    }

    protected Component makeControls() {
        return new LetAbsControl(this);
    }

    protected void drawLinks() {
        super.drawLinks();
        LetAbs labs = (LetAbs)syntax;    
        for(int i=0;i < labs.arity();i++) {
            SyntaxLayout sl = labs.binding(i).layoutInfo;
            sl.drawLinks();
        }
    }

    public void changeBAB(boolean newBAB) {
        bindingBranches = newBAB;
        LetAbs labs = (LetAbs)syntax;
        for(int i=0;i<labs.arity();i++)
            labs.binding(i).layoutInfo.removeFaces();
        replaceMe(this);
    }

}

class LetAbsControl extends ValueControl implements ItemListener {
    private static final String NAMESPACE_BUTTON_LABEL = "namespace";
    private static final String BRANCH_CHECKBOX_LABEL =
        "bindings as branches";
    private static final String HASKELL_BUTTON_LABEL = "write haskell";
    private static final String ADD_BUTTON_LABEL = "add binding";
    private static final String DELETE_BUTTON_LABEL = "delete binding";
    private static final String SHOW_BUTTON_LABEL = "show definition";

    private static final String [] UNDEFINE_VAR_CHOICES =
        { "OK, delete them", "Cancel" };

    LetAbsLayout lal;
    private Checkbox treeBindings;
    private TextField namespaceField;
    public List bindingList;

    public LetAbsControl(SyntaxLayout sl) {
        super(sl);
        lal = (LetAbsLayout)sl;
        
        /* add controls */

        ToolTipButton ab = new ToolTipButton(Editor.sharedInstance,
            ADD_BUTTON_LABEL,null);
        cp.add(ab,"position=0,4,3,1");
        ab.addActionListener(this);
        ToolTipButton db = new ToolTipButton(Editor.sharedInstance,
            DELETE_BUTTON_LABEL,null);
        cp.add(db,"position=3,4,3,1");
        db.addActionListener(this);
        ToolTipButton sb = new ToolTipButton(Editor.sharedInstance,
            SHOW_BUTTON_LABEL,null);
        cp.add(sb,"position=0,5,6,1");
        sb.addActionListener(this);
        
        bindingList = new List();
        bindingList.setBackground(Config.textBackdropColour);
        cp.add(bindingList,"position=0,6,6,3");
        bindingList.addActionListener(this);
        
        LetAbs labs = (LetAbs)lal.syntax;
        for(int i=0;i < labs.arity();i++)
            bindingList.add(labs.binding(i).writeExp());

        treeBindings = new Checkbox(BRANCH_CHECKBOX_LABEL,
            lal.bindingBranches);
        treeBindings.setBackground(Config.faceColour);
        cp.add(treeBindings,"position=0,9,6,1");
        treeBindings.addItemListener(this);

        namespaceField = new TextField();
        namespaceField.setBackground(Config.textBackdropColour);
        cp.add(namespaceField,"position=0,10,6,1");
        namespaceField.setText(((AbsVal)lal.syntax).namespace);
    }

    /* event handling */
    
    public void actionPerformed(ActionEvent event) {
        String cmd = event.getActionCommand();
        LetAbs labs = (LetAbs)lal.syntax;
        if(cmd.equals(ADD_BUTTON_LABEL)) {
            lal.addBinding((Component)this);
        } else if(cmd.equals(DELETE_BUTTON_LABEL)) {
            int i = bindingList.getSelectedIndex();
            boolean doit = true;
            if(i == -1) {
                Editor.showAlert("Delete which binding ?"); return;
            }
            Binding targetBinding = labs.binding(i);
            Vector vars = labs.findAllVars(targetBinding);
            if(vars.size() > 0) {
                String conf = jkk.gui.Lib.requestChoice(
                    "Confirmation request", "There are instances of "+
                    "that variable in use.  Shall I undefine them ?",
                    UNDEFINE_VAR_CHOICES, Editor.sharedInstance,this);
                if(!conf.equals(UNDEFINE_VAR_CHOICES[0])) {
                    doit = false;
                } else {
                    Statistics.addVariant("shrink-let-undef");
                }
            } else {
                Statistics.addVariant("shrink-let-safe");
            }
            if(doit) {
                Value bBody = labs.arg(i);
                labs.deleteBinding(i,vars);
                String s = null;
                if(Editor.typeless || !Config.optimiseGrow) {
                    Editor.goTyped(); s = Statistics.rebuildTypes("shrink");
                } else {
                    Statistics.startTiming();
                    // technically, this leaves orphaned node types in the
                    // type inference state, but the occasional type rebuild
                    // will clean these out
                    if(vars.size() > 0)
                        s = Editor.rebuildTypes();
                    Statistics.addTiming("shrink");
                }
                if(s != null) {
                    Thread.dumpStack();
                    Editor.panic("Universe out of alignment error (see stack trace)");
                }
                bindingList.delItem(i);
                lal.replaceMe(lal);
                targetBinding.layoutInfo.removeFaces();
                bBody.layoutInfo.removeFaces();
                for(int j=0;j<vars.size();j++)
                    ((Syntax)vars.elementAt(j)).layoutInfo.removeFaces();
                Statistics.addOp("shrink","let");
            }
        } else if(cmd.equals(SHOW_BUTTON_LABEL)) {
            int i = bindingList.getSelectedIndex();
            boolean doit = true;
            if(i == -1) {
                Editor.showAlert("Show which binding ?"); return;
            }
            lal.showDef(i);
            close = true;
        }

        labs.namespace = namespaceField.getText();
        
        super.actionPerformed(event);
    }

    public void itemStateChanged(ItemEvent event) {
        lal.changeBAB(treeBindings.getState());
    }
    
}

class NewBindingRequester extends Dialog implements
    ActionListener {
        
    private static final String WINDOW_TITLE = "New Binding";
    private static final String PROMPT =
        "Enter name and arguments eg f x y z";
    private static final String CHECKBOX_LABEL = "make pattern set";
    private static final String CANCEL_LABEL = "Cancel";
    private static final String OK_LABEL = "OK";
    
    private String str = null;
    private TextComponent tf;
    private boolean makePatterns;
    private Checkbox cb;
    private ToolTipButton okB, cancelB;
    
    NewBindingRequester(Component near) {
        super(Editor.sharedInstance,WINDOW_TITLE,true);
        GridBagPanel gbp = new GridBagPanel();
        add("Center",gbp);
        
        gbp.add(new Label(PROMPT,Label.CENTER),"position=0,0,2,1");
        tf = new TextField();
        tf.setBackground(Config.textBackdropColour);
        ((TextField)tf).addActionListener(this);
        gbp.add(tf,"position=0,1,2,1");

        cb = new Checkbox(CHECKBOX_LABEL);
        gbp.add(cb,"position=0,2,2,1");
        
        gbp.add(okB = new ToolTipButton(Editor.sharedInstance,
            OK_LABEL,null),"position=0,3,1,1");
        okB.addActionListener(this);
        gbp.add(cancelB = new ToolTipButton(Editor.sharedInstance,
            CANCEL_LABEL,null),"position=1,3,1,1");
        cancelB.addActionListener(this);
        jkk.gui.Lib.locateNear(this,near);
        pack();
        addComponentListener(new ComponentAdapter() {
            public void componentShown(ComponentEvent cd) {
                tf.requestFocus();
            }
        });
    }

    public String getString() { return str; }

    public boolean getMakePatterns() { return makePatterns; }

    /* event handling */

    public void actionPerformed(ActionEvent ae) {
        if(ae.getActionCommand().equals(CANCEL_LABEL) ||
            tf.getText().equals("")) {
            str = null;
        } else {
            str = tf.getText();
        }
        makePatterns = cb.getState();
        setVisible(false); dispose();
    }
}
