/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1998
*/

package vfpe.editor;

import java.awt.Button;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.Vector;

import vfpe.syntax.Binding;
import vfpe.syntax.LetAbs;
import vfpe.syntax.PatBind;
import vfpe.syntax.Syntax;
import vfpe.syntax.Value;
import vfpe.syntax.VarBind;

public class PatBindLayout extends BindingLayout {
	public static final long serialVersionUID = 1;
	
	public PatBind pb;
	
	public PatBindLayout(PatBind pb) {
		super(pb);
		this.pb = pb;
	}

	protected String syntaxName() { return "pattern binding"; }

	protected SyntaxFace makeFace() {
		String lbl = pb.dataCon.binding.name;
		if(!pb.name.equals(""))
			lbl = pb.name + " @ " + lbl;
		if(pb.parent instanceof LetAbs)
			lbl = "match " + lbl;
		return new BindingFace(lbl,this);
	}

	protected Component makeControls() {
		return new BindingControl(this);
	}

	protected Vector layoutChildren() {
		Vector v = new Vector();
		if(Config.bindingsOnLeft) {
			for(int i=0;i < pb.bindings.size();i++)
				v.addElement(pb.binding(i));
		}
		if(pb.parent instanceof LetAbs) {
			LetAbs labs = (LetAbs)pb.parent;
			int n = labs.whatNumberIs(pb);
			v.addElement(labs.arg(n));
		}
		if(!Config.bindingsOnLeft) {
			for(int i=0;i < pb.bindings.size();i++)
				v.addElement(pb.binding(i));
		}
		return v;
	}

	public int spineLink() {
		if(!(pb.parent instanceof LetAbs))
			return SyntaxLayout.NO_SPINE;
		if(Config.bindingsOnLeft)
			return SyntaxLayout.RIGHT_SPINE;
		else
			return SyntaxLayout.LEFT_SPINE;
	}
		
}

