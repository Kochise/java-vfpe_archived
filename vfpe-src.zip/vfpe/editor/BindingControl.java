/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997-1999
*/

package vfpe.editor;

import java.awt.Checkbox;
import java.awt.event.ActionEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.Vector;

import jkk.gui.StringRequester;
import jkk.gui.ToolTipButton;
import vfpe.editor.SyntaxControl;
import vfpe.editor.SyntaxLayout;
import vfpe.syntax.AbsVal;
import vfpe.syntax.Binding;
import vfpe.syntax.Syntax;
import vfpe.syntax.VarBind;

public class BindingControl extends SyntaxControl
    implements ItemListener {
    public static final long serialVersionUID = 1;
    
    private static final String MK_VAR_LABEL = "make variable";
    private static final String RENAME_LABEL = "rename";
    private static final String DELETE_PAT_LABEL = "delete pattern";
    private static final String BREAKPOINT_LABEL = "breakpoint";

    private static final String [] UNDEFINE_VAR_CHOICES =
        { "OK, delete them", "Cancel" };
    private static final String DEF_BIND_NAME = "x";

    protected Checkbox breakCheckbox;
    BindingLayout bl;
    Binding b;
    
    public BindingControl(SyntaxLayout sl) {
        super(sl);
        bl = (BindingLayout)body;
        b = (Binding)body.syntax;

        /* binding controls */

        ToolTipButton mvb = new ToolTipButton(Editor.sharedInstance,
            MK_VAR_LABEL,null);
        cp.add(mvb,"position=0,3,2,1");
        mvb.addActionListener(this);
        ToolTipButton rb = new ToolTipButton(Editor.sharedInstance,
            RENAME_LABEL,null);
        cp.add(rb,"position=2,3,2,1");
        rb.addActionListener(this);
        ToolTipButton db = new ToolTipButton(Editor.sharedInstance,
            DELETE_PAT_LABEL,null);
        cp.add(db,"position=4,3,2,1");
        db.addActionListener(this);

        breakCheckbox = new Checkbox(BREAKPOINT_LABEL);
        breakCheckbox.setBackground(Config.faceColour);
        cp.add(breakCheckbox,"position=0,4,6,1");
        breakCheckbox.setState(b.breakpoint);
        breakCheckbox.addItemListener(this);
    }

    /* event handling */

    public void actionPerformed(ActionEvent event) {
        String cmd = event.getActionCommand();

        if(cmd.equals(MK_VAR_LABEL)) {
            body.click(); close = true;
        } else if(cmd.equals(RENAME_LABEL)) {
            StringRequester sr = new StringRequester("Rename request",
                "Enter new name",Editor.sharedInstance);
            jkk.gui.Lib.locateNear(sr,this);
            sr.tf.setBackground(Config.textBackdropColour);
            sr.setVisible(true);

            String newName = sr.getString();
            if(newName == null || newName.equals("")) {
                Editor.showMessage("Rename canceled"); return;
            }
            b.name = newName;
            AbsVal absv = b.abstraction();
            Vector v = absv.findAllVars(b); v.addElement(b);
            SyntaxLayout.redoLayoutForNodes(v);
            close = true;
            Statistics.addOp("rename","binding");
        } else if(cmd.equals(DELETE_PAT_LABEL)) {
            AbsVal abs = b.abstraction();
            boolean doit = true;
            Vector vars = abs.findAllVars(b);
            if(vars.size() > 0) {
                String conf = jkk.gui.Lib.requestChoice(
                    "Confirmation request", "There are instances of "+
                    "that variable in use.  Shall I undefine them ?",
                    UNDEFINE_VAR_CHOICES, Editor.sharedInstance);
                if(!conf.equals(UNDEFINE_VAR_CHOICES[0])) {
                    doit = false;
                } else {
                    Statistics.addVariant("detach-binding-undef");
                }
            } else {
                Statistics.addVariant("detach-binding-safe");
            }
            if(doit) {
                abs.removeAllVars(vars);
                VarBind vb = new VarBind(b.parent,DEF_BIND_NAME);
                b.replace(vb);
// this probably needs to be generalised
                SyntaxLayout sl = abs.layoutInfo.findVisibleParent();
                sl.replaceMe(sl);
                for(int j=0;j<vars.size();j++)
                    ((Syntax)vars.elementAt(j)).layoutInfo.removeFaces();
                b.layoutInfo.removeFaces();
                Statistics.addOp("detach","binding");
                if(Editor.typeless)
                    Editor.goTyped();
                String s = Statistics.rebuildTypes("detach");
// NOTE - remove type of b from itypes
                if(s != null) {
                    Thread.dumpStack();
                    Editor.panic("Universe out of alignment error (see stack trace)");
                }
                close = true;
            }

        }

        super.actionPerformed(event);
    }

    public void itemStateChanged(ItemEvent ie) {
        if(ie.getSource().equals(breakCheckbox)) {
            b.breakpoint = breakCheckbox.getState();
        }
    }
}
