/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997-1999
*/

package vfpe.editor;

import java.awt.Component;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.util.StringTokenizer;
import java.util.Vector;

import jkk.gui.StringRequester;
import jkk.gui.ToolTipButton;
import vfpe.editor.BindingControl;
import vfpe.editor.Config;
import vfpe.editor.ImageFace;
import vfpe.editor.ValueLayout;
import vfpe.syntax.LamAbs;
import vfpe.syntax.Patterns;
import vfpe.syntax.Value;

public class LamAbsLayout extends ValueLayout {
	public static final long serialVersionUID = 1;

// NOTE this should probably be in VarBind
	public static final String DEF_PAT_NAME = "_";

	public LamAbsLayout(LamAbs labs) { super(labs); }

	protected String syntaxName() { return "lambda abstraction"; }

	protected SyntaxFace makeFace() { 
		return new ImageFace(this,(Image)Config.iconLib.get("lambda"));
	}

	protected Vector layoutChildren() {
		Vector v = new Vector();
		LamAbs labs = (LamAbs)syntax;
		if(!Config.bindingsOnLeft)
			v.addElement(labs.body());
		for(int i=0;i < labs.bindings.size();i++)
				v.addElement(labs.binding(i));
		if(Config.bindingsOnLeft)
			v.addElement(labs.body());
		return v;
	}

	protected int spineLink() {
		if(Config.bindingsOnLeft)
			return RIGHT_SPINE;
		else
			return LEFT_SPINE;
	}

	protected void handleDrop(Value gv, boolean typed) {
		LamAbs newBody = (LamAbs)syntax;
		if(gv instanceof Patterns) {
			Patterns pats = (Patterns)gv;
			pats.nArgs = newBody.bindings.size();
			newBody.replace(pats);
			pats.setArg(newBody,0);
			replaceMe(pats.layoutInfo);
			Editor.types.setType(pats,Editor.types.getType(this.syntax));
			Editor.drop();
		} else {
			super.handleDrop(gv,typed);
		}
	}

	/* tool for making a LamAbs, possibly prompting for arg names */

	protected static LamAbs makeLamAbs(Component near, int arity) {
		String vNames = null;
		if(arity == -1 || Config.promptForPatNames) {
			StringRequester sr = new StringRequester("New Lambda",
                "Enter binding names eg x y z",Editor.sharedInstance);
            jkk.gui.Lib.locateNear(sr,near);
            sr.tf.setBackground(Config.textBackdropColour);
            sr.setVisible(true);
			vNames = sr.getString();
		} else {
			vNames = "";
			for(int i=0;i < arity;i++)
				vNames += " "+DEF_PAT_NAME;
		}
		if(vNames == null || vNames.equals("")) return null;
		StringTokenizer toks = new StringTokenizer(vNames);
		if(toks.countTokens() < 1) return null;
		Vector varNames = new Vector();
		while(toks.hasMoreTokens())
			varNames.addElement(toks.nextToken());
		return new LamAbs(varNames.size(),varNames);
	}

	protected Component makeControls() {
		return new LamAbsControl(this);
	}
			
}

class LamAbsControl extends ValueControl {
	private static final String CURRY_LABEL = "curry";
	private static final String UNCURRY_LABEL = "uncurry";

	protected LamAbsLayout lal;
	
	LamAbsControl(LamAbsLayout lal) {
		super(lal);
		this.lal = lal;

		/* controls */

		ToolTipButton b = new ToolTipButton(Editor.sharedInstance,
			CURRY_LABEL,null);
		cp.add(b,"position=0,4,3,1");
		b.addActionListener(this);
		b = new ToolTipButton(Editor.sharedInstance,
			UNCURRY_LABEL,null);
		cp.add(b,"position=3,4,3,1");
		b.addActionListener(this);
	}

	/* event handling */

	public void actionPerformed(ActionEvent ae) {
		String cmd = ae.getActionCommand();
		LamAbs labs = (LamAbs)lal.syntax;
		if(cmd.equals(CURRY_LABEL)) {
			if(labs.bindings.size() < 2) {
				Editor.showMessage("Nothing to split");
				return;
			}
			labs.body().layoutInfo.removeFaces();
			labs.curry();
			lal.replaceMe(lal);
		} else if(cmd.equals(UNCURRY_LABEL)) {
			Value b = labs.body();
			if(!(b instanceof LamAbs)) {
				Editor.showMessage("Nothing to merge");
				return;
			}
			labs.uncurry();
			b.layoutInfo.removeFaces();
			lal.replaceMe(lal);
		}

		super.actionPerformed(ae);
	}

}
