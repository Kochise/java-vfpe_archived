/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997-1999
*/

package vfpe.editor;

import java.awt.event.ActionEvent;

import jkk.gui.ToolTipButton;
import vfpe.editor.Editor; 
import vfpe.editor.SyntaxControl;
import vfpe.editor.SyntaxLayout;
import vfpe.syntax.AbsVal;
import vfpe.syntax.BtmVal;
import vfpe.syntax.Syntax;
import vfpe.syntax.Value;

class ValueControl extends SyntaxControl {
	protected static final String CUT_LABEL = "cut";
	protected static final String COPY_LABEL = "copy";
	protected static final String REDUCE_LABEL = "reduce";
	protected static final String EVAL_LABEL = "evaluate";
	
	ValueControl(SyntaxLayout sl) {
		super(sl);

		ToolTipButton cb = new ToolTipButton(Editor.sharedInstance,
			Config.getIcon("Cut"),CUT_LABEL);
		cp.add(cb,"position=0,3,2,1"); 
		cb.tipBackground = Config.infoBackdropColour;
		cb.addActionListener(this); cb.setCommand(CUT_LABEL);
		cb = new ToolTipButton(Editor.sharedInstance,
			Config.getIcon("Copy"),COPY_LABEL);
		cp.add(cb,"position=2,3,2,1");
		cb.tipBackground = Config.infoBackdropColour;
		cb.addActionListener(this); cb.setCommand(COPY_LABEL);
		cb = new ToolTipButton(Editor.sharedInstance,
			Config.getIcon("Reduce"), REDUCE_LABEL);
		cp.add(cb,"position=4,3,1,1");
		cb.tipBackground = Config.infoBackdropColour;
		cb.addActionListener(this); cb.setCommand(REDUCE_LABEL);
		cb = new ToolTipButton(Editor.sharedInstance,
			Config.getIcon("Evaluate"), EVAL_LABEL);
		cp.add(cb,"position=5,3,1,1");
		cb.tipBackground = Config.infoBackdropColour;
		cb.addActionListener(this); cb.setCommand(EVAL_LABEL);
	}

	/* event handling */

	public void actionPerformed(ActionEvent event) {
		String cmd = event.getActionCommand();

		if(((ValueLayout)body).handleValueOp(cmd,Editor.makeReducer()))
			close = true;

		super.actionPerformed(event);
	}
}
