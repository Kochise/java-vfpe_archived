/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1998-1999
*/

package vfpe.editor;

import java.awt.Checkbox;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.StringTokenizer;
import java.util.Vector;

import jkk.gui.StringRequester;
import vfpe.syntax.AppVal;
import vfpe.syntax.Binding;
import vfpe.syntax.Const;
import vfpe.syntax.ConstBind;
import vfpe.syntax.LamAbs;
import vfpe.syntax.LetAbs;
import vfpe.syntax.Literal;
import vfpe.syntax.LitBind;
import vfpe.syntax.PatBind;
import vfpe.syntax.Syntax;
import vfpe.syntax.Value;
import vfpe.syntax.VarBind;
import vfpe.type.DerivedState;
import vfpe.type.Substitution;
import vfpe.type.Type;
import vfpe.type.TypeException;
import vfpe.type.TypeInferenceState;

public class VarBindLayout extends BindingLayout {
	public static final long serialVersionUID = 1;

	protected boolean hideLambda = true;
		
	public VarBindLayout(VarBind bv) { super(bv); }

	protected String syntaxName() { return "variable binding"; }

	protected SyntaxFace makeFace() { 
		return new BindingFace(((Binding)syntax).name,this);
	}

	protected Component makeControls() {
		return new VarBindControl(this);
	}

	protected Vector layoutChildren() {
		Binding b = (Binding)syntax;
		Vector v = new Vector();
		if(b.parent instanceof LetAbs) {
			LetAbs labs = (LetAbs)b.parent;
			int n = labs.whatNumberIs(b);
			if(n < 0) return v;
			Value vn = labs.arg(n);
			if(hideLambda) {
				if(!(vn instanceof LamAbs)) {
					hideLambda = false;
					v.addElement(vn);
				} else {
					v = vn.layoutInfo.layoutChildren();
				}
			} else {
				v.addElement(vn);
			}
		}
		return v;
	}

	protected void updatePattern(Binding newPat) {
		if(Editor.typeless) {
			Editor.goTyped(); Statistics.rebuildTypes("attach");
		}

		// replace pattern
		
		VarBind vb = (VarBind)syntax;
		vb.replace(newPat);

		// type check
		
		String res = null;
		if(Config.optimiseAttach) {
			Statistics.startTiming();
			DerivedState itypes = new DerivedState(Editor.types);
			// we should always be able to build this type
			try {
				newPat.inferBindingType(itypes);
			} catch(TypeException te) {
				Editor.panic("can't build type for new pattern " + newPat);
			}
			try {
				Substitution subs = Type.unify(
					itypes.getType(newPat),itypes.getType(vb));
				itypes.substitute(subs);
				newPat.narrowBindingType(itypes);
				itypes.commit();
			} catch(TypeException te) {
				res = "type mismatch during construction: " + te.explain();
			}
			Statistics.addTiming("attach");
		} else {
			res = Statistics.rebuildTypes("attach");
		}

		if(res != null) {
			Editor.showAlert(res);
			newPat.replace(vb); return;
		} else {
			this.replaceMe(newPat.layoutInfo);
			Editor.drop(); Editor.showMessage("Pattern build successful");
			Statistics.addOp("attach","binding");
			return;
		}
	}

	protected void click() {
		Syntax g = Editor.getGrabbed();
		if(g == null) {
			super.click(); return;
		}
		if(g instanceof Literal) {
			try {
				LitBind lb = null;
				lb = new LitBind((Literal)g);
				updatePattern(lb);
			} catch(IllegalArgumentException e) {
				Editor.showAlert("can't make literal pattern from that");
			}
			return;
		}
		if(g instanceof AppVal)
			g = ((AppVal)g).body();
		if(g instanceof Const) {
			ConstBind cb = (ConstBind)((Const)g).binding;
			if(!cb.isData) {
				Editor.showAlert("Can't make pattern out of that");
				return;
			}
			Type t = Type.parseType(cb.tstr);
			int n = t.funArity();
			Vector vNames = new Vector();
			if(n > 0) {
				String aNames = null;
				if(cb.varNames != null) {
					aNames = cb.varNames;
				} else {
					StringRequester sr = new StringRequester("New Pattern",
						"Enter binding naems eg x xs", Editor.sharedInstance);
					jkk.gui.Lib.locateNear(sr,face);
					sr.tf.setBackground(Config.textBackdropColour);
					sr.setVisible(true);
					aNames = sr.getString();
				}
				if(aNames == null || aNames.equals("")) {
					Editor.showMessage("Pattern addition canceled"); return;
				}
				StringTokenizer toks = new StringTokenizer(aNames);
				while(toks.hasMoreTokens())
					vNames.addElement(toks.nextToken());
				if(vNames.size() != n) {
					Editor.showAlert("Wrong number of args");
					return;
				}
			}
			PatBind pb = new PatBind(((VarBind)syntax).parent,cb,vNames);
			updatePattern(pb);
			return;
		}
		Editor.showMessage("I don't understand that action");
	}
}

class VarBindControl extends BindingControl 
	implements ItemListener {

	private static final String HIDE_LAM_LABEL = "hide lambda";

	private Checkbox hideLamBox;

	VarBindLayout vbl;

	public VarBindControl(SyntaxLayout sl) {
		super(sl);
		vbl = (VarBindLayout)body;

		/* extra let bind controls */

		hideLamBox = new Checkbox(HIDE_LAM_LABEL,vbl.hideLambda);
		hideLamBox.setBackground(Config.faceColour);
		cp.add(hideLamBox,"position=0,5,6,1");
		hideLamBox.addItemListener(this);
	}

	public void itemStateChanged(ItemEvent event) {
		VarBind vb = (VarBind)vbl.syntax;
		if(event.getSource().equals(hideLamBox)) {
			Syntax p = vb.parent;
			Value vn = null;
			if((p instanceof LetAbs) && hideLamBox.getState()) {
				LetAbs labs = (LetAbs)p;
				int n = labs.whatNumberIs(vb);
				vn = labs.arg(n);
				if(vn instanceof LamAbs) {
					vbl.hideLambda = true;
				} else {
					Editor.showMessage("no lambda to hide");
					hideLamBox.setState(false);
					return;
				}
			} else {
				vbl.hideLambda = false;
			}
			if(hideLamBox.getState()) {
				vn.layoutInfo.removeFaces();
			}
			vbl.replaceMe(vbl);
			close = true;
			super.actionPerformed(new ActionEvent(this,0,"some shit"));
		}

		super.itemStateChanged(event);
	}
}
