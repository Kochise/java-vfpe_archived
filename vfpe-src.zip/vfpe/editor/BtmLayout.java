/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997
*/

package vfpe.editor;

import java.awt.Image;
import java.util.Vector;

import vfpe.syntax.BtmVal;
import vfpe.syntax.Syntax;
import vfpe.syntax.Value;
import vfpe.syntax.VarVal;
import vfpe.editor.ImageFace;
import vfpe.editor.ValueLayout;
import vfpe.type.DerivedState;
import vfpe.type.Substitution;
import vfpe.type.Type;
import vfpe.type.TypeException;
import vfpe.type.TypeInferenceState;

import jkk.Set;

public class BtmLayout extends ValueLayout {
    public static final long serialVersionUID = 1;

    public BtmLayout(BtmVal bv) { super(bv); }

    protected String syntaxName() { return "undefined value"; }

    protected Vector layoutChildren() {    return new Vector(); }

    protected SyntaxFace makeFace() { 
        ImageFace iFace = new ImageFace(this,(Image)Config.iconLib.get("btm"));
        return iFace;
    }

    /* event handling --------------------------------------------- */

    private static final String [] UNDEFINE_VAR_CHOICES =
        { "OK, delete them", "Cancel" };

    public void handleDrop(Value gv, boolean typed) {
        if(Editor.typeless) {
            Editor.goTyped(); Statistics.rebuildTypes("attach");
        }

        /* save old value and substitute */
        
        String res = null;
        Value oldVal = (Value)syntax;
        oldVal.replace(gv);

        /* scope check */

        Vector v = gv.findNodes("vfpe.syntax.VarVal");
        Vector nv = new Vector();
        for(int i=0;i < v.size();i++) {
            VarVal vv = (VarVal)v.elementAt(i);
            if(!vv.inScope())
                nv.addElement(vv);
        }
        if(nv.size() > 0) {
            Vector nub = (new Set(nv)).vectorise();
            StringBuffer prompt = new StringBuffer();
            prompt.append("That would take instances of the following variables " +
                "out of scope:\n");
            for(int i=0;i < nub.size();i++) {
                VarVal vv = (VarVal)nub.elementAt(i);
                prompt.append(vv.name()); prompt.append(" ");
                if(i % 4 == 3 && i < (v.size()-1))
                    prompt.append("\n");
            }
            prompt.append("\nShall I undefine them ?");
            String conf = jkk.gui.Lib.requestChoice("Confirmation Request",
                prompt.toString(), UNDEFINE_VAR_CHOICES, Editor.sharedInstance);
            if(!conf.equals(UNDEFINE_VAR_CHOICES[0])) {
                gv.replace(oldVal); return;
            } else {
                gv.removeAllVars(nv); typed = false;
            }

        }
        
        /* type check */

        if(typed && Config.optimiseAttach) {
            Statistics.startTiming();
            DerivedState itypes = new DerivedState(Editor.types);
            try {
                // We need to do this so that if this creates a recursive
                // definition, any generic types in the grabbed expression
                // become non-generic.  This should be fast, and should
                // never fail (?).
                try {
                    gv.inferType(itypes);
                } catch(TypeException te1) {
                    Editor.panic("So that can fail.  Bugger.");
                }
                Substitution subs = Type.unify(
                    itypes.getType(gv),itypes.getType(oldVal));
                itypes.substitute(subs);
                gv.narrowBindingType(itypes);
                itypes.commit();
            } catch(TypeException te) {
                res = "type mismatch during construction: " + te.explain();
            }
            Statistics.addTiming("attach");
        } else {
            res = Statistics.rebuildTypes("attach");
        }
        
        if(res != null) {
            /* type inference failure */
            Editor.showAlert(res);
            gv.replace(oldVal);
        } else {
            /* success, rebuild faces */
            oldVal.layoutInfo.replaceMe(gv.layoutInfo);
            Editor.drop();
            Editor.showMessage("Drop successful");
            Statistics.addOp("attach","value");
        }
    }
}
