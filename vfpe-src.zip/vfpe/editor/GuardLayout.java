/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1998
*/

package vfpe.editor;

import java.awt.Component;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.util.Vector;

import jkk.gui.ToolTipButton;
import vfpe.syntax.BtmVal;
import vfpe.syntax.Guards;
import vfpe.syntax.Value;
import vfpe.type.Type;

public class GuardLayout extends ValueLayout implements NowShowingLayout {
    public static final long serialVersionUID = 1;
    
    public Guards guard;
    protected int nShowing;

    public GuardLayout(Guards guard) {
        super(guard);
        this.guard = guard; nShowing = 0;
    }

    protected String syntaxName() { return "guards"; }

    protected SyntaxFace makeFace() {
        return new FocusFace(this,(Image)Config.iconLib.get("guard"));
    }

    protected Vector layoutChildren() {
        Vector v = new Vector();
        v.addElement(guard.arg(nShowing));
        v.addElement(guard.arg(nShowing+1));
        return v;
    }

    protected Component makeControls() {
        return new GuardControl(this);
    }

    /* control effects */

    public String nowShowing() {
        return " " + (nShowing/2+1) + " of " + guard.arity()/2;
    }

    public void leftArrowClick() {
        guard.arg(nShowing).layoutInfo.removeFaces();
        guard.arg(nShowing+1).layoutInfo.removeFaces();
        nShowing = jkk.math.Lib.mod(nShowing-2,guard.arity());
        replaceMe(this);
    }

    public void rightArrowClick() {
        guard.arg(nShowing).layoutInfo.removeFaces();
        guard.arg(nShowing+1).layoutInfo.removeFaces();
        nShowing = jkk.math.Lib.mod(nShowing+2,guard.arity());
        replaceMe(this);
    }

    public void showChild(Value v) {
        int n = ((Value)syntax).whatNumberIsChild(v);
        nShowing = (n/2)*2;
    }
}

class GuardControl extends ValueControl {
    private static final String DEL_GUARD_LABEL = "delete guard";
    private static final String ADD_GUARD_AFTER = "add guard after";
    private static final String SWAP_WITH_NEXT = "swap with next";
    
    GuardLayout gl;
    
    GuardControl(SyntaxLayout sl) {
        super(sl);
        gl = (GuardLayout)sl;
        ToolTipButton b = new ToolTipButton(Editor.sharedInstance,
            DEL_GUARD_LABEL,null);
        cp.add(b,"position=0,4,2,1");
        b.addActionListener(this);
        b = new ToolTipButton(Editor.sharedInstance,
            ADD_GUARD_AFTER,null);
        cp.add(b,"position=2,4,2,1");
        b.addActionListener(this);
        b = new ToolTipButton(Editor.sharedInstance,
            SWAP_WITH_NEXT,null);
        cp.add(b,"position=4,4,2,1");
        b.addActionListener(this);
    }

    /* event handling */

    public void actionPerformed(ActionEvent event) {
        String cmd = event.getActionCommand();
        Guards gds = gl.guard;

        if(cmd.equals(DEL_GUARD_LABEL)) {
            if(gds.arity() < 3) {
                Editor.showMessage("can't delete last pattern"); return;
            }
            gds.arg(gl.nShowing).layoutInfo.removeFaces();
            gds.arg(gl.nShowing+1).layoutInfo.removeFaces();
            gds.deleteArg(gl.nShowing);
            gds.deleteArg(gl.nShowing);
            if(gl.nShowing >= gds.arity())
                gl.nShowing = gds.arity()-2;
            Statistics.addOp("shrink","guard");
            if(Editor.typeless) Editor.goTyped();
            String s = Statistics.rebuildTypes("shrink");
            gl.replaceMe(gl);    close = true;
        } else if(cmd.equals(ADD_GUARD_AFTER)) {
            BtmVal newGd, newVal;
            gds.addArgAt(newVal = new BtmVal(),gl.nShowing+2);
            gds.addArgAt(newGd = new BtmVal(),gl.nShowing+2);

            String r = null;
            if(Editor.typeless || !Config.optimiseGrow) {
                Editor.goTyped(); r = Statistics.rebuildTypes("grow");
            } else {
                Statistics.startTiming();
                Editor.types.setType(newGd,new Type("Bool",0));
                Editor.types.setType(newVal,Editor.types.getType(gds));
                Statistics.addTiming("grow");
            }
            if(r != null) {
                Thread.dumpStack();
                Editor.panic("Universe out of alignment error (see stack trace)");
            }

            gl.replaceMe(gl); close = true;
            Statistics.addOp("grow","guard");
        } else if(cmd.equals(SWAP_WITH_NEXT)) {
            if(gds.arity() < 4) {
                Editor.showMessage("swap with what ?"); return;
            }
            int next = (gl.nShowing+2) % gds.arity();
            Value firstG = gds.arg(gl.nShowing);
            Value firstE = gds.arg(gl.nShowing+1);
            gds.arg(gl.nShowing).layoutInfo.removeFaces();
            gds.arg(gl.nShowing+1).layoutInfo.removeFaces();
            gds.deleteArg(gl.nShowing);
            gds.deleteArg(gl.nShowing);
            gds.addArgAt(firstE,next);
            gds.addArgAt(firstG,next);
            gl.replaceMe(gl);
            Statistics.addOp("reorder","guard");
        }

//OPTIMISATION - just build the guard and exp types
        super.actionPerformed(event);
    }    
}

