/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997
*/

package vfpe.editor;

import vfpe.editor.LabelFace;
import vfpe.editor.SyntaxFace;
import vfpe.editor.ValueLayout;
import vfpe.syntax.Literal;

public class LiteralLayout extends ValueLayout {
	public static final long serialVersionUID = 1;
	
	public LiteralLayout(Literal lit) {
		super(lit);
	}

	protected String syntaxName() { return "literal"; }

	protected SyntaxFace makeFace() {
		return new LabelFace(this,((Literal)syntax).str);
	}
}
