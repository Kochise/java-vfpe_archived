/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1998-1999
*/

package vfpe.editor;

import java.awt.Button;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dialog;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Image;
import java.awt.Label;
import java.awt.MenuItem;
import java.awt.TextField;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.StringTokenizer;
import java.util.Vector;

import jkk.gui.Bordered;
import jkk.gui.Checkbox;
import jkk.gui.GridBagPanel;
import jkk.gui.ImageLabel;
import jkk.gui.LightContainer;
import jkk.gui.MultiLineTextLabel;
import jkk.gui.StringRequester;
import jkk.gui.StringSelectorPopup;
import jkk.gui.TextEntryLine;
import jkk.gui.TextLabel;
import jkk.gui.ToolTipButton;
import vfpe.editor.Editor;
import vfpe.syntax.CondVal;
import vfpe.syntax.ConstAbs;
import vfpe.syntax.ConstBind;
import vfpe.syntax.AppVal;
import vfpe.syntax.BtmVal;
import vfpe.syntax.DataAbs;
import vfpe.syntax.Guards;
import vfpe.syntax.LamAbs;
import vfpe.syntax.LetAbs;
import vfpe.syntax.List;
import vfpe.syntax.Literal;
import vfpe.syntax.Patterns;
import vfpe.syntax.ParTuple;
import vfpe.syntax.Thread;
import vfpe.syntax.Value;
import vfpe.type.Type;

public class Pallet extends GridBagPanel implements ActionListener {

    private static final String INFO_LABEL = "Info";
    
    private static String SOURCES_LABEL = "Sources";
    private static String SOURCE_HEADER = "Syntax";
    private static final String GROUP_HEADER = "Prim Groups";
    private static final String PRIM_HEADER = "Primitives";
    
    private static String IF_BUTTON_LABEL = "if-then";
    private static String LET_BUTTON_LABEL = "let";
    private static String SELECT_ARITY_LABEL = "select arity";
    private static String APP_BUTTON_LABEL = "apply";
    private static String APP_BUTTON_PREFIX = "apply-";
    private static String LAM_BUTTON_LABEL = "lambda";
    private static String LAM_BUTTON_PREFIX = "lambda-";
    private static String LIST_BUTTON_LABEL = "list";
    private static String PAT_BUTTON_LABEL = "patterns";
    private static String PAT_BUTTON_PREFIX = "patterns-";
    private static String LOAD_BUTTON_LABEL = "load";
    private static String PRIM_BUTTON_LABEL = "primitive";
    private static String DATA_BUTTON_LABEL = "datatype";
    private static String GUARD_BUTTON_LABEL = "guards";
    private static String PAR_BUTTON_LABEL = "parallel";
    private static String PAR_BUTTON_PREFIX = "parallel-";
    private static String LIT_LABEL = "literal";
    private static String THREAD_BUTTON_LABEL = "thread";
    
    private static String SEL_GROUP_TITLE = "select group";
    private static String SEL_CONST_TITLE = "select constant";
    
    private static String SINKS_LABEL = "Sinks";
    private static String RUBBISH_BUTTON_LABEL = "Delete";
    private static String SAVE_BUTTON_LABEL = "Drop here to save";
    private static String HASKELL_BUTTON_LABEL = "Write Haskell";
    private static String DEPEND_BUTTON_LABEL = "Dependancies";
    
    private static Vector appLabels;
    private static Vector lamLabels;
    private static Vector patLabels;
    private static Vector parLabels;
    
    static {
        appLabels = new Vector();
        lamLabels = new Vector();
        patLabels = new Vector();
        parLabels = new Vector();
        for(int i=1;i <= 5;i++) {
            appLabels.addElement("apply-"+i);
            lamLabels.addElement("lambda-"+i);
            patLabels.addElement("patterns-"+i);
            parLabels.addElement("parallel-"+i);
        }
    }

    private TextEntryLine literalField;
// SCREENSHOT CODE
//    private TextField literalField;
    private ToolTipButton constButton;
    private ToolTipButton appButton;
    private ToolTipButton lamButton;
    private ToolTipButton patButton;
    private ToolTipButton dataButton;
    private ToolTipButton parButton;
    protected Vector constGroups;
    protected Hashtable consts;
    private InfoPanel infoPanel;
    
    public Pallet() {
        super();
        setVisible(false);

        consts = new Hashtable(); constGroups = new Vector();
        addConstants(Editor.prelude);
        
        /* info panel */

        infoPanel = new InfoPanel();        
        Bordered br = new Bordered(Bordered.SQUARE, Bordered.ETCHED, Editor.GAP);
        br.title = INFO_LABEL;
        br.add(infoPanel,"");
        
        add(br,"position=0,0,1,1 weight=1.0,0.0");

        /* sink buttons */

        GridBagPanel sinkPanel = new GridBagPanel();
        sinkPanel.setBackground(Config.faceColour);

        ToolTipButton b;
        sinkPanel.add(b = new ToolTipButton(Editor.sharedInstance,
            Config.getIcon("Save"), SAVE_BUTTON_LABEL),
            "position=0,0,1,1");
        b.tipBackground = Config.infoBackdropColour;
        b.addActionListener(this); b.setCommand(SAVE_BUTTON_LABEL);
        sinkPanel.add(b = new ToolTipButton(Editor.sharedInstance,
            Config.getIcon("DocumentIn"), HASKELL_BUTTON_LABEL),
            "position=1,0,1,1");
        b.tipBackground = Config.infoBackdropColour;
        b.addActionListener(this); b.setCommand(HASKELL_BUTTON_LABEL);
        sinkPanel.add(b = new ToolTipButton(Editor.sharedInstance,
            Config.getIcon("Delete"), RUBBISH_BUTTON_LABEL),
            "position=2,0,1,1");
        b.tipBackground = Config.infoBackdropColour;
        b.addActionListener(this); b.setCommand(RUBBISH_BUTTON_LABEL);

        br = new Bordered(Bordered.SQUARE, Bordered.ETCHED, Editor.GAP);
        br.title = SINKS_LABEL;
        br.add(sinkPanel,"");
        
        add(br,"position=0,1,1,1 weight=1.0,0.0");

        /* source buttons */

        GridBagPanel sourcePanel = new GridBagPanel();
        sourcePanel.setBackground(Config.faceColour);
        
        sourcePanel.add(new TextLabel(SOURCE_HEADER),
            "position=0,0,1,1");
        sourcePanel.add(new TextLabel(GROUP_HEADER),"position=1,0,1,1");
        sourcePanel.add(new TextLabel(PRIM_HEADER),"position=2,0,1,1");

        sourcePanel.add(b = new ToolTipButton(Editor.sharedInstance,
            Config.getIcon("Open"),LOAD_BUTTON_LABEL), "position=0,1,1,1");
        b.tipBackground = Config.infoBackdropColour;
        b.addActionListener(this); b.setCommand(LOAD_BUTTON_LABEL);
        sourcePanel.add(b = new ToolTipButton(Editor.sharedInstance,
            Config.getIcon("cond"), null), "position=0,2,1,1");
        b.addActionListener(this); b.setCommand(IF_BUTTON_LABEL);
        sourcePanel.add(b = new ToolTipButton(Editor.sharedInstance,
            Config.getIcon("let"),null), "position=0,3,1,1");
        b.addActionListener(this); b.setCommand(LET_BUTTON_LABEL);
        sourcePanel.add(appButton = new ToolTipButton(Editor.sharedInstance,
            Config.getIcon("arrow"),null), "position=0,4,1,1");
        appButton.addActionListener(this); appButton.setCommand(APP_BUTTON_LABEL);
        sourcePanel.add(lamButton = new ToolTipButton(Editor.sharedInstance,
            Config.getIcon("lambda"),null), "position=0,5,1,1");
        lamButton.addActionListener(this); lamButton.setCommand(LAM_BUTTON_LABEL);
        sourcePanel.add(b = new ToolTipButton(Editor.sharedInstance,
            Config.getIcon("list"), null), "position=0,6,1,1");
        b.addActionListener(this); b.setCommand(LIST_BUTTON_LABEL);
        sourcePanel.add(patButton = new ToolTipButton(Editor.sharedInstance,
            Config.getIcon("patterns"),null), "position=0,7,1,1");
        patButton.addActionListener(this); patButton.setCommand(PAT_BUTTON_LABEL);
        sourcePanel.add(dataButton = new ToolTipButton(Editor.sharedInstance,
            Config.getIcon("datatyp"),null), "position=0,8,1,1");
        dataButton.addActionListener(this); dataButton.setCommand(DATA_BUTTON_LABEL);
        sourcePanel.add(b = new ToolTipButton(Editor.sharedInstance,
            Config.getIcon("guard"),null), "position=0,9,1,1");
        b.addActionListener(this); b.setCommand(GUARD_BUTTON_LABEL);
        sourcePanel.add(parButton = new ToolTipButton(Editor.sharedInstance,
            Config.getIcon("parallel"),null), "position=0,10,1,1");
        parButton.addActionListener(this); parButton.setCommand(PAR_BUTTON_LABEL);
        sourcePanel.add(constButton = new ToolTipButton(Editor.sharedInstance,
            Config.getIcon("prim"),null),"position=0,11,1,1");
        constButton.addActionListener(this);
        constButton.setCommand(PRIM_BUTTON_LABEL);
        /*
        sourcePanel.add(b = new ToolTipButton(Editor.sharedInstance,
            Config.getIcon("thread"),null), "position=0,11,1,1");
        b.addActionListener(this); b.setCommand(THREAD_BUTTON_LABEL);
        */
        
        /* prim pallet */

        sourcePanel.add(new GroupPanel(this),"position=1,1,2,11");

        /* literal instantiation field */

        sourcePanel.add(b = new ToolTipButton(Editor.sharedInstance,
            (Image)Config.iconLib.get("literal"),null),    "position=0,12,1,1");
        b.addActionListener(this); b.setCommand(LIT_LABEL);
// SCREENSHOT CODE
        //sourcePanel.add(literalField = new TextField(),"position=1,12,2,1");
        //literalField.setBackground(Config.textBackdropColour);
        sourcePanel.add(literalField = new TextEntryLine(),"position=1,12,2,1");
        literalField.addActionListener(this);
        literalField.setBackground(Config.textBackdropColour);

        br = new Bordered(Bordered.SQUARE, Bordered.ETCHED, Editor.GAP);
        br.title = SOURCES_LABEL;
        br.add(sourcePanel,"");
        
        add(br,"position=0,2,1,1 weight=1.0,1.0");

        setVisible(true);    
    }

    public void updateInfo() { infoPanel.updateInfo(); }

    /* handle constants menu */

    public void addConstants(ConstAbs cabs) {
        Enumeration e = cabs.defs.keys();
        while(e.hasMoreElements()) {
            ConstBind cb = (ConstBind)cabs.defs.get(e.nextElement());
            if(!constGroups.contains(cb.group)) {
                constGroups.addElement(cb.group);
                consts.put(cb.group,new Vector());
            }
            Vector v = (Vector)consts.get(cb.group);
            v.addElement(cb.name);
        }
    }

    /* event handling --------------------------------------- */

    public void actionPerformed(ActionEvent event) {

        String cmd = event.getActionCommand();

        if(cmd.equals(IF_BUTTON_LABEL)) {
            Editor.grab(new CondVal("ignore me"),true);
            Statistics.addOp("create","if");
        } else if(cmd.equals(LET_BUTTON_LABEL)) {
            Editor.grab(new LetAbs(new BtmVal()),true);
            Statistics.addOp("create","let");
        } else if(event.getSource().equals(literalField) || 
            cmd.equals(LIT_LABEL)) {
            Literal lit = null;
            try {
                lit = new Literal(literalField.getText());
            } catch(Exception e) {
                System.out.println(e.getMessage());
                return;
            }
            Editor.grab(lit,true);
            Statistics.addOp("create","literal");
        } else if(cmd.equals(PRIM_BUTTON_LABEL)) {
            StringSelectorPopup grp = new StringSelectorPopup(
                Editor.sharedInstance,SEL_GROUP_TITLE,constGroups);
            jkk.gui.Lib.locateNear(grp,constButton);
            grp.setVisible(true);
            String group = grp.getSelectedString();
            if(group == null) return;
            grp = new StringSelectorPopup(Editor.sharedInstance,
                SEL_CONST_TITLE,(Vector)consts.get(group));
            jkk.gui.Lib.locateNear(grp,constButton);
            grp.setVisible(true);
            String cName = grp.getSelectedString();

            grabConstant(group,cName);
            Statistics.addOp("create","primitive");
        } else if(cmd.equals(LOAD_BUTTON_LABEL)) {
            Value v = Editor.loadValue();
            if(v == null) return;
            Editor.grab(v);
            Statistics.addOp("create","load");
        } else if(cmd.equals(RUBBISH_BUTTON_LABEL)) {
            if(Editor.getGrabbed() != null)
                Editor.drop(true);
        } else if(cmd.equals(SAVE_BUTTON_LABEL)) {
            if(Editor.getGrabbed() != null) {
                if(Editor.saveValue((Value)Editor.getGrabbed()))
                    Editor.drop(true);
            }
        } else if(cmd.equals(HASKELL_BUTTON_LABEL)) {
            if(Editor.getGrabbed() == null) {
                Editor.showMessage("nothing to write"); return;
            }
            String err = Editor.writeHaskell((Value)Editor.getGrabbed());
            if(err == null) {
                Editor.showMessage("expression written");
                Editor.drop(true);
            } else {
                Editor.showAlert(err);
            }
        }
/*
        else if(cmd.equals(DEPEND_BUTTON_LABEL)) {
// OBSOLETE
            if(Editor.getGrabbed() == null) {
                Editor.showMessage("nothing to analyse"); return;
            }
            if(Editor.analyseDepend((Value)Editor.getGrabbed()))
                Editor.drop();
        }
*/
          else if(cmd.equals(APP_BUTTON_LABEL)) {
            StringSelectorPopup grp = new StringSelectorPopup(
                Editor.sharedInstance,SELECT_ARITY_LABEL,appLabels);
            jkk.gui.Lib.locateNear(grp,appButton);
            grp.setVisible(true);
            String aString = grp.getSelectedString();
            if(aString == null) return;
            aString = aString.substring(APP_BUTTON_PREFIX.length());
            int arity = 1;
            try {
                arity = Integer.parseInt(aString);
            } catch(NumberFormatException nfe) { }
            Editor.grab(new AppVal(arity),true);
            Statistics.addOp("create","apply");
        } else if(cmd.equals(LAM_BUTTON_LABEL)) {
            StringSelectorPopup grp = new StringSelectorPopup(
                Editor.sharedInstance,SELECT_ARITY_LABEL,lamLabels);
            jkk.gui.Lib.locateNear(grp,lamButton);
            grp.setVisible(true);
            String aString = grp.getSelectedString();
            if(aString == null) return;
            aString = aString.substring(LAM_BUTTON_PREFIX.length());
            int arity = 1;
            try {
                arity = Integer.parseInt(aString);
            } catch(NumberFormatException nfe) { }
            Editor.grab(new LamAbs(arity),true);
            Statistics.addOp("create","lambda");
        } else if(cmd.equals(PAT_BUTTON_LABEL)) {
            StringSelectorPopup grp = new StringSelectorPopup(
                Editor.sharedInstance,SELECT_ARITY_LABEL,patLabels);
            jkk.gui.Lib.locateNear(grp,patButton);
            grp.setVisible(true);
            String aString = grp.getSelectedString();
            if(aString == null) return;
            aString = aString.substring(PAT_BUTTON_PREFIX.length());
            int arity = 1;
            try {
                arity = Integer.parseInt(aString);
            } catch(NumberFormatException nfe) { }
            Editor.grab(new Patterns(arity),true);
            Statistics.addOp("create","pattern");
        } else if(cmd.equals(LIST_BUTTON_LABEL)) {
            Editor.grab(new List(),true);
            Statistics.addOp("create","list");
        } else if(cmd.equals(DATA_BUTTON_LABEL)) {
            StringRequester sr = new StringRequester("New Datatype",
                "Enter type name and arguments eg Tree a",
                Editor.sharedInstance);
            jkk.gui.Lib.locateNear(sr,dataButton);
            sr.tf.setBackground(Config.textBackdropColour);
            sr.setVisible(true);
            String defString = sr.getString();
            if(defString == null || defString.equals("")) {
                Editor.showMessage("New datatype canceled"); return;
            }
            StringTokenizer toks = new StringTokenizer(defString);
            if(toks.countTokens() < 1) {
                Editor.showMessage("New datatype canceled"); return;
            }
            String tName = toks.nextToken();
            if(!Character.isUpperCase(tName.charAt(0))) {
                Editor.showAlert("Bad type name " + tName); return;
            }
            Vector varNames = new Vector();
            while(toks.hasMoreTokens()) {
                String v = (String)toks.nextToken();
                if(!Character.isLowerCase(v.charAt(0))) {
                    Editor.showAlert("bad type var name " + v); return;
                }
                varNames.addElement(v);
            }
            Editor.grab(new DataAbs(new BtmVal(),tName,varNames),true);        
            Statistics.addOp("create","datatype");
        } else if(cmd.equals(GUARD_BUTTON_LABEL)) {
            Editor.grab(new Guards(),true);
            Statistics.addOp("create","guard");
        }  else if(cmd.equals(PAR_BUTTON_LABEL)) {
            StringSelectorPopup grp = new StringSelectorPopup(
                Editor.sharedInstance,SELECT_ARITY_LABEL,parLabels);
            jkk.gui.Lib.locateNear(grp,parButton);
            grp.setVisible(true);
            String aString = grp.getSelectedString();
            if(aString == null) return;
            aString = aString.substring(PAR_BUTTON_PREFIX.length());
            int arity = 1;
            try {
                arity = Integer.parseInt(aString);
            } catch(NumberFormatException nfe) { }
            Editor.grab(new ParTuple(arity),true);
            Statistics.addOp("create","parTuple");
        } else if(cmd.equals(THREAD_BUTTON_LABEL)) {
            Thread t = new Thread("thread");
            String s = jkk.gui.Lib.requestString("Name",
                "Thread name", Editor.sharedInstance,"thread",false);
            if(s != null && !s.equals(""))
                t.name = s;
            t.addBody(new BtmVal());
            Editor.grab(t,true);
            Statistics.addOp("create","thread");
        }
    }

    protected void grabConstant(String gName, String cName) {
        if(cName == null) return;
        ConstBind sb = (ConstBind)Editor.prelude.defs.get(gName+"/"+cName);
        Value v = null;
            
        if(Config.applyVars) {
            v = new AppVal(); v.addBody(sb.makeVar());
            int arity = Type.parseType(sb.tstr).funArity();
            if(arity == 0) {
                v = sb.makeVar();
                Statistics.addVariant("create-var-function");
            } else {
                for(int i=0;i < arity;i++)
                    v.addArg(new BtmVal());
                ((AppLayout)v.layoutInfo).hideApply = true;    
                Statistics.addVariant("create-var-apply");
            }
        } else {
            v = sb.makeVar();
            Statistics.addVariant("create-var-function");
        }
        Editor.grab(v,true);
        Statistics.addOp("create","var");
        Statistics.addVariant("create-var-prim");
    }

}

class PrimPanel extends GridBagPanel implements ActionListener {
    Pallet p;
    String groupName;
    
    PrimPanel(Pallet p, String gName) {
        super();
        this.p = p; groupName = gName;
        ConstAbs prelude = Editor.prelude;
        Vector cs = (Vector)p.consts.get(gName);
        for(int i=0;i < cs.size();i++) {
            String cName = (String)cs.elementAt(i);
            ConstBind cb = (ConstBind)prelude.defs.get(gName+"/"+cName);
            ToolTipButton b = new ToolTipButton(Editor.sharedInstance,
                cName,cb.tstr);
            b.tipBackground = Config.infoBackdropColour;
            b.addActionListener(this);
            add(b,"position=0,"+i+",1,1");
        }
    }

    /* event handling --------------------------------------- */

    public void actionPerformed(ActionEvent event) {
        String cmd = event.getActionCommand();
        p.grabConstant(groupName,cmd);
    }
    
}

class GroupPanel extends GridBagPanel implements ActionListener {
    Hashtable primPanels;
    PrimPanel currentPanel;
    int nPanels;
    Color hlColor, normalColor;
    Component currentButton;
    
    GroupPanel(Pallet p) {
        super();
        normalColor = Config.faceColour;
        hlColor = Config.selectedColour;
        primPanels = new Hashtable();
        StringTokenizer groups = new StringTokenizer(Config.getProp(
            "pallet.visible.prim.groups"),",");
        int i=0; String gName = null;
        ToolTipButton b = null;
        while(groups.hasMoreTokens()) {
            gName = groups.nextToken();
            b = new ToolTipButton(Editor.sharedInstance,
                gName,null);
            b.addActionListener(this);
            add(b,"position=0,"+i+",1,1");
            PrimPanel pp = new PrimPanel(p,gName);
            pp.setBackground(hlColor);
            primPanels.put(gName,pp);
            i++; 
        }
        nPanels = i;
        currentButton = b;
        currentButton.setBackground(hlColor);
        currentPanel = (PrimPanel)primPanels.get(gName);
        add(currentPanel,"position=1,0,1,"+(nPanels));
    }

    /* event handling --------------------------------------- */

    public void actionPerformed(ActionEvent event) {
        String cmd = event.getActionCommand();
        Component src = ((Component)event.getSource()).getParent();
        currentButton.setBackground(normalColor);
        currentButton.repaint();
        src.setBackground(normalColor);
        PrimPanel newPanel = (PrimPanel)primPanels.get(cmd);
        remove(currentPanel);
        add(newPanel,"position=1,0,1,"+nPanels);
        currentButton = src;
        currentButton.setBackground(hlColor);
        currentPanel = newPanel;
        currentPanel.repaint();
        invalidate();
        validate();
    }
    
}

class InfoPanel extends GridBagPanel implements ActionListener {
    private static final String GRABBED_LABEL = "grabbed expression";
    private static final String SELECTED_LABEL = "selected expression";
    private static final String NONE_LABEL = "no expression";
    private static final String VAR_CHECKBOX_LABEL = "apply functions";
    private static final String EVAL_CONTROL_LABEL = "eval controls";
    private static final String REBUILD_TYPES_LABEL = "rebuild types";

    private static final String INFO_BUTTON_LABEL = "info";

    private Checkbox applyVars;
    private MultiLineTextLabel infoText;
    private Container toolbar;
    private ReducerPanel evalControls;
    private Window rDialog;

    private ToolTipButton infoButton;
    
    public InfoPanel() {
        setBackground(Config.faceColour);

        // info box
        
        Bordered border = new Bordered(Bordered.SQUARE,Bordered.PLAIN,2);
        border.setBackground(Config.infoBackdropColour);        
        border.add("",infoText = new MultiLineTextLabel(NONE_LABEL+"\n\n"));
        add(border,"position=0,0,2,2 insets=0,0,2,0");

        // toolbar 
        
        add(toolbar = new LightContainer(),"position=0,2,2,1");
        toolbar.setLayout(new FlowLayout(FlowLayout.LEFT,0,0));
        
        toolbar.add(infoButton = new ToolTipButton(Editor.sharedInstance,
            Config.getIcon("Inform"), INFO_BUTTON_LABEL));
        infoButton.tipBackground = Config.infoBackdropColour;
        infoButton.addActionListener(this);
        infoButton.setCommand(INFO_BUTTON_LABEL);

        ToolTipButton b;
        toolbar.add(b = new ToolTipButton(Editor.sharedInstance,
            Config.getIcon("AlignCenter"),SyntaxControl.LAYOUT_LABEL));
        b.tipBackground = Config.infoBackdropColour;
        b.addActionListener(this); b.setCommand(SyntaxControl.LAYOUT_LABEL);
        toolbar.add(b = new ToolTipButton(Editor.sharedInstance,
            Config.getIcon("DocumentDraw"),SyntaxControl.COMMENT_LABEL));
        b.tipBackground = Config.infoBackdropColour;
        b.addActionListener(this); b.setCommand(SyntaxControl.COMMENT_LABEL);
        toolbar.add(b = new ToolTipButton(Editor.sharedInstance,
            Config.getIcon("Cut"), ValueControl.CUT_LABEL));
        b.tipBackground = Config.infoBackdropColour;
        b.addActionListener(this); b.setCommand(ValueControl.CUT_LABEL);
        toolbar.add(b = new ToolTipButton(Editor.sharedInstance,
            Config.getIcon("Copy"), ValueControl.COPY_LABEL));
        b.tipBackground = Config.infoBackdropColour;
        b.addActionListener(this); b.setCommand(ValueControl.COPY_LABEL);
        toolbar.add(b = new ToolTipButton(Editor.sharedInstance,
            Config.getIcon("Reduce"), ValueControl.REDUCE_LABEL));
        b.tipBackground = Config.infoBackdropColour;
        b.addActionListener(this); b.setCommand(ValueControl.REDUCE_LABEL);
        toolbar.add(b = new ToolTipButton(Editor.sharedInstance,
            Config.getIcon("Evaluate"), ValueControl.EVAL_LABEL));
        b.tipBackground = Config.infoBackdropColour;
        b.addActionListener(this); b.setCommand(ValueControl.EVAL_LABEL);
        
        // show eval controls button

        rDialog = new Frame(EVAL_CONTROL_LABEL);
        rDialog.setBackground(Config.faceColour);
        rDialog.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent we) {
                if(Config.takeSnapshots)
                    Editor.shotToFile(rDialog);
                else
                    rDialog.setVisible(false);
            }
        });
        evalControls = new ReducerPanel(Editor.makeReducer());
        rDialog.add(evalControls,"Center");
        rDialog.pack();
        add(b = new ToolTipButton(Editor.sharedInstance,
            EVAL_CONTROL_LABEL,null), "position=0,3,1,1");
        b.tipBackground = Config.infoBackdropColour;
        b.addActionListener(this);
        
        // apply vars checkbox
        
        add(applyVars = new Checkbox(new TextLabel(VAR_CHECKBOX_LABEL)),
            "position=0,4,2,1 insets=0,1,0,0");
        applyVars.addActionListener(this);
        applyVars.setState(Config.applyVars);

        // rebuild types

        ToolTipButton rebuildTypes;
        add(rebuildTypes = new ToolTipButton(Editor.sharedInstance,
            Config.getIcon("alpha"), REBUILD_TYPES_LABEL), "position=1,3,1,1");
        rebuildTypes.tipBackground = Config.infoBackdropColour;
        rebuildTypes.setCommand(REBUILD_TYPES_LABEL);
        rebuildTypes.addActionListener(this);
    }

    public void updateInfo() {
        String infoAboutLabel;
        SyntaxLayout infoAbout = null;
        if(Editor.getGrabbed() != null) {
            infoAboutLabel = GRABBED_LABEL;
            infoAbout = Editor.getGrabbed().layoutInfo;
        } else if(Editor.getSelected() != null) {
            infoAboutLabel = SELECTED_LABEL;
            infoAbout = Editor.getSelected().body;
        } else
            infoAboutLabel = NONE_LABEL;

        if(infoAbout != null)
            infoAboutLabel += "\n" + infoAbout.getDescription(false);
        infoText.setText(infoAboutLabel);
        setToolbarEnable(Editor.getSelected() != null);

        repaint();

        evalControls.updatePanel(); evalControls.repaint();
    }

    public void setToolbarEnable(boolean b) {
        Component [] cs = toolbar.getComponents();
        for(int i=0;i < cs.length;i++)
            cs[i].setEnabled(b);
    }

    /* event handling */

    public void actionPerformed(ActionEvent event) {
        String cmd = event.getActionCommand();

        if(event.getSource().equals(applyVars)) {
            Config.applyVars = cmd.equals("true");
        }

        if(Editor.getGrabbed() == null && Editor.getSelected() != null) {
            SyntaxFace selFace = Editor.getSelected();
            selFace.body.handleSyntaxOp(cmd);
            if(selFace.body instanceof ValueLayout) {
                ((ValueLayout)selFace.body).handleValueOp(cmd,Editor.makeReducer());
            }
        }
        
        if(cmd.equals(INFO_BUTTON_LABEL)) {
            if(Editor.getSelected() == null) return;
            SyntaxFace selFace = Editor.getSelected();
            selFace.body.controlClick();
        } else if(cmd.equals(EVAL_CONTROL_LABEL)) {
            evalControls.getParent().setVisible(true);
        } else if(cmd.equals(REBUILD_TYPES_LABEL)) {
            if(Editor.typeless) {
                Editor.goTyped();
                String s = Statistics.rebuildTypes("rebuild");
                if(s != null)
                    Editor.panic("expression got badly typed...");
            }
        }
    }

}
