/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997-1998
*/

package vfpe.editor;

import java.awt.Image;

import jkk.gui.ImageLabel;
import vfpe.editor.SyntaxFace;
import vfpe.editor.SyntaxLayout;

/* this implementation is for simple image-labeled buttons */

public class ImageFace extends SyntaxFace {

	/* constructor -------------------------------------------------- */

	protected ImageFace(SyntaxLayout body, Image img) { 
        super(body);
        ImageLabel lbl = new ImageLabel(img);
		add("",lbl);
	}
}
