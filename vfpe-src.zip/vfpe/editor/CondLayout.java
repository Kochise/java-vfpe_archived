/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997-1998
*/

package vfpe.editor;

import java.awt.Image;

import vfpe.syntax.CondVal;
import vfpe.syntax.Syntax;
import vfpe.syntax.Value;
import vfpe.editor.ImageFace;
import vfpe.editor.ValueLayout;

public class CondLayout extends ValueLayout {
	public static final long serialVersionUID = 1;

	public CondLayout(CondVal cndv) { super(cndv); }

	protected String syntaxName() { return "conditional"; }

	protected SyntaxFace makeFace() { 
		return new ImageFace(this,(Image)Config.iconLib.get("cond"));
	}
}
