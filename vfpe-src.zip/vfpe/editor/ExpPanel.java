/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997
*/

package vfpe.editor;

import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Panel;
import java.awt.Point;

import jkk.gui.LinkPanel;
import vfpe.editor.SyntaxLayout;

class ExpPanel extends LinkPanel {
  protected SyntaxLayout root;
  private Dimension prefSize = new Dimension(200,200);
  
  protected ExpPanel() { 
    super(); 
  }
  
  protected void setExp(SyntaxLayout sl) {
    root = sl;
    root.makeFaces(this);
    prefSize = root.layoutSubtree(new Point(SyntaxLayout.GAP,SyntaxLayout.GAP));
    invalidate();
  }

  protected void redraw() {
    prefSize = root.layoutSubtree(new Point(SyntaxLayout.GAP,SyntaxLayout.GAP));
    invalidate();
    Container p = getParent();
    if(p != null) p.validate();
    repaint();
  }

  protected void rebuild() {
    removeAll(); setExp(root); 
    Container p = getParent();
    if(p != null) p.validate();
    repaint();
  }

  Dimension offSize;
  Image offscreen;
  
  public void paint(Graphics g) {
    if(Config.doubleBufferExp) {
      Dimension size = getSize();
      if(offscreen == null || !offSize.equals(size)) {
        offscreen = createImage(size.width,size.height);
        offSize = new Dimension(size.width,size.height);
      }
      Graphics ofg = offscreen.getGraphics();
      
      ofg.setColor(getBackground());
      ofg.fillRect(0,0,size.width,size.height);
      super.paint(ofg);

      g.drawImage(offscreen,0,0,null);
    } else {
      super.paint(g);
    }
  }

  public Dimension getPreferredSize() { return prefSize; }
    
  public Dimension getMinimumSize() { return prefSize; }
}
