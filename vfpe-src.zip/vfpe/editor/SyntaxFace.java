/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997-1998
*/

package vfpe.editor;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import jkk.gui.Bordered;
import jkk.gui.GridBagPanel;
//import jkk.gui.PopupLabel;
import jkk.gui.MultiLineTextLabel;

import vfpe.editor.Config;
import vfpe.editor.Editor;
import vfpe.editor.SyntaxLayout;
import vfpe.editor.ValueLayout;
import vfpe.editor.ValueControl;

/* this implementation is for simple text-labeled buttons */

public abstract class SyntaxFace extends Bordered 
    implements ActionListener, KeyListener {

    protected static int BORDER_SIZE = 4;

    protected SyntaxLayout body;
    public boolean allowControls;

    /* constructor -------------------------------------------------- */

    protected SyntaxFace(SyntaxLayout body) { 
        super(Bordered.SQUARE,Bordered.RAISED,BORDER_SIZE);
        isDraggable = true; allowControls = true;
        this.body = body;
        setBackground(Config.nodeColour);
    }

    /* ToolTip handling --------------------------------------------- */

    
    /* ToolTip handling --------------------------------------------- */

    protected Window tip;
    
    public void postTip() {
        super.postTip();
        if(!isShowing()) return;
        tip = new Window(jkk.gui.Lib.getParentFrame(this));
        tip.add(body.getDescPanel(true),"Center");
        tip.pack(); jkk.gui.Lib.locateNear(tip,this);
        tip.setVisible(true);
    }

    public void unpostTip() {
        super.unpostTip();
        if(tip != null) {
            tip.setVisible(false); tip.dispose();
        }
    }
    
    /* Event handling ----------------------------------------------- */
    
    public void mouseClicked(MouseEvent evnt) {
        super.mousePressed(evnt);
        requestFocus();
        if(!allowControls) return;
        int mods = evnt.getModifiers();
        resetTipTimer();
        if((mods & (InputEvent.CTRL_MASK |
                    InputEvent.BUTTON2_MASK |
                    InputEvent.BUTTON3_MASK)) != 0)
            body.controlClick();
        else
            body.click();
    }
    
    public void actionPerformed(ActionEvent evnt) { body.click(); }
    
    public void keyPressed(KeyEvent ke) {
        if(this != Editor.getSelected()) return;
        if(!ke.isControlDown()) return;
        if(!(body instanceof ValueLayout)) return;
        ValueLayout vl = (ValueLayout)body;
        switch(ke.getKeyCode()) {
        case KeyEvent.VK_C:
            vl.handleValueOp(ValueControl.COPY_LABEL,
                Editor.makeReducer());
            break;
        case KeyEvent.VK_X:
            vl.handleValueOp(ValueControl.CUT_LABEL,
                Editor.makeReducer());
            break;
        case KeyEvent.VK_R:
            vl.handleValueOp(ValueControl.REDUCE_LABEL,
                Editor.makeReducer());
            break;
        case KeyEvent.VK_E:
            vl.handleValueOp(ValueControl.EVAL_LABEL,
                Editor.makeReducer());
            break;
        default: break;
        }
    }

    public void keyReleased(KeyEvent ke) { }

    public void keyTyped(KeyEvent ke) {
    }

}

