/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997
*/

package vfpe.editor;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.util.Vector;

import jkk.gui.ToolTipButton;
import vfpe.editor.ValueControl;
import vfpe.syntax.Value;
import vfpe.editor.ValueLayout;
import vfpe.syntax.VarVal;

public class VarLayout extends ValueLayout {
    public static final long serialVersionUID = 1;

    public VarLayout(VarVal vv) {
        super(vv);
    }

    protected String syntaxName() { return "variable"; }

    protected SyntaxFace makeFace() {
        return new LabelFace(this,((VarVal)syntax).binding.name);
    }

    protected Vector layoutChildren() { return new Vector(); }

    protected Component makeControls() {
        return new VarControl(this);
    }
}

class VarControl extends ValueControl {
    private static final String SHOW_BINDING_LABEL = "show binding";

    protected VarLayout vl;
    
    VarControl(SyntaxLayout sl) {
        super(sl);
        vl = (VarLayout)sl;

        /* controls */
        
        ToolTipButton b = new ToolTipButton(Editor.sharedInstance,
            SHOW_BINDING_LABEL,null);
        cp.add(b,"position=0,5,6,1");
        b.addActionListener(this);
    }

    /* event handling */

    public void actionPerformed(ActionEvent ae) {
        String cmd = ae.getActionCommand();
        VarVal vv = (VarVal)vl.syntax;
        if(cmd.equals(SHOW_BINDING_LABEL)) {
            Editor.makeVisible(vv.binding);
            close = true;
        } 
        super.actionPerformed(ae);
    }
}
