/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1999
*/

/* unary array operations */

package vfpe.evaluators;

import vfpe.EvaluationException;
import vfpe.PrimEvaluator;
import vfpe.Reducer;
import vfpe.editor.Editor;
import vfpe.syntax.AppVal;
import vfpe.syntax.Array;
import vfpe.syntax.ConstBind;
import vfpe.syntax.Literal;
import vfpe.syntax.Value;

public class UnaryParallel implements PrimEvaluator {

  public UnaryParallel() { }
  
  public int arity() { return 1; }
  
  public Value reduce(AppVal app, Value [] argv, ConstBind cb, Reducer r)
    throws EvaluationException {

    /* select and perform operation */

    Value res = null;

    if(cb.group.equals("parallel")) {
      if(cb.name.equals("parData") ||
         cb.name.equals("parPair")) {
        AppVal a0 = evalConstructor(argv[0],r);
        if(a0 == null) return app;
        int oldRCount = r.rCount;
        boolean allNormal = true;
        for(int i=0;i < a0.arity();i++) {
          Value v = a0.arg(i);
          Value nv = v.reduce(r);
          if(nv != null) {
            v.replace(nv); allNormal = false;
          }
        }
        r.rCount = oldRCount;
        if(!allNormal) {
          res = app;
        } else {
          res = a0;
        }
      } else
        Editor.panic("UnaryParallel doesn't know " + cb.name);
    } else
      Editor.panic("UnaryParallel doesn't know " + cb.group);

    r.step(Reducer.PRIM_EVAL,cb.getLongName(),res,app);
    return res;
  }

  public static AppVal evalConstructor(Value v, Reducer r)
    throws EvaluationException {
    Value v1 = v.reduce(r);
    if(v1 != null) {
      v.replace(v1); return null;
    }
    return (AppVal)v.getGroundValue();
  }

}
