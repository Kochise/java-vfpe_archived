/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997-1998
*/

/* primitive evaluator for binary integer and float operators */

package vfpe.evaluators;

import vfpe.EvaluationException;
import vfpe.PrimEvaluator;
import vfpe.Reducer;
import vfpe.editor.Editor;
import vfpe.syntax.AppVal;
import vfpe.syntax.ConstBind;
import vfpe.syntax.Literal;
import vfpe.syntax.Value;

public class ArithmeticEval implements PrimEvaluator {

	public ArithmeticEval() { }
	
	public int arity() { return 2; }
	
	public Value reduce(AppVal app, Value [] argv, ConstBind cb, Reducer r)
		throws EvaluationException {

		/* evaluate args */

		Value v1 = argv[0].reduce(r);
		if(v1 != null) {
			argv[0].replace(v1); return app;
		}
		Literal l1 = (Literal)argv[0].getGroundValue();

		Value v2 = argv[1].reduce(r);
		if(v2 != null) {
			argv[1].replace(v2); return app;
		}
		Literal l2 = (Literal)argv[1].getGroundValue();

		/* select and perform operation */

		String res = null;

		if(cb.group.equals("int-math")) {
			if(cb.name.equals("+")) {
				res = Integer.toString(
					((Integer)l1.value).intValue() +
					((Integer)l2.value).intValue());
			} else if(cb.name.equals("-")) {
				res = Integer.toString(
					((Integer)l1.value).intValue() -
					((Integer)l2.value).intValue());
			} else if(cb.name.equals("div")) {
				res = Integer.toString(
					((Integer)l1.value).intValue() /
					((Integer)l2.value).intValue());
			} else if(cb.name.equals("*")) {
				res = Integer.toString(
					((Integer)l1.value).intValue() *
					((Integer)l2.value).intValue());
			} else if(cb.name.equals("mod")) {
				int rem = ((Integer)l1.value).intValue() %
					((Integer)l2.value).intValue();
				rem = rem< 0 ? rem + ((Integer)l2.value).intValue() : rem;
				res = Integer.toString(rem);
			} else
				Editor.panic("ArithmeticEval doesn't know " + cb.name);
		} else if(cb.group.equals("float-math")) {
			if(cb.name.equals("+")) {
				res = Float.toString(
					((Float)l1.value).floatValue() +
					((Float)l2.value).floatValue());
			} else if(cb.name.equals("-")) {
				res = Float.toString(
					((Float)l1.value).floatValue() -
					((Float)l2.value).floatValue());
			} else if(cb.name.equals("/")) {
				res = Float.toString(
					((Float)l1.value).floatValue() /
					((Float)l2.value).floatValue());
			} else if(cb.name.equals("*")) {
				res = Float.toString(
					((Float)l1.value).floatValue() *
					((Float)l2.value).floatValue());
			} else if(cb.name.equals("**")) {
				res = Float.toString((float)Math.pow(
					((Float)l1.value).floatValue(),
					((Float)l2.value).floatValue()));
			} else
				Editor.panic("ArithmeticEval doesn't know " + cb.name);
		} else
			Editor.panic("ArithmeticEval doesn't know " + cb.group);

		try {
			Literal retLit = new Literal(res);
			r.step(Reducer.PRIM_EVAL,cb.getLongName(),retLit,app);
			return retLit;
		} catch(Exception e) {
			Editor.panic("ArithmeticEval with bad Literal " + res);
			return null;
		}
	}

}
