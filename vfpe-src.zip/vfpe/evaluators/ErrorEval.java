/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997-1998
*/

/* primitive evaluator for the error function */

package vfpe.evaluators;

import vfpe.EvaluationException;
import vfpe.PrimEvaluator;
import vfpe.Reducer;
import vfpe.editor.Editor;
import vfpe.syntax.AppVal;
import vfpe.syntax.ConstBind;
import vfpe.syntax.Literal;
import vfpe.syntax.Value;

public class ErrorEval implements PrimEvaluator {

	public ErrorEval() { }
	
	public int arity() { return 1; }
	
	public Value reduce(AppVal app, Value [] argv, ConstBind cb, Reducer r)
		throws EvaluationException {

		/* evaluate arg */

		Value v1 = argv[0].reduce(r);
		if(v1 != null) {
			argv[0].replace(v1); return app;
		}
		Literal l1 = (Literal)argv[0].getGroundValue();

		/* select and perform operation */

		throw new EvaluationException("Evaluated 'error' function: " + l1);
	}
}
