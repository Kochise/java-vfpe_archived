/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997-1998
*/

/* primitive evaluator for character functions */

package vfpe.evaluators;

import vfpe.EvaluationException;
import vfpe.PrimEvaluator;
import vfpe.Reducer;
import vfpe.editor.Editor;
import vfpe.syntax.AppVal;
import vfpe.syntax.ConstBind;
import vfpe.syntax.Literal;
import vfpe.syntax.Value;

public class CharEval implements PrimEvaluator {

	public CharEval() { }
	
	public int arity() { return 1; }
	
	public Value reduce(AppVal app, Value [] argv, ConstBind cb, Reducer r)
		throws EvaluationException {

		/* evaluate arg */

		Value v1 = argv[0].reduce(r);
		if(v1 != null) {
			argv[0].replace(v1); return app;
		}
		Literal l1 = (Literal)argv[0].getGroundValue();

		/* select and perform operation */

		String res = null;
		if(cb.name.equals("ord")) {
			char c = ((Character)l1.value).charValue();
			res = Integer.toString(c);
		} else if(cb.name.equals("chr")) {
			int i = ((Integer)l1.value).intValue();
			res = "'" + (new Character((char)i).toString()) + "'";
		} else {
			Editor.panic("CharEval doesn't know " + cb.name);
		}

		try {
			Literal retLit = new Literal(res);
			r.step(Reducer.PRIM_EVAL,cb.getLongName(),retLit,app);
			return retLit;
		} catch(Exception e) {
			Editor.panic("CharEval with bad Literal " + res);
			return null;
		}

	}

}
