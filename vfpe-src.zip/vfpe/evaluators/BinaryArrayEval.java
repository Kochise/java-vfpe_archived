/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997-1999
*/

/* binary array operations */

package vfpe.evaluators;

import vfpe.EvaluationException;
import vfpe.PrimEvaluator;
import vfpe.Reducer;
import vfpe.editor.Editor;
import vfpe.syntax.AppVal;
import vfpe.syntax.Array;
import vfpe.syntax.ConstBind;
import vfpe.syntax.Literal;
import vfpe.syntax.Value;

public class BinaryArrayEval implements PrimEvaluator {

  public BinaryArrayEval() { }
  
  public int arity() { return 2; }
  
  public Value reduce(AppVal app, Value [] argv, ConstBind cb, Reducer r)
    throws EvaluationException {

    /* select and perform operation */

    Value res = null;

    if(cb.group.equals("array")) {
      if(cb.name.equals("!")) {
        Array a0 = evalArray(argv[0],r);
        if(a0 == null) return app;
        Literal l1 = EvalLib.evalLiteral(argv[1],r);
        if(l1 == null) return app;
        int n = ((Integer)l1.value).intValue();
        if(n < 0 || n >= a0.arity()) {
          throw new EvaluationException("array index out of bounds in " +
            "! : " + n);
        }
        if(!a0.equals(argv[0])) {
          a0.replace(a0.arg(n));
          res = argv[0];
        } else {
          res = a0.arg(n);
        }
      } else if(cb.name.equals("arrayMap")) {
        Array a0 = evalArray(argv[1],r);
        if(a0 == null) return app;
        AppVal av = new AppVal(1);
        Value f = argv[0];
        av.setBody(f);
        for(int i=0;i < a0.arity();i++) {
          Value v = a0.arg(i);
          AppVal newApp = (AppVal)av.copy(true);
          newApp.setArg((Value)v.copy(true),0);
          v.replace(newApp);
        }
        res = argv[1];
      } else if(cb.name.equals("combinePairs")) {
        Array a0 = evalArray(argv[1],r);
        if(a0 == null) return app;
        int n = a0.arity();
        int newArraySize = n % 2 == 0 ? n/2 : n/2+1;
        Array a1 = new Array(newArraySize);
        if(n % 2 != 0) {
          a1.arg(n/2).replace(a0.arg(a0.arity()-1));
        }
  
        AppVal av = new AppVal(2);
        Value f = argv[0];
        av.setBody(f);
        for(int i=0;i < n/2;i++) {
          Value v1 = a0.arg(i*2);
          Value v2 = a0.arg(i*2+1);
          AppVal newApp = (AppVal)av.copy(true);
          newApp.setArg((Value)v1.copy(true),0);
          newApp.setArg((Value)v2.copy(true),1);
          a1.arg(i).replace(newApp);
        }
        if(!a0.equals(argv[1])) {
          a0.replace(a1);
          res = argv[1];
        } else
          res = a1;
      } else
        Editor.panic("BinaryArrayEval doesn't know " + cb.name);
    } else
      Editor.panic("BinaryArrayEval doesn't know " + cb.group);

    r.step(Reducer.PRIM_EVAL,cb.getLongName(),res,app);
    return res;
  }

  public static Array evalArray(Value v, Reducer r)
    throws EvaluationException {
    Value v1 = v.reduce(r);
    if(v1 != null) {
      v.replace(v1); return null;
    }
    return (Array)v.getGroundValue();
  }

}
