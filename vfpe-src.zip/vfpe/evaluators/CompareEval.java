/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997-1999
*/

/* primitive evaluator for  */

package vfpe.evaluators;

import jkk.Lib;

import vfpe.EvaluationException;
import vfpe.PrimEvaluator;
import vfpe.Reducer;
import vfpe.editor.Editor;
import vfpe.syntax.AppVal;
import vfpe.syntax.Const;
import vfpe.syntax.ConstAbs;
import vfpe.syntax.ConstBind;
import vfpe.syntax.Literal;
import vfpe.syntax.Value;

public class CompareEval implements PrimEvaluator {

	public CompareEval() { }
	
	public int arity() { return 2; }
	
	public Value reduce(AppVal app, Value [] argv, ConstBind cb, Reducer reducer)
		throws EvaluationException {

		/* evaluate args */

		Value v1 = argv[0].reduce(reducer);
		if(v1 != null) {
			argv[0].replace(v1); return app;
		}
		v1 = (Value)argv[0].getGroundValue();

		Value v2 = argv[1].reduce(reducer);
		if(v2 != null) {
			argv[1].replace(v2); return app;
		}
		v2 = (Value)argv[1].getGroundValue();

		/* select and perform operation */

		boolean res;

		if(v1 instanceof Literal) {
			
			/* a Comparable interface should have been part of Java 1.0 */
			
			Literal l1 = (Literal)v1;
			Literal l2 = (Literal)v2;
			if(l1.value instanceof String) {
				Editor.panic("get on Joel's case about putting the String ->" +
					" [Char] conversion in the Literal evaluator");
			}
			int r = Lib.compare(l1.value, l2.value);

			String n = cb.name; res = false;
			res =
				((r == 0) && (n.equals("==") || n.equals("<=") || n.equals(">="))) ||
				((r < 0) && (n.indexOf('<') >= 0)) ||
				((r > 0) && (n.indexOf('>') >= 0)) ||
				(!(r == 0) && n.equals("/=")); 
		} else {
			throw new EvaluationException("CompareEval: don't know how to compare " +
				v1.writeExp() + " and " + v2.writeExp());
		}

		Const retConst = ConstAbs.makeConst("data/"+(res ? "True" : "False"));
		reducer.step(Reducer.PRIM_EVAL,cb.getLongName(),retConst,app);
		return retConst;
	}

}
