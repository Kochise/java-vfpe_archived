/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997-1999
*/

/*	library functions for prim evaluators
	OK so its not an abstract superclass ... so sue me ...
*/

package vfpe.evaluators;

import vfpe.EvaluationException;
import vfpe.PrimEvaluator;
import vfpe.Reducer;
import vfpe.editor.Editor;
import vfpe.syntax.AppVal;
import vfpe.syntax.Array;
import vfpe.syntax.ConstBind;
import vfpe.syntax.Literal;
import vfpe.syntax.Value;

public class EvalLib {

	public static Literal evalLiteral(Value v, Reducer r)
		throws EvaluationException {
		Value v1 = v.reduce(r);
		if(v1 != null) {
			v.replace(v1); return null;
		}
		return (Literal)v.getGroundValue();
	}
	
}
