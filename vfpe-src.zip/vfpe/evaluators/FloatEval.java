/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997-1998
*/

/* primitive evaluator for floating-point operations */

package vfpe.evaluators;

import vfpe.EvaluationException;
import vfpe.PrimEvaluator;
import vfpe.Reducer;
import vfpe.editor.Editor;
import vfpe.syntax.AppVal;
import vfpe.syntax.ConstBind;
import vfpe.syntax.Literal;
import vfpe.syntax.Value;

public class FloatEval implements PrimEvaluator {

	public FloatEval() { }
	
	public int arity() { return 1; }
	
	public Value reduce(AppVal app, Value [] argv, ConstBind cb, Reducer r)
		throws EvaluationException {

		/* evaluate arg */

		Literal l1 = EvalLib.evalLiteral(argv[0],r);
		if(l1 == null) return app;

		/* select and perform operation */

		String res = null;

		if(cb.group.equals("float-math")) {
			if(cb.name.equals("fromInt")) {
				float f = (float)((Integer)l1.value).floatValue();
				res = Float.toString(f);
			} else if(cb.name.equals("floor")) {
				float f = (float)Math.floor(((Float)l1.value).floatValue());
				res = Integer.toString((int)f);
			} else if(cb.name.equals("ceiling")) {
				float f = (float)Math.ceil(((Float)l1.value).floatValue());
				res = Integer.toString((int)f);
			} else if(cb.name.equals("round")) {
				int i = Math.round(((Float)l1.value).floatValue());
				res = Integer.toString(i);
			} else if(cb.name.equals("sqrt")) {
				float f = (float)Math.sqrt(((Float)l1.value).floatValue());
				res = Float.toString(f);
			} else
				Editor.panic("FloatEval doesn't know " + cb.name);
		} else
			Editor.panic("FloatEval doesn't know " + cb.group);

		try {
			Literal retLit = new Literal(res);
			r.step(Reducer.PRIM_EVAL,cb.getLongName(),retLit,app);
			return retLit;
		} catch(IllegalArgumentException e) {
			Editor.panic("FloatEval with bad Literal " + res);
			return null;
		}
	}

}
