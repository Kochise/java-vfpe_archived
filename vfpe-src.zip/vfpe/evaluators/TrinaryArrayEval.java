/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997-1999
*/

/* trinary array operations */

package vfpe.evaluators;

import vfpe.EvaluationException;
import vfpe.PrimEvaluator;
import vfpe.Reducer;
import vfpe.editor.Editor;
import vfpe.syntax.AppVal;
import vfpe.syntax.Array;
import vfpe.syntax.ConstBind;
import vfpe.syntax.Literal;
import vfpe.syntax.Value;

public class TrinaryArrayEval implements PrimEvaluator {

  public TrinaryArrayEval() { }
  
  public int arity() { return 3; }
  
  public Value reduce(AppVal app, Value [] argv, ConstBind cb, Reducer r)
    throws EvaluationException {

    /* select and perform operation */

    Value res = null;

    if(cb.group.equals("array")) {
      if(cb.name.equals("update")) {
        Array a0 = evalArray(argv[0],r);
        if(a0 == null) return app;
        Literal l1 = EvalLib.evalLiteral(argv[1],r);
        if(l1 == null) return app;
        int n = ((Integer)l1.value).intValue();
        if(n < 0 || n >= a0.arity())
          throw new EvaluationException("array index out of bounds in " +
            "! : " + n);
// OPTIMISATION - can we actually eliminate some of this copying ?
        Value resA = (Value)argv[0].copy(true);
        Value upVal = (Value)argv[2].copy(true);
        Array gv = (Array)resA.getGroundValue();
        gv.setArg(upVal,n);
        res = resA;
      } else
        Editor.panic("TrinaryArrayEval doesn't know " + cb.name);
    } else
      Editor.panic("TrinaryArrayEval doesn't know " + cb.group);

    r.step(Reducer.PRIM_EVAL,cb.getLongName(),res,app);
    return res;
  }

  public static Array evalArray(Value v, Reducer r)
    throws EvaluationException {
    Value v1 = v.reduce(r);
    if(v1 != null) {
      v.replace(v1); return null;
    }
    return (Array)v.getGroundValue();
  }

}
