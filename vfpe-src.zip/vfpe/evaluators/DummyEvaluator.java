/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997-1998
*/

/* A "dummy" primitive evaluator. */

package vfpe.evaluators;

import vfpe.PatternMatchFailure;
import vfpe.PrimEvaluator;
import vfpe.Reducer;
import vfpe.syntax.AppVal;
import vfpe.syntax.ConstBind;
import vfpe.syntax.Value;

public class DummyEvaluator implements PrimEvaluator {
	
	public int arity() {
		return 2;
	}
	
	public Value reduce(AppVal app, Value [] argv, ConstBind cb, Reducer r)
		throws PatternMatchFailure {
		return null;
	}

}
