/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997
*/

/*    type variables */

package vfpe.type;

import java.util.Hashtable;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.Vector;

import jkk.Set;
import vfpe.type.Substitution;
import vfpe.type.Type;

public class TypeVar extends Type {

    private static final String DUMMY_NAME = "__TVAR";

    private String name;

    /* constructors ---------------------------------------------- */

    public TypeVar() {  
        typename = DUMMY_NAME; 
        name = niceName();
    }

    /* tools ----------------------------------------------------- */

    public Type substitute(Substitution subs) {
        if(subs.containsKey(this))
            return (Type)subs.get(this);
        else
            return this;
    }

    public Set freeVars() { return new Set(this,this); }

    public static Vector newVars(int n) {
        Vector vs = new Vector();
        for(int i=0;i < n;i++) vs.addElement(new TypeVar());
        return vs;
    }

    public String writeType() { return name; }

    public boolean contains(Type var) { return var.equals(this); }

    public Type copy(Hashtable already) {
        if(already.containsKey(this))
            return (Type)already.get(this);
        TypeVar tv = new TypeVar();
        already.put(this,tv);
        return tv;
    }

    /* for nice type variable name printing ---------------------- */

    /*    this mechanism could be replace by one that explicitly 
        tracks the usable of type variables.  if we use an inference
        system where this is possible, we can be more agressive 
        about re-using names
    */

    static long maxName = 0;
    static SortedMap nnames = new TreeMap();

    private String niceName() {
        synchronized(nnames) {
            if(nnames.size() == 0) {
                // chisel off a new name
                StringBuffer nn = new StringBuffer();
                long mn = maxName++;
                do {
                    nn.append((char)((mn % 26)+'a'));
                    mn /= 26;
                } while(mn > 25);
                String n = nn.toString();
                nnames.put(n,n);
            }
            String n = (String)nnames.firstKey();
            nnames.remove(n); return n;
        }
    }

    /*    if the type nodes don't get collected quick enough, we
        will have to think of something else, although running
        Runtime.gc() and/or Runtime.runFinalization() might free
        some more names */

    protected void finalize() {
        synchronized (nnames) {
            nnames.put(name,name);
        }
    }
}

