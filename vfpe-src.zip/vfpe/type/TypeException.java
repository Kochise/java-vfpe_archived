/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  joel@babbage.cs.murdoch.edu.au
  *** * * * * copyright 1997
*/

package vfpe.type;

import vfpe.type.Type;

public class TypeException extends Exception {
	public Type t1, t2;
	public TypeException(String s, Type tt1, Type tt2) {
		super(s);
		t1 = tt1; t2 = tt2;
	}

	public String explain() {
		StringBuffer buf = new StringBuffer();
		buf.append(getMessage());
		if(t1 != null) {
			buf.append(" due to "); buf.append('\n');
			buf.append(t1.writeType()); buf.append('\n');
		}
		if(t2 != null) {
			buf.append(" and "); buf.append('\n');
			buf.append(t2.writeType());
		} 
		return buf.toString();
	}
}
