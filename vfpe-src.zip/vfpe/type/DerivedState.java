/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1998
*/

/*	the idea here is that making and using these will be cheaper than
	cloning the whole TIS when we're checking typed constructions
*/

package vfpe.type;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import jkk.Functor;
import jkk.Set;
import vfpe.type.Substitution;
import vfpe.syntax.Binding;
import vfpe.syntax.Patterns;
import vfpe.syntax.Syntax;
import vfpe.syntax.Value;

public class DerivedState extends TypeInferenceState {

	private Hashtable newAssumptions;
	private Substitution currentSub;
	private TypeInferenceState parent;

	public DerivedState(TypeInferenceState p) {
		parent = p;
		newAssumptions = new Hashtable();
		currentSub = new Substitution();
	}

	public void commit() {
		parent.substitute(currentSub);
		Enumeration e = newAssumptions.keys();
		while(e.hasMoreElements()) {
			Syntax s = (Syntax)e.nextElement();
			parent.setType(s,getType(s));
		}
		newAssumptions = new Hashtable();
		currentSub = new Substitution();
	}

	public Object clone() {
		throw new IllegalArgumentException(
			"someone cloned a DerivedState");
	}

	public void setType(Syntax s, Type t) {
		newAssumptions.put(s,t);
	}

	public Type getType(Syntax s) {
		Type t = (Type)newAssumptions.get(s);
		if(t != null)
			return t;
		t = (Type)parent.getType(s);
		t = t.substitute(currentSub);
		setType(s,t);
		return t;
	}

	/*	this'll probably need optimisation */
	public void substitute(Substitution subs) {
		currentSub.apply(subs);
		Enumeration e = newAssumptions.keys();
		Vector v = new Vector();
		while(e.hasMoreElements())
			v.addElement(e.nextElement());
		e = v.elements();
		while(e.hasMoreElements()) {
			Syntax s = (Syntax)e.nextElement();
			setType(s,getType(s).substitute(subs));
		}
	}

	public int size() { 
		throw new IllegalArgumentException(
			"size() not supported by DerivedState");
	}

	public void removeType(Syntax s) {
		throw new IllegalArgumentException(
			"removeType() not supported by DerivedState");
	}

	public void removeTypes(Value v) {
		throw new IllegalArgumentException(
			"removeTypes() not supported by DerivedState");
	}

	/////////////////
	// debug printing
	
	public String dump(boolean printBindings) {
		StringBuffer buf = new StringBuffer();
		buf.append("types in newAssumptions:\n");

		Enumeration e = newAssumptions.keys();
		while(e.hasMoreElements()) {
			Syntax s = (Syntax)e.nextElement();
			Type t = getType(s);
			if(printBindings) {
				if(s instanceof Binding) {
					buf.append(((Binding)s).name);
					buf.append(" has type " + t.writeType());
					buf.append('\n');
				}
			}
			if(s instanceof Patterns) {
				buf.append("Patterns " + s.hashCode() + " has type ");
				buf.append(t.writeType());
				buf.append('\n');
			}
		}

		buf.append("types in parent state:\n");
		buf.append(parent.dump(printBindings));
		return buf.toString();
	}

}
