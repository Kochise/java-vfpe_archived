/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997
*/

/*	universally quantified type (ie "for all" type) */

package vfpe.type;

import java.util.Hashtable;
import java.util.Vector;

import jkk.Set;
import vfpe.type.Substitution;
import vfpe.type.Type;

public class QuantifiedType extends Type {

	private static final String DUMMY_NAME = "__QUANT";
	protected Set vars;
	protected Type body;

	/* constructors ---------------------------------------------- */

	public QuantifiedType(Set v, Type b) {  
		typename = DUMMY_NAME; vars = v; body = b;
	}

	/* tools ----------------------------------------------------- */

	public Type substitute(Substitution subs) {
		return new QuantifiedType(vars,
			body.substitute((Substitution)subs.difference(vars)));
	}

	public Set freeVars() {
		return body.freeVars().difference(vars);
	}

	public Type specialise() {
		return body.substitute(
			new Substitution(vars.vectorise(),TypeVar.newVars(vars.size())));
	}

	public int funArity() { return body.funArity(); }
	public Type funArgType(int an) { return body.funArgType(an); }
	public Type funRetType(int an) { return body.funRetType(an); }

	public boolean contains(Type var) { return body.contains(var); }

	/* should put in quantifiers */
	public String writeType() { return body.writeType(); }

}

