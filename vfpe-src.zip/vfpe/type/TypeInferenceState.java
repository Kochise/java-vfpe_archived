/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1998-2001
*/

/*	this abstracts the state of known type information about a program
	during type inference

	the idea is that we implement this efficently in the face of 
	assumptions about the types of subexpressions, type queries,
	and substitutions resulting from unifications
*/

package vfpe.type;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import jkk.Functor;
import jkk.Set;
import vfpe.type.Substitution;
import vfpe.syntax.Binding;
import vfpe.syntax.Patterns;
import vfpe.syntax.Syntax;
import vfpe.syntax.Value;

public class TypeInferenceState {

	private Hashtable assumptions;
	private Hashtable generics;

	public TypeInferenceState() {
		assumptions = new Hashtable();
		generics = new Hashtable();
	}

	public Object clone() {
		TypeInferenceState tmp = new TypeInferenceState();
		tmp.assumptions = (Hashtable)assumptions.clone();
		return tmp;
	}

	public void setType(Syntax s, Type t) {
		assumptions.put(s,t);
	}

	public Type getType(Syntax s) {
		return (Type)assumptions.get(s);
	}

	/*	this'll probably need optimisation */
	public void substitute(Substitution subs) {
// NOTE - check for substitution for generic var ?
		Enumeration e = assumptions.keys();
		Vector v = new Vector();
		while(e.hasMoreElements())
			v.addElement(e.nextElement());
		e = v.elements();
		while(e.hasMoreElements()) {
			Syntax s = (Syntax)e.nextElement();
			setType(s,getType(s).substitute(subs));
		}
	}

	public void setGenerics(Binding b, Set gVars) {
		Enumeration e = gVars.keys();
		while(e.hasMoreElements()) {
			Type gv = (Type)e.nextElement();
			generics.put(gv,b);
		}
// NOTE also add to binding -> gv set reverse table ?
	}

/*
	public Set freeVars() {
		Set fvs = new Set();
		Enumeration e = assumptions.elements();
		while(e.hasMoreElements()) {
			Type t = (Type)e.nextElement();
			fvs.add(t.freeVars());
		}
		return fvs;
	}
*/

	public int size() { return assumptions.size(); }

	public void removeType(Syntax s) {
		assumptions.remove(s);
	}

	public void removeTypes(Value v) {
		v.traverseSyntaxTree(new Functor() {
			public Object eval(Object x) {
				removeType((Syntax)x); return null;
			}
		});
	}

	/////////////////
	// debug printing
	
	public String dump(boolean printBindings) {
		StringBuffer buf = new StringBuffer();
		Enumeration e = assumptions.keys();
		while(e.hasMoreElements()) {
			Syntax s = (Syntax)e.nextElement();
			Type t = getType(s);
			if(printBindings) {
				if(s instanceof Binding) {
					buf.append(((Binding)s).name);
					buf.append(" has type " + t.writeType());
					buf.append('\n');
				}
			}
			if(s instanceof Patterns) {
				buf.append("Patterns " + s.hashCode() + " has type ");
				buf.append(t.writeType());
				buf.append('\n');
			}
		}
		return buf.toString();
	}

}
