/* reads two type expressions from command line, unifies and reports */

package vfpe.type;

import java.util.Enumeration;

import jkk.Set;
import vfpe.type.Substitution;
import vfpe.type.Type;

public class TypeTest {

	public TypeTest() {}

	public static void main(String [] argv) {
		Type t1 = Type.parseType(argv[0]);
		System.out.println(t1.writeType());
		/*
		if(argv.length == 1) {
			Set fvs = t1.freeVars();
			System.out.println("free vars in type are: ");
			Enumeration e = fvs.keys();
			while(e.hasMoreElements())
				System.out.println(((Type)e.nextElement()).writeType());
			return;
		}

		Type t2 = Type.parseType(argv[1]);
		System.out.println("Type 1 is: " + t1.writeType());
		System.out.println("Type 2 is: " + t2.writeType());
		Substitution s = null;
		try {
			s = Type.unify(t1,t2);
		} catch(TypeException te) {
			System.out.println("Unification failure" + te.explain());
			return;
		}
		Type.unificationReport(s);
		*/
	}
}

