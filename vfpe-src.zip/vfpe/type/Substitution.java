/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1996-1997
*/

package vfpe.type;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import jkk.Set;
import vfpe.type.Type;

public class Substitution extends Set {
	
	/* id */
	public Substitution() { super(); }

	/* singleton sub */
	public Substitution(Object key, Object val) {
		super(); put(key,val);
	}

	/* construct from two vectors */
	public Substitution(Vector keys, Vector vals) {
		super();
		for(int i=0;i < keys.size();i++) 
			put(keys.elementAt(i),vals.elementAt(i));
	}

	/* does this <- suffix . this */
	public void apply(Substitution suffix) {
		Enumeration e = this.keys();
		while(e.hasMoreElements()) {
			Object x = e.nextElement(); Type y = (Type)this.get(x);
			this.put(x,y.substitute(suffix));
		}
		e = suffix.keys();
		while(e.hasMoreElements()) {
			Object x = e.nextElement();
			if(!this.containsKey(x))
				this.put(x,suffix.get(x));
		}
	}

	/* returns f . g */
	public static Substitution compose(Substitution f, Substitution g) {
		Substitution s = new Substitution();
		s.apply(g); s.apply(f); return s;
	}

	/* debug printing */

	public String unificationReport() {
		Type t, t2;
		StringBuffer buf = new StringBuffer();
        for(Enumeration e = keys(); e.hasMoreElements();) {
            t = (Type)e.nextElement();
            t2 = (Type)get(t);
        	buf.append("update ");
        	buf.append(t.writeType());
        	buf.append(" with ");
        	buf.append(t2.writeType());
        	buf.append('\n');
        }
        return buf.toString();
    }
}
