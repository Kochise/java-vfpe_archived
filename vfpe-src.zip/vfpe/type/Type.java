/*
    * * * * * software from the house of J Kyle Kelso
    * **  **  
  *** * * * * copyright 1997-1998
*/

/*	superclass for types: used for functions, tuples, constructor types */

package vfpe.type;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;
import java.io.Serializable;

import jkk.Set;
import jkk.text.Lexer;
import vfpe.ListParser;
import vfpe.type.Substitution;
import vfpe.type.TypeVar;

public class Type implements Serializable {

	/* constants ------------------------------------------------- */

	public static final String LIST_TAG = "List";
	public static final String ARRAY_TAG = "Array";
	public static final String FUNC_TAG = "->";
	public static final String TUPLE_PREFIX_TAG = "Tuple-";
	public static final String QUANT_TAG = "\\/";
	public static final String UNIT_TAG = "Unit";

	/* data ------------------------------------------------------ */

	public String typename;
	public Type [] args;
	
	/* constructors ---------------------------------------------- */

	public Type() { }

	public Type(String c, int a) {
		typename = c; args = new Type [a];
	}

	/* tools ----------------------------------------------------- */

	public int arity() { return args.length; }

	public Type substitute(Substitution subs) {
		Type t = new Type(typename,arity());
		for(int i=0;i < arity();i++)
			t.args[i] = args[i].substitute(subs);
		return t;
	}

	public Set freeVars() {
		Set newFVs = new Set();
		for(int i=0;i < arity();i++)
			newFVs.add(args[i].freeVars());
		return newFVs;
	}

	public Type specialise() { return this; }

	public Type copy() { return copy(new Hashtable()); }

	public Type copy(Set nonGeneric) {
		Hashtable already = new Hashtable();
		Enumeration e = nonGeneric.keys();
		while(e.hasMoreElements()) {
			Type t = (Type)e.nextElement();
			already.put(t,t);
		}
		return copy(already);
	}
	
	public Type copy(Hashtable already) {
		Type t = new Type(typename,args.length);
		for(int i=0;i < args.length;i++)
			t.args[i] = args[i].copy(already);
		return t;
	}

	/* occurs check */
	public boolean contains(Type var) {
		for(int i=0;i < args.length;i++)
			if(args[i].contains(var))
				return true;
		return false;
	}

	/* tools for funciton types */

	public int funArity() {
		if(!typename.equals(FUNC_TAG))
			return 0;
		return 1 + args[1].funArity();
	}

    public Type funArgType(int an) {
        Type tmp = this;
        for(int i = 0;i < an;i++)
            tmp = tmp.args[1];
        return tmp.args[0];
    }

    public Type funRetType(int an) {
        Type tmp = this;
        for(int i = 0;i < an;i++)
            tmp = tmp.args[1];
        return tmp.args[1];
    }

	/* printing and parsing */

	public String writeType() {

		if(typename.equals(LIST_TAG))
			return "[" + args[0].writeType() + "]";

		if(typename.equals(UNIT_TAG))
			return "()";

		if(typename.startsWith(TUPLE_PREFIX_TAG)) {
			String tmp = "(";
			for(int i=0;i < args.length;i++) {
				tmp = tmp + args[i].writeType();
				if(i < args.length-1)
					tmp = tmp + ", ";
			}
			return tmp + ")";
		}

		if(typename.equals(FUNC_TAG)) {
			Type tt = this; String tmp = "(";
			while(tt.typename.equals(FUNC_TAG)) {
				tmp = tmp + tt.args[0].writeType() + " -> ";
				tt = tt.args[1];
			}
			tmp = tmp + tt.writeType() + ")";
			return tmp;
		}

		/* must be ordinary constructor */

        if(arity() == 0)
			return typename;
		else {
			String tmp = "("+typename;
            for(int i=0;i < arity();i++)
            	tmp = tmp + " " + args[i].writeType();
			tmp = tmp + ")";
			return tmp;
		}
	}

	/*	might need to read quantified vars, maybe something like
		"\/ (x) ..." */

	public static Type parseType(String s) {
		try {
			return parseType(new Lexer(s),new Hashtable(),false);
		} catch(ArrayIndexOutOfBoundsException aioobe) {
			return null;
		}
	}

	/* this version so we can examine the var bindings */

	public static Type parseType(String s, Hashtable vars) {
		try {
			return parseType(new Lexer(s),vars,false);
		} catch(ArrayIndexOutOfBoundsException aioobe) {
			return null;
		}
	}

	private static final String TYPE_DELIM = "()[],-";

	private static Type parseType(
		Lexer lex, Hashtable vars, boolean consArg) {
		lex.nextSpace();
		char c = lex.peek();
		Type r = null;
		if(Character.isLowerCase(c)) {

			/* type variable */

			String v = lex.nextWord(TYPE_DELIM,true);
			if(vars.containsKey(v))
				r = (Type)vars.get(v);
			else {
				r = new TypeVar();
				vars.put(v,r);
			}
			
		} else if(!consArg && Character.isUpperCase(c)) {

			/* constructor type */

			String cName = lex.nextWord(TYPE_DELIM,true);
			Vector ts = parseConstructorArgTypes(lex,vars);
			r = new Type(cName,ts.size());
			for(int i=0;i < ts.size();i++)
				r.args[i] = (Type)ts.elementAt(i);

		} else if(c == '[') {

			/* list */

			lex.advance();
			Type t = parseType(lex,vars,false);
			r = new Type(LIST_TAG,1);
			r.args[0] = t;
			lex.advance();
			
		} else if(c == '(') {

			/* parenthesis */
			
			lex.advance();

			/* check for unit type */
			
			lex.nextSpace();
			if(lex.peek() == ')') {
				r = new Type(UNIT_TAG,0);
			} else {
				Vector ts = new Vector();
				Type t = parseType(lex,vars,false); ts.addElement(t);
				lex.nextSpace(); char c2 = lex.peek();
				while(c2 == ',') {
					lex.advance();
					ts.addElement(parseType(lex,vars,false));
					lex.nextSpace(); c2 = lex.peek();
				}
				lex.advance(); // should be ')'
				if(ts.size() == 1)
					r = t;
				else {
					r = new Type(TUPLE_PREFIX_TAG+ts.size(),ts.size());
					for(int i=0;i < ts.size();i++)
						r.args[i] = (Type)ts.elementAt(i);
				}
			}
		} else {
			// error
		}

		lex.nextSpace();
		if(!consArg && lex.more(false) && lex.matchToken(FUNC_TAG)) {

			/* function type */

			Type retType = parseType(lex,vars,false);
			Type thisType = new Type(FUNC_TAG,2);
			thisType.args[0] = r; thisType.args[1] = retType;
			return thisType;
		}

		return r;
	}

	private static Vector parseConstructorArgTypes(
		Lexer lex, Hashtable vars) {
		Vector ts = new Vector();
		lex.nextSpace();
		if(!lex.more(false)) return ts;
		char c = lex.peek();
		Type r = null;
		while(lex.more(false) && (
			Character.isUpperCase(c) || Character.isLowerCase(c) ||
			c == '(' || c == '[')) {
				
			if(Character.isUpperCase(c)) {

				/* zero-arg constructor */
				
				String cName = lex.nextWord(TYPE_DELIM,true);
				ts.addElement(new Type(cName,0));
			} else {
				ts.addElement(parseType(lex,vars,true));
				lex.nextSpace();
				if(!lex.more(false)) return ts;
				c = lex.peek();
			}
		}
		return ts;
	}


	/* unification ----------------------------------------------- */

/*	simple type unification - Robinson's unification algorithm (with
	occurs check).  I got this from "Functional Programming" by Field
	and Harrison (Addison Wesley 1988), ch 7.2

	throws exception on failure, or returns a Table of (var,value) that
	performs the unification on success

	has a switch to enable "one-sided" unification: ie if switch is
	-on- then substitutions for variables in t1 (the first type) -will-
	be considered, if it is -off-, substitutions for variables in t1
	-will no- be considered.

	NOTE: still under testing
*/

	/* entry points */

    public static Substitution unify(Type t1, Type t2) throws TypeException {
    	Substitution subs = new Substitution();
		Type.unify(t1,t2,subs,true); return subs;
	}

	public boolean isSubtypeOf(Type t) {
		try {
			Type.unify(this,t,new Substitution(),false);
		} catch(TypeException te) { return false; }
		return true;
	}

	/*  I think this is the same as means "having a unification involving
		only var-for-var substitutions.  With a functional language you
		could have a decent shot of -proving- that this is equivilent to
		a simpler implementation.
	*/

	public boolean isIsomorphicTo(Type t) {
		return this.isSubtypeOf(t) && t.isSubtypeOf(this);
	}

	/* implementation */

	public static void unify(
		Type t1, Type t2, Substitution subs, boolean twoSided) 
	 throws TypeException {

		/* should pick up variable equality and some others */

		if(t1.equals(t2)) return;

		/* vars */

		if(twoSided && (t1 instanceof TypeVar) && !t2.contains(t1)) {
			subs.apply(new Substitution(t1,t2)); return;
		}

		if((t2 instanceof TypeVar) && !t1.contains(t2)) {
			subs.apply(new Substitution(t2,t1)); return;
		}

		/* what do you do about quantified types in unification ? */

		if((t1 instanceof QuantifiedType) || (t1 instanceof QuantifiedType))
			throw new TypeException("quantified types",t1,t2);

		/* constructed types */

		if(!(t1 instanceof TypeVar) && !(t2 instanceof TypeVar) &&
		 t1.typename.equals(t2.typename) &&
		 t1.arity() == t2.arity()) {
			for(int i=0;i < t1.arity();i++) {
				Type.unify(
				   t1.args[i].substitute(subs),t2.args[i].substitute(subs),
				   subs,twoSided);
			}
			return;
		}

		/* could give more error info with different control flow */

		throw new TypeException("unifcation failure",t1,t2);
	}

    public String toString() { return writeType(); }
}
